/////////////////////////////////
// LAB II
// Robot.axe: Projecte de configuraci�.
// v1.0 - (c)2001 DEE-UPC
// Robot.c:Programa principal del projecte  
/////////////////////////////////

#include <embedded.h>

#include "typedefs.h"
#include "register.h"
#include "timers.h"	//funcions de control dels temporitzadors
#include "ports.h"	//funcions de control dels ports


void main()
{



}


