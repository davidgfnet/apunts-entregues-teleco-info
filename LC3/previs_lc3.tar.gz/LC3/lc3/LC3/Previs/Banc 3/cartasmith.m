z0=50;
L=10e-9;
C=10e-12;
R=25; G=1/R;
f=linspace(0,2e9,201);
w=2*pi.*f;

%Cas R figure;
figure;
smith;

zin_n=R/z0;
rho=(zin_n-1)./(zin_n+1);
plot(rho,0,'ro')
title('Carta de Smith per R')

%Cas L
figure;
smith;

zin=j*w*L;
zin_n=zin/z0;
rho=(zin_n-1)./(zin_n+1);
plot(rho,'r')
title('Carta de Smith per L')


%Cas C
figure;
smith;

yin=j*w*C;
zin_n=1./(z0*yin);
rho=(zin_n-1)./(zin_n+1);
plot(rho,'r')
title('Carta de Smith per C')

%Cas L-R paral�lel
figure;
smith;

yin=G+1./(j*w.*L);
zin_n=1./(z0*yin);
rho=(zin_n-1)./(zin_n+1);
plot(rho,'r')
title('Carta de Smith per circuit R//L')

%Cas L-C paral�lel
figure;
smith;

yin=1./(j*w*L)+j*w*C;
zin_n=1./(z0*yin);
rho=(zin_n-1)./(zin_n+1);
plot(rho,'r')
title('Carta de Smith per circuit L//C')

%Cas C-R paral�lel
figure;
smith;

yin=G+j*w*C;
zin_n=1./(z0*yin);
rho=(zin_n-1)./(zin_n+1);
plot(rho,'r')
title('Carta de Smith per circuit C//R')

%Cas L-R serie
figure;
smith;

zin=R+j*w*L;
zin_n=zin/z0;
rho=(zin_n-1)./(zin_n+1);
plot(rho,'r')
title('Carta de Smith per circuit L-R')

%Cas L-C serie
figure;
smith;

zin=1./(j*w*C)+j*w*L;
zin_n=zin/z0;
rho=(zin_n-1)./(zin_n+1);
plot(rho,'r')
title('Carta de Smith per circuit L-C')

%Cas C-R serie
figure;
smith;

zin=1./(j*w*C)+R;
zin_n=zin/z0;
rho=(zin_n-1)./(zin_n+1);
plot(rho,'r')
title('Carta de Smith per circuit C-R')