#ifndef tokens_h
#define tokens_h
/* tokens.h -- List of labelled tokens and stuff
 *
 * Generated from: cl.g
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-2001
 * Purdue University Electrical Engineering
 * ANTLR Version 1.33MR33
 */
#define zzEOF_TOKEN 1
#define INPUTEND 1
#define PROGRAM 2
#define ENDPROGRAM 3
#define PROCEDURE 4
#define ENDPROCEDURE 5
#define VARS 6
#define ENDVARS 7
#define INT 8
#define STRUCT 9
#define ENDSTRUCT 10
#define WRITELN 11
#define ARRAY 12
#define OF 13
#define PLUS 14
#define MINUS 15
#define AND 16
#define OR 17
#define NOT 18
#define TRUECONST 19
#define FALSECONST 20
#define IF 21
#define THEN 22
#define ENDIF 23
#define ELSE 24
#define WHILE 25
#define ENDWHILE 26
#define PARVAL 27
#define PARREF 28
#define DO 29
#define PRODUCT 30
#define DIVISION 31
#define EQUAL 32
#define LESSTHAN 33
#define GREATERTHAN 34
#define OPENPAR 35
#define CLOSEPAR 36
#define INDOPEN 37
#define INDCLOSE 38
#define ASIG 39
#define DOT 40
#define COMMA 41
#define INTCONST 42
#define IDENT 43
#define COMMENT 44
#define WHITESPACE 45
#define NEWLINE 46
#define LEXICALERROR 47
#define FUNCTION 48
#define ENDFUNCTION 49
#define BOOL 50
#define STRING 51

#ifdef __USE_PROTOS
void program(AST**_root);
#else
extern void program();
#endif

#ifdef __USE_PROTOS
void dec_vars(AST**_root);
#else
extern void dec_vars();
#endif

#ifdef __USE_PROTOS
void l_dec_vars(AST**_root);
#else
extern void l_dec_vars();
#endif

#ifdef __USE_PROTOS
void dec_var(AST**_root);
#else
extern void dec_var();
#endif

#ifdef __USE_PROTOS
void param_dec(AST**_root);
#else
extern void param_dec();
#endif

#ifdef __USE_PROTOS
void params_dec(AST**_root);
#else
extern void params_dec();
#endif

#ifdef __USE_PROTOS
void l_dec_blocs(AST**_root);
#else
extern void l_dec_blocs();
#endif

#ifdef __USE_PROTOS
void procedure_declaration(AST**_root);
#else
extern void procedure_declaration();
#endif

#ifdef __USE_PROTOS
void dec_bloc(AST**_root);
#else
extern void dec_bloc();
#endif

#ifdef __USE_PROTOS
void constr_type(AST**_root);
#else
extern void constr_type();
#endif

#ifdef __USE_PROTOS
void field(AST**_root);
#else
extern void field();
#endif

#ifdef __USE_PROTOS
void l_instrs(AST**_root);
#else
extern void l_instrs();
#endif

#ifdef __USE_PROTOS
void fparamlist(AST**_root);
#else
extern void fparamlist();
#endif

#ifdef __USE_PROTOS
void instruction(AST**_root);
#else
extern void instruction();
#endif

#ifdef __USE_PROTOS
void expression(AST**_root);
#else
extern void expression();
#endif

#ifdef __USE_PROTOS
void expression2(AST**_root);
#else
extern void expression2();
#endif

#ifdef __USE_PROTOS
void expression3(AST**_root);
#else
extern void expression3();
#endif

#ifdef __USE_PROTOS
void expression4(AST**_root);
#else
extern void expression4();
#endif

#ifdef __USE_PROTOS
void expression5(AST**_root);
#else
extern void expression5();
#endif

#ifdef __USE_PROTOS
void expression6(AST**_root);
#else
extern void expression6();
#endif

#ifdef __USE_PROTOS
void expression7(AST**_root);
#else
extern void expression7();
#endif

#ifdef __USE_PROTOS
void expsimple(AST**_root);
#else
extern void expsimple();
#endif

#endif
extern SetWordType zzerr1[];
extern SetWordType zzerr2[];
extern SetWordType setwd1[];
extern SetWordType zzerr3[];
extern SetWordType zzerr4[];
extern SetWordType setwd2[];
extern SetWordType zzerr5[];
extern SetWordType zzerr6[];
extern SetWordType zzerr7[];
extern SetWordType zzerr8[];
extern SetWordType zzerr9[];
extern SetWordType zzerr10[];
extern SetWordType setwd3[];
extern SetWordType zzerr11[];
extern SetWordType zzerr12[];
extern SetWordType zzerr13[];
extern SetWordType zzerr14[];
extern SetWordType zzerr15[];
extern SetWordType setwd4[];
extern SetWordType zzerr16[];
extern SetWordType zzerr17[];
extern SetWordType zzerr18[];
extern SetWordType setwd5[];
