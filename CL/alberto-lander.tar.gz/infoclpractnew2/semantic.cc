/* ===== semantic.c ===== */
#include <string>
#include <iostream>
#include <map>
#include <list>
#include <vector>


using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include "ptype.hh"
#include "symtab.hh"

#include "myASTnode.hh"

#include "semantic.hh"

// feedback the main program with our error status
int TypeError = 0;


/// ---------- Error reporting routines --------------

void errornumparam(int l) {
  TypeError = 1;
  cout<<"L. "<<l<<": The number of parameters in the call do not match."<<endl;
}

void errorincompatibleparam(int l,int n) {
  TypeError = 1;
  cout<<"L. "<<l<<": Parameter "<<n<<" with incompatible types."<<endl;
}

void errorreferenceableparam(int l,int n) {
  TypeError = 1;
  cout<<"L. "<<l<<": Parameter "<<n<<" is expected to be referenceable but it is not."<<endl;
}

void errordeclaredident(int l, string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Identifier "<<s<<" already declared."<<endl;
}

void errornondeclaredident(int l, string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Identifier "<<s<<" is undeclared."<<endl;
}

void errornonreferenceableleft(int l, string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Left expression of assignment is not referenceable."<<endl;
}

void errorincompatibleassignment(int l) {
  TypeError = 1;
  cout<<"L. "<<l<<": Assignment with incompatible types."<<endl;
}

void errorbooleanrequired(int l,string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Instruction "<<s<<" requires a boolean condition."<<endl;
}

void errorisnotprocedure(int l) {
  TypeError = 1;
  cout<<"L. "<<l<<": Operator ( must be applied to a procedure in an instruction."<<endl;
}

void errorisnotfunction(int l) {
  TypeError = 1;
  cout<<"L. "<<l<<": Operator ( must be applied to a function in an expression."<<endl;
}

void errorincompatibleoperator(int l, string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Operator "<<s<<" with incompatible types."<<endl;
}

void errorincompatiblereturn(int l) {
  TypeError = 1;
  cout<<"L. "<<l<<": Return with incompatible type."<<endl;
}

void errorreadwriterequirebasic(int l, string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Basic type required in "<<s<<"."<<endl;
}

void errornonreferenceableexpression(int l, string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Referenceable expression required in "<<s<<"."<<endl;
}

void errornonfielddefined(int l, string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Field "<<s<<" is not defined in the struct."<<endl;
}

void errorfielddefined(int l, string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Field "<<s<<" already defined in the struct."<<endl;
}

/// ------------------------------------------------------------
/// Table to store information about program identifiers
symtab symboltable;

static void InsertintoST(int line,string kind,string id,ptype tp)
{
  infosym p;

  if (symboltable.find(id) && symboltable.jumped_scopes(id)==0) errordeclaredident(line,id);
  else {
    symboltable.createsymbol(id);
    symboltable[id].kind=kind;
    symboltable[id].tp=tp;
  }
}

/// ------------------------------------------------------------

bool isbasickind(string kind) {
  return kind=="int" || kind=="bool" || kind=="string";
}

int getelem (ptype a)
{
	if (!a)
		return 0;
	return getelem(a->right)+1;
}

void check_params(AST *a,ptype tp,int line,int numparam)
{
  int npar=getelem(tp->down);
  if (npar!=numparam)
  {
  	errornumparam(line);
  	return;
  }
  ptype ta=tp->down;
  for (int i=0;i<numparam;i++)
  {
    AST* b=child(a,i);
    if (ta->kind=="ref" and !b->ref)
    {
      errorreferenceableparam(line,i+1);
    }
    if (b->tp->kind!="error")
    {
  	  if (not equivalent_types(ta->down,b->tp))
  	  {
  	    errorincompatibleparam(line,i+1);
  	  }
  	}
  	ta=ta->right;
  }
}

void insert_vars(AST *a)
{
  if (!a) return;
  TypeCheck(child(a,0));
  InsertintoST(a->line,"idvarlocal",a->text,child(a,0)->tp);
  insert_vars(a->right); 
}

void insert_vars2(AST *a)
{
	if (!a) return;
	TypeCheck(child(a,1));
	if (a->kind=="val")
	  InsertintoST(a->line,"idparval",child(a,0)->text,child(a,1)->tp);
	else
	  InsertintoST(a->line,"idparref",child(a,0)->text,child(a,1)->tp);
	  
	insert_vars2(a->right);
}

void construct_struct(AST *a)
{
  AST *a1=child(a,0);
  a->tp=create_type("struct",0,0);

  while (a1!=0) {
    TypeCheck(child(a1,0));
    if (a->tp->struct_field.find(a1->text)==a->tp->struct_field.end()) {
      a->tp->struct_field[a1->text]=child(a1,0)->tp;
      a->tp->ids.push_back(a1->text);
     } else {
      errorfielddefined(a1->line,a1->text);
    }
    a1=a1->right;
  }
}

void create_header(AST *a)
{
  TypeCheck(child(child(a,0),1));
  AST *b= child(child(child(a,0),0),0);
  ptype type;
  if (b!=0)
  {
    TypeCheck(child(b,1));
  	ptype mp = child(b,1)->tp;
  	ptype ch = create_type(b->kind,mp,0);
  	ptype ch2=ch;
  	b=b->right;
  	while (b!=0)
  	{
  		TypeCheck(child(b,1));
  		ptype myp = child(b,1)->tp;
  		ch2->right=create_type(b->kind,myp,0);
  		ch2=ch2->right;
  		b=b->right;
  	}
  	if (a->kind=="procedure")
      type=create_type("procedure",ch,0);
    else
    {
      type=create_type("function",ch,0);
      type->right=child(child(a,0),1)->tp;
    }
  }
  else
  {
  	if (a->kind=="procedure")
      type=create_type("procedure",0,0);
    else
    {
      type=create_type("function",0,0);
      type->right=child(child(a,0),1)->tp;
    }
  }
  if (a->kind=="procedure")
    InsertintoST (a->line,"procedure",child(a,0)->text,type);
  else
    InsertintoST (a->line,"function",child(a,0)->text,type);
}


void insert_header(AST *a)
{
  create_header(a);
}

void insert_headers(AST *a)
{
  while (a!=0) {
    insert_header(a);
    a=a->right;
  }
}

int size (AST *a)
{
	if (a==0)
		return 0;
	return size(a->right)+1;
}

void TypeCheck(AST *a,string info)
{
  if (!a) {
    return;
  }

  //cout<<"Starting with node \""<<a->kind<<"\""<<endl;
  if (a->kind=="program") {
    a->sc=symboltable.push();
    insert_vars(child(child(a,0),0));
    insert_headers(child(child(a,1),0));
    TypeCheck(child(a,1));
    TypeCheck(child(a,2),"instruction");
    symboltable.pop();
  }
  else if (a->kind=="procedure")
  {
  	a->sc=symboltable.push();
  	insert_vars2(child(child(child(a,0),0),0));
  	insert_vars(child(child(a,1),0));
  	insert_headers(child(child(a,2),0));
  	TypeCheck(child(a,2));
  	TypeCheck(child(a,3),"instruction");
  	symboltable.pop();
  }
  else if (a->kind=="function")
  {
  	a->sc=symboltable.push();
  	insert_vars2(child(child(child(a,0),0),0));
  	insert_vars(child(child(a,1),0));
  	insert_headers(child(child(a,2),0));
  	TypeCheck(child(child(a,0),1));
  	TypeCheck(child(a,2));
  	TypeCheck(child(a,3),"instruction");
  	TypeCheck(child(a,4));
  	if (not equivalent_types(child(child(a,0),1)->tp,child(a,4)->tp) 
  	    or child(child(a,0),1)->tp->kind =="error"
  	    or child(a,4)->tp->kind == "error")
  	  errorincompatiblereturn(child(a,4)->line);
  	a->tp=child(child(a,0),1)->tp;
  	symboltable.pop();
  }
  else if (a->kind=="if")
  {
  	TypeCheck(child(a,0));
	if (child(a,0)->tp->kind!="bool")
	  errorbooleanrequired(a->line,a->kind);
  	TypeCheck(child(a,1),"instruction");
  	if (child(a,2)!=0)
	  TypeCheck(child(a,2),"instruction");
	  
  }
  else if (a->kind=="while")
  {
  	TypeCheck(child(a,0));
	if (child(a,0)->tp->kind!="bool")
	  errorbooleanrequired(a->line,a->kind);
  	TypeCheck(child(a,1),"instruction");
  }
  else if (a->kind=="list") {
    // At this point only instruction, procedures or parameters lists are possible.
    for (AST *a1=a->down;a1!=0;a1=a1->right) {
      TypeCheck(a1,info);
    }
  }
  else if (a->kind=="ident") {
    if (!symboltable.find(a->text)) {
      errornondeclaredident(a->line, a->text);
    } 
    else {
      a->tp=symboltable[a->text].tp;
      if (a->tp->kind!="procedure" and a->tp->kind!="function")
	    a->ref=1;
    }
  } 
  else if (a->kind=="struct") {
    construct_struct(a);
  }
  else if (a->kind==":=") {
    TypeCheck(child(a,0));
    TypeCheck(child(a,1));
    if (!child(a,0)->ref) {
      errornonreferenceableleft(a->line,child(a,0)->text);
    }
    else if (child(a,0)->tp->kind!="error" && child(a,1)->tp->kind!="error" &&
	     !equivalent_types(child(a,0)->tp,child(a,1)->tp)) {
      errorincompatibleassignment(a->line);
    } 
    else {
      a->tp=child(a,0)->tp;
    }
  }
  else if (a->kind=="(")
  {
  	TypeCheck(child(a,0));
  	if (child(a,0)->tp->kind!="error")
  	{
  		
  	  TypeCheck(child(a,1));
      if (info=="instruction")
      {
        if (child(a,0)->tp->kind!="procedure" && child(a,0)->tp->kind!="function")
	      errorisnotprocedure(a->line);
	    else
	    {
	      if (child(a,0)->tp->kind!="procedure")
	      	errorisnotprocedure(a->line);
          check_params(child(a,1),child(a,0)->tp,a->line,size(child(child(a,1),0)));
        }
      }
      else
      {
        if (child(a,0)->tp->kind!="procedure" && child(a,0)->tp->kind!="function")
	      errorisnotfunction(a->line);
	    else
	    {
	      if (child(a,0)->tp->kind!="function")
	        errorisnotfunction(a->line);
          check_params(child(a,1),child(a,0)->tp,a->line,size(child(child(a,1),0)));
	    }
      }
      if (child(a,0)->tp->kind=="function")
      {
      	a->tp=child(a,0)->tp->right;
      }
  	}
  }
  else if (a->kind=="intconst") {
    a->tp=create_type("int",0,0);
  }
  else if (a->kind=="string")
  {
  	a->tp=create_type("string",0,0);
  }
  else if (a->kind=="true")
  {
  	a->tp=create_type("bool",0,0);
  }
  else if (a->kind=="false")
  {
  	a->tp=create_type("bool",0,0);
  }
  else if (a->kind=="array")
  {
  	TypeCheck(child(a,0));
  	TypeCheck(child(a,1));
    a->tp=create_type("array",0,0);
    a->tp->numelemsarray=atoi(child(a,0)->text.c_str());
    a->tp->size=a->tp->numelemsarray*child(a,1)->tp->size;
    a->tp->down=child(a,1)->tp;
  }
  else if (a->kind=="+" || (a->kind=="-" && child(a,1)!=0) || a->kind=="*"
	   || a->kind=="/") {
    TypeCheck(child(a,0));
    TypeCheck(child(a,1));
    if ((child(a,0)->tp->kind!="error" && child(a,0)->tp->kind!="int") ||
	(child(a,1)->tp->kind!="error" && child(a,1)->tp->kind!="int")) {
      errorincompatibleoperator(a->line,a->kind);
    }
    a->tp=create_type("int",0,0);
  }
  else if (a->kind=="<" || a->kind==">")
  {
  	TypeCheck(child(a,0));
    TypeCheck(child(a,1));
    if ((child(a,0)->tp->kind!="error" && child(a,0)->tp->kind!="int") ||
	(child(a,1)->tp->kind!="error" && child(a,1)->tp->kind!="int")) {
      errorincompatibleoperator(a->line,a->kind);
    }
    a->tp=create_type("bool",0,0);
  }
  else if (a->kind=="=")
  {
  	TypeCheck(child(a,0));
    TypeCheck(child(a,1));
    if (child(a,0)->tp->kind!="error" && child(a,1)->tp->kind!="error" && 
	(not equivalent_types(child(a,0)->tp ,child(a,1)->tp) or 
	(child(a,0)->tp->kind!="int" and child(a,0)->tp->kind!="bool"))) {
      errorincompatibleoperator(a->line,a->kind);
    }
    a->tp=create_type("bool",0,0);
  }
  else if (a->kind=="not")
  {
  	TypeCheck(child(a,0));
  	if (child(a,0)->tp->kind!="error" && child(a,0)->tp->kind!="bool"){
      errorincompatibleoperator(a->line,a->kind);
    }
    a->tp=create_type("bool",0,0);
  }
  else if (a->kind=="-" && (child(a,1)==0))
  {
  	TypeCheck(child(a,0));
  	if (child(a,0)->tp->kind!="error" && child(a,0)->tp->kind!="int"){
      errorincompatibleoperator(a->line,a->kind);
    }
    a->tp=create_type("int",0,0);
  }
  else if (a->kind=="or" || a->kind=="and")
  {
  	TypeCheck(child(a,0));
    TypeCheck(child(a,1));
    if ((child(a,0)->tp->kind!="error" && child(a,0)->tp->kind!="bool") ||
	(child(a,1)->tp->kind!="error" && child(a,1)->tp->kind!="bool")) {
      errorincompatibleoperator(a->line,a->kind);
    }
    a->tp=create_type("bool",0,0);
  }
  else if (isbasickind(a->kind)) {
    a->tp=create_type(a->kind,0,0);
  }
  else if (a->kind=="read")
  {
    TypeCheck(child(a,0));
    if (not child(a,0)->ref)
      errornonreferenceableexpression(a->line,a->kind);
    else if (child(a,0)->tp->kind!="error" && !isbasickind(child(a,0)->tp->kind)) {
      errorreadwriterequirebasic(a->line,a->kind);
    }
  }
  else if (a->kind=="writeln" || a->kind=="write") {
    TypeCheck(child(a,0));
    if (child(a,0)->tp->kind!="error" && !isbasickind(child(a,0)->tp->kind)) {
      errorreadwriterequirebasic(a->line,a->kind);
    }
  }
  else if (a->kind==".") {
    TypeCheck(child(a,0));
    a->ref=child(a,0)->ref;
    if (child(a,0)->tp->kind!="error") {
      if (child(a,0)->tp->kind!="struct") {
	errorincompatibleoperator(a->line,"struct.");
      }
      else if (child(a,0)->tp->struct_field.find(child(a,1)->text)==
	       child(a,0)->tp->struct_field.end()) {
	errornonfielddefined(a->line,child(a,1)->text);
      } 
      else {
	a->tp=child(a,0)->tp->struct_field[child(a,1)->text];
      }
    }
  }
  else if (a->kind=="[")
  {
  	TypeCheck(child(a,0));
  	TypeCheck(child(a,1));
  	if (child(a,0)->tp->kind!="array")
  	{
  	  if (child(a,0)->tp->kind!="error")
  	  {
  	    errorincompatibleoperator(a->line,"array[]");
  	  }
  	}
  	else
  	{
  	  a->tp=child(a,0)->tp->down;
  	}
  	if (child(a,1)->tp->kind!="int" and child(a,1)->tp->kind!="error")
  	  errorincompatibleoperator(a->line,"[]");
  	a->ref=child(a,0)->ref;
  }
  else {
    cout<<"BIG PROBLEM! No case defined for kind "<<a->kind<< "(semantic)" <<endl;
  }

  //cout<<"Ending with node \""<<a->kind<<"\""<<endl;
}
