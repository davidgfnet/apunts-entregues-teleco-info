#ifndef tokens_h
#define tokens_h
/* tokens.h -- List of labelled tokens and stuff
 *
 * Generated from: cl.g
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-2001
 * Purdue University Electrical Engineering
 * ANTLR Version 1.33MR33
 */
#define zzEOF_TOKEN 1
#define INPUTEND 1
#define PROGRAM 2
#define ENDPROGRAM 3
#define VARS 4
#define ENDVARS 5
#define PROCEDURE 6
#define ENDPROCEDURE 7
#define FUNCTION 8
#define ENDFUNCTION 9
#define IF 10
#define THEN 11
#define ELSE 12
#define ENDIF 13
#define WHILE 14
#define DO 15
#define ENDWHILE 16
#define REF 17
#define VAL 18
#define INT 19
#define BOOL 20
#define STRUCT 21
#define ENDSTRUCT 22
#define ARRAY 23
#define OF 24
#define READ 25
#define WRITE 26
#define WRITELN 27
#define AND 28
#define OR 29
#define NOT 30
#define RET 31
#define PLUS 32
#define MINUS 33
#define MULT 34
#define DIV 35
#define OPENPAR 36
#define CLOSEPAR 37
#define OPENBR 38
#define CLOSEBR 39
#define ASIG 40
#define DOT 41
#define COMMA 42
#define GREAT 43
#define LESS 44
#define EQUAL 45
#define BOOLCONST 46
#define STRING 47
#define IDENT 48
#define INTCONST 49
#define COMMENT 50
#define WHITESPACE 51
#define NEWLINE 52
#define LEXICALERROR 53

#ifdef __USE_PROTOS
void program(AST**_root);
#else
extern void program();
#endif

#ifdef __USE_PROTOS
void dec_vars(AST**_root);
#else
extern void dec_vars();
#endif

#ifdef __USE_PROTOS
void l_dec_vars(AST**_root);
#else
extern void l_dec_vars();
#endif

#ifdef __USE_PROTOS
void dec_var(AST**_root);
#else
extern void dec_var();
#endif

#ifdef __USE_PROTOS
void l_dec_blocs(AST**_root);
#else
extern void l_dec_blocs();
#endif

#ifdef __USE_PROTOS
void dec_bloc(AST**_root);
#else
extern void dec_bloc();
#endif

#ifdef __USE_PROTOS
void header_proc(AST**_root);
#else
extern void header_proc();
#endif

#ifdef __USE_PROTOS
void header_func(AST**_root);
#else
extern void header_func();
#endif

#ifdef __USE_PROTOS
void list_vars(AST**_root);
#else
extern void list_vars();
#endif

#ifdef __USE_PROTOS
void dec_param(AST**_root);
#else
extern void dec_param();
#endif

#ifdef __USE_PROTOS
void constr_type(AST**_root);
#else
extern void constr_type();
#endif

#ifdef __USE_PROTOS
void field(AST**_root);
#else
extern void field();
#endif

#ifdef __USE_PROTOS
void l_instrs(AST**_root);
#else
extern void l_instrs();
#endif

#ifdef __USE_PROTOS
void instruction(AST**_root);
#else
extern void instruction();
#endif

#ifdef __USE_PROTOS
void list_exp(AST**_root);
#else
extern void list_exp();
#endif

#ifdef __USE_PROTOS
void expression(AST**_root);
#else
extern void expression();
#endif

#ifdef __USE_PROTOS
void comparison(AST**_root);
#else
extern void comparison();
#endif

#ifdef __USE_PROTOS
void term(AST**_root);
#else
extern void term();
#endif

#ifdef __USE_PROTOS
void factor(AST**_root);
#else
extern void factor();
#endif

#ifdef __USE_PROTOS
void expsimple(AST**_root);
#else
extern void expsimple();
#endif

#endif
extern SetWordType zzerr1[];
extern SetWordType zzerr2[];
extern SetWordType setwd1[];
extern SetWordType zzerr3[];
extern SetWordType zzerr4[];
extern SetWordType zzerr5[];
extern SetWordType setwd2[];
extern SetWordType zzerr6[];
extern SetWordType zzerr7[];
extern SetWordType zzerr8[];
extern SetWordType zzerr9[];
extern SetWordType zzerr10[];
extern SetWordType zzerr11[];
extern SetWordType setwd3[];
extern SetWordType zzerr12[];
extern SetWordType zzerr13[];
extern SetWordType zzerr14[];
extern SetWordType zzerr15[];
extern SetWordType setwd4[];
extern SetWordType zzerr16[];
extern SetWordType zzerr17[];
extern SetWordType setwd5[];
