#ifndef tokens_h
#define tokens_h
/* tokens.h -- List of labelled tokens and stuff
 *
 * Generated from: cl.g
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-2001
 * Purdue University Electrical Engineering
 * ANTLR Version 1.33MR33
 */
#define zzEOF_TOKEN 1
#define INPUTEND 1
#define PROGRAM 2
#define ENDPROGRAM 3
#define PROCEDURE 4
#define ENDPROCEDURE 5
#define FUNCTION 6
#define ENDFUNCTION 7
#define RETURN 8
#define VARS 9
#define ENDVARS 10
#define INT 11
#define STRUCT 12
#define ENDSTRUCT 13
#define WRITELN 14
#define ARRAY 15
#define OF 16
#define PLUS 17
#define MINUS 18
#define AND 19
#define OR 20
#define NOT 21
#define TRUECONST 22
#define FALSECONST 23
#define IF 24
#define THEN 25
#define ENDIF 26
#define ELSE 27
#define WHILE 28
#define ENDWHILE 29
#define PARVAL 30
#define PARREF 31
#define DO 32
#define PRODUCT 33
#define DIVISION 34
#define EQUAL 35
#define LESSTHAN 36
#define GREATERTHAN 37
#define OPENPAR 38
#define CLOSEPAR 39
#define INDOPEN 40
#define INDCLOSE 41
#define ASIG 42
#define DOT 43
#define COMMA 44
#define INTCONST 45
#define IDENT 46
#define COMMENT 47
#define WHITESPACE 48
#define NEWLINE 49
#define LEXICALERROR 50
#define BOOL 51
#define STRING 52

#ifdef __USE_PROTOS
void program(AST**_root);
#else
extern void program();
#endif

#ifdef __USE_PROTOS
void dec_vars(AST**_root);
#else
extern void dec_vars();
#endif

#ifdef __USE_PROTOS
void l_dec_vars(AST**_root);
#else
extern void l_dec_vars();
#endif

#ifdef __USE_PROTOS
void dec_var(AST**_root);
#else
extern void dec_var();
#endif

#ifdef __USE_PROTOS
void param_dec(AST**_root);
#else
extern void param_dec();
#endif

#ifdef __USE_PROTOS
void params_dec(AST**_root);
#else
extern void params_dec();
#endif

#ifdef __USE_PROTOS
void l_dec_blocs(AST**_root);
#else
extern void l_dec_blocs();
#endif

#ifdef __USE_PROTOS
void procedure_declaration(AST**_root);
#else
extern void procedure_declaration();
#endif

#ifdef __USE_PROTOS
void function_declaration(AST**_root);
#else
extern void function_declaration();
#endif

#ifdef __USE_PROTOS
void dec_bloc(AST**_root);
#else
extern void dec_bloc();
#endif

#ifdef __USE_PROTOS
void constr_type(AST**_root);
#else
extern void constr_type();
#endif

#ifdef __USE_PROTOS
void field(AST**_root);
#else
extern void field();
#endif

#ifdef __USE_PROTOS
void l_instrs(AST**_root);
#else
extern void l_instrs();
#endif

#ifdef __USE_PROTOS
void fparamlist(AST**_root);
#else
extern void fparamlist();
#endif

#ifdef __USE_PROTOS
void instruction(AST**_root);
#else
extern void instruction();
#endif

#ifdef __USE_PROTOS
void expression(AST**_root);
#else
extern void expression();
#endif

#ifdef __USE_PROTOS
void expression2(AST**_root);
#else
extern void expression2();
#endif

#ifdef __USE_PROTOS
void expression3(AST**_root);
#else
extern void expression3();
#endif

#ifdef __USE_PROTOS
void expression4(AST**_root);
#else
extern void expression4();
#endif

#ifdef __USE_PROTOS
void expression5(AST**_root);
#else
extern void expression5();
#endif

#ifdef __USE_PROTOS
void expression6(AST**_root);
#else
extern void expression6();
#endif

#ifdef __USE_PROTOS
void expression7(AST**_root);
#else
extern void expression7();
#endif

#ifdef __USE_PROTOS
void expsimple(AST**_root);
#else
extern void expsimple();
#endif

#endif
extern SetWordType zzerr1[];
extern SetWordType zzerr2[];
extern SetWordType zzerr3[];
extern SetWordType setwd1[];
extern SetWordType zzerr4[];
extern SetWordType zzerr5[];
extern SetWordType zzerr6[];
extern SetWordType setwd2[];
extern SetWordType zzerr7[];
extern SetWordType zzerr8[];
extern SetWordType zzerr9[];
extern SetWordType zzerr10[];
extern SetWordType zzerr11[];
extern SetWordType zzerr12[];
extern SetWordType setwd3[];
extern SetWordType zzerr13[];
extern SetWordType zzerr14[];
extern SetWordType zzerr15[];
extern SetWordType zzerr16[];
extern SetWordType setwd4[];
extern SetWordType zzerr17[];
extern SetWordType zzerr18[];
extern SetWordType zzerr19[];
extern SetWordType zzerr20[];
extern SetWordType setwd5[];
