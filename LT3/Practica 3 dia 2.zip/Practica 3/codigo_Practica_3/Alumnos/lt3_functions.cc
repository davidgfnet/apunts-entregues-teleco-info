#include <omnetpp.h>

double lt3_rng()
{
	return uniform(0,1); //Funci�n estad�stica propia de Omnet
}

double lt3_exponencial(double media)
{
	// Incluir aqu� el c�digo necesario para generar un valor exponecial de media "media"
}

double lt3_geometrica(double vmin, double vmax, double media)
{
	// Incluir aqu� el c�digo necesario para generar una variable geom�trica entre un valor m�nimo, "vmin",
  //y un valor m�ximo, "vmax", con media "media"
}


double lt3_normal(double media, double varianza, double metodo)
{
	// Incluir aqu� el c�digo necesario para generar un valor normal segun el metodo "metodo"
}

double lt3_convolucion_exponencial(double media, double numExp)
{
	// Incluir aqu� el c�digo necesario para generar la variable T del ejercicio 6.
	// Mean sera media empleada en las variables aleatorias exponenciales y numExp es el numero de exponenciales a sumar
}

double lt3_chi2(double media, double varianza, double k)
{
	// Incluir aqu� el c�digo necesario para generar un valor chi cuadrado a partir de 
	// k v.a. normales de media "media" y varianza "varianza" cada una al cuadradado
}

Define_Function(lt3_rng, 0);
Define_Function(lt3_exponencial, 1);
Define_Function(lt3_geometrica, 3);
Define_Function(lt3_normal, 3);
Define_Function(lt3_convolucion_exponencial, 2);
Define_Function(lt3_chi2, 3);
