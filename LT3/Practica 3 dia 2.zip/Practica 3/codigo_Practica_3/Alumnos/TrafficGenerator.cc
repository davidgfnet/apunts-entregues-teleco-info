#include <cmessage.h>
#include <string.h>
#include <omnetpp.h>
#include <sstream>
#include "Lt3Message_m.h"

using namespace std;


class TrafficGenerator : public cSimpleModule
{
private:
    bool endSim;
    int msgKind;	// Tipo de mensaje a generar
	int priority;	// Prioridad de los mensajes
    unsigned long long packetSent;	// Mensajes enviados

public:
    Module_Class_Members(TrafficGenerator, cSimpleModule, 0);

    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

// Registramos la clase para su uso en OMNET
Define_Module(TrafficGenerator);

void TrafficGenerator::initialize()
{
    cMessage * msg;

    // Inicializando variables
    msgKind = static_cast<int>(par("msgKind"));	
    priority =  static_cast<int>(par("priority"));
    packetSent = 0;	
    endSim = false;

    // Enviando el mensaje inicial
    msg = new Lt3Message("Paquete");
    msg->setKind(msgKind);
	msg->setPriority(priority);
	msg->setLength(1);
    // Se crea un trigger para enviar el mensaje inicial pasado un cierto tiempo
    scheduleAt(simTime() + (double) par("time_between_arrivals"), msg);
}

void TrafficGenerator::handleMessage(cMessage *msg)
{
	cMessage * msgToBeSent;
	ostringstream ostr;
    
	if (msg->isSelfMessage()) {
		// El mensaje procede del modulo SimpleTrafficGenerator (trigger)
		if (!endSim) {
			// Se crea un duplicado del paquete
			msgToBeSent = (cMessage *) msg->dup();

			// Incrementamos el numero de paquetes enviados
			++packetSent;

			// Modificamos el nombre del paquete de acuerdo al numero de paquete
			ostr << packetSent;
			msgToBeSent->setName(ostr.str().c_str());
			ostr.str("");

	
			if (ev.isGUI()) {
				ostr << "New message of type " << msgToBeSent->kind();
				bubble(ostr.str().c_str());
			}
	
			// Enviando el siguiente mensaje
			ev << "Number of messages of type " << msgToBeSent->kind() << " is " << packetSent << endl;
			send(msgToBeSent, "gout");
	
			// Se programa el trigger para el siguiente paquete
			scheduleAt(simTime() + (double) par("time_between_arrivals"), msg);
		}
		else {
			// Borramos el paquete
			delete msg;
		}
	}
	else {
		// El mensaje es de control. Por defecto se para la generacion de mensajes.
		endSim = true;
		delete msg;
		//endSimulation();
	}
}


