
#include <iostream>

using namespace std;

int main() {
	double temps, temps_anterior, accum = 0;
	int us, us_anterior;
	int numpackets = 0;
	cin >> temps_anterior >> us_anterior;

	while (cin >> temps) {
		cin >> us;

		if (us > us_anterior) {
			double dif_temps = temps - temps_anterior;
			accum += dif_temps;
			numpackets++;
			temps_anterior = temps;
		}
		us_anterior = us;

	}

	accum = accum / 10000;
	cout << accum << endl;
	cout << numpackets << endl;
}
