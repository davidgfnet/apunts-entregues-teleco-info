#! /bin/bash

# check 
if [[ -z "${3}" ]]; then
	echo "Usage: ${0} number_of_runs name_of_the_program_to_run output_path [initial_seed]"
	echo "Ex. ${0} 10 sim_run dout     runs sim_run program 10 times and leaves the results in the 'dout' directory"
	exit 
fi

ls ${3} &> /dev/null
if [ $? -ne 0 ]; then
	echo "The path \"${3}\" does not exist"
	exit 2
fi

if [[ -z "${4}" ]]; then
	initialSeed=1
else
	initialSeed=${4}
fi

declare -a seeds

seedtool g ${initialSeed} 10000000 ${1} > seed_file.txt
seeds=(`cat seed_file.txt`)

mv seeds.ini seeds.ini.default
for i in `seq 0 $[${1} - 1]`; do
	(
		echo "output-vector-file = omnetpp_${i}.vec"
		echo "seed = ${seeds[${i}]}"
		echo "seed-0-mt = ${seeds[${i}]}"
	) > seeds.ini
	./$2

	# Guardar ficheros de configuracion
	mv seeds.ini ${3}/seeds_${i}.ini

	# Guardar el fichero de resultados 
	mv omnetpp_${i}.vec ${3}/omnetpp_${i}.vec

done

cp omnetpp.ini ${3}/omnetpp.ini
mv seed_file.txt ${3}/seed_file.txt

mv seeds.ini.default seeds.ini

