#ifndef __LT3LCG_H
#define __LT3LCG_H

#include "cLT3rng.h"

class LT3LCG : public cLT3rng {
private:
	unsigned long long numberOfSamplesGenerated;
	unsigned long long seed;
	unsigned long long a;
	unsigned long long b;
	unsigned long long m;
	unsigned long long currentX;	

public:
	virtual void initialize(int runNumber, int id, int numRngs, int parsimProcId, int parsimNumPartitions, cConfiguration *cfg);
	virtual void selfTest();
	virtual double doubleRand();
};

#endif
