


% v mostres, n num categories, k i theta valors de gamma
function pearson_test_exp(v,n, mu,a)
    % v mostres, n categories
    histo = hist(v,n);
    % V.A. exponencial
    valor_esp = 0;
    for i=1:n-1
       valor_esp(i+1) = (1-0.75)*power(0.75,i);
    end
    valor_esp(1) = 1- sum(valor_esp);
    valor_esp = 50000*valor_esp;
    
%    factor = a*max(histo)./max(valor_esp);
%    valor_esp = factor*valor_esp;
    
    plot(histo)
    figure()
    plot(valor_esp)
    figure()

    % Calcul
    resta = histo-valor_esp;
    % Suma al cuadrat
        plot(resta)
    
    suma = 0;
    for i=1:n
        suma = suma + resta(i)*resta(i)./valor_esp(i);
    end
    suma
end

% matriu entrada es parells de temps i ocupacio de cua
function num_unitats_en_cua (W)
    % Vector de temps
    vt=W(:,1:1);
    % Vector de diferencies de temps
    vt2=vt(2:size(vt))-vt(1:size(vt)-1);
    % Vector de paquets a la cua
    vn=W(:,2:2);
    vn=vn(1:size(vn)-1);
    % Producte escalar
    prod = vt2'*vn;
    % Dividir entre el temps total
    prod = prod./(max(vt)-min(vt));
    prod
end

% Vector d'entrada es temps mitjos d'espera
function probabilitat_demora(W)
    cont0=0;
    for i=1:size(W,1)
        if (W(i) == 0)
            cont0 = cont0+1;
        end
    end
    prob_buit=cont0./size(W,1);
    prob_algu=1-prob_buit;
    prob_algu
end



function [S] = filtra_temps (W,t1,t2)
    temps = W(:,1:1);
    m1 =-1;
    m2 =-1;
    for i=1:size(W,1)
        if (temps(i) > t1 && m1 < 0)
         m1 = i;
        end
        if (temps(i) > t2 && m2 < 0)
         m2 = i;
        end
    end
    S = W(m1:m2,:);
end