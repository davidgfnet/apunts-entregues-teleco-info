#! /bin/bash

if [ $# -ne 2 ]; then
    echo "Usage: ${0} vector 'filter'"
    echo -e "Example: ${0} 0 '*.vec' \t generates files with the content of the vector 0 for all the files *.vec"
    exit 1
fi

for i in `ls ${2}`; do
  awk '{ if ($1 == '"${1}"') print $2,$3 }' < $i > "$i.vector_${1}"
done
