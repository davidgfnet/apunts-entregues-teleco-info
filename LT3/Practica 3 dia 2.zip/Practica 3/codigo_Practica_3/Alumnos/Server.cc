
#include <csimplemodule.h>
#include <macros.h>
#include <cmessage.h>
#include <cqueue.h>

#include <string.h>
#include <iostream>

using namespace std;


typedef unsigned long ULONG;
typedef unsigned long long ULONGLONG;

typedef enum { NO_PRIORITY, PRIORITY } PRIORITY_ENUM;

class Server : public cSimpleModule
{
private:	// Representation
	unsigned int numSources;
	long double lastTimeOfArrival;
		
	ULONG numSamples;	// Number of samples to be taken
	bool endSim; 		// Simulation has ended?

	struct InputKind {
		long double lastTimeOfArrival;
		cOutVector timeBetweenArrivals;	// Time between arrivals to the server.
		ULONG queueAllocated;	// Amount of bytes (or bits) already allocated in the queue.
		cOutVector queueTime;	// Samples for time spent in the queue.
		cOutVector queueOccupancy;	// Samples for the amount of bytes (or bits) allocated in the queue
		ULONGLONG bitsQueued;
		ULONGLONG messagesQueued;
		ULONGLONG bitsLost;	// Number of byes lost.
		ULONGLONG messagesLost;	// Number of messages lost.
		ULONGLONG bitsCarried;  // Number of bytes carried.
		ULONGLONG messagesCarried;  // Number of messages carried.
	};
	InputKind *iqueues;	// One per traffic.
	cQueue *queue;		// Queue for messages accepted but not carried yet
	cOutVector allQueueTime;	// Samples for time spent in the queues (for all-traffic)
	cOutVector allQueueOccupancy;	// Samples for the amount of bytes (or bits) allocated in all queues
	cOutVector allTimeBetweenArrivals;	// Time between arrivals to the server (for all-traffic)
	ULONG queueSize;	// Amount of bytes (or bits) that can be queued
	ULONG allQueueAllocated;	// Amount of bytes (or bits) already allocated in all queues

	struct ServerProcessor {
		cOutVector serverOccupancy;	// Samples (0/1) for the busy server (one per server)
		bool serverBusy;	// Status of each server
	};
	ServerProcessor *servers;
	int numOfServers;	// Number of servers
	cPar *serviceTime;	// Elapsed time by service
	int numOfServersBusy;	// Number of busy servers
	cOutVector allServerOccupancy;	// Samples for the number of busy servers

	ULONG numPackets;	// Number of packets already carried
	
public:
	Module_Class_Members(Server, cSimpleModule, 0);

	~Server();

	// The following redefined virtual function holds the algorithm.
	virtual void initialize();
	virtual void handleMessage(cMessage *msg);
	virtual void finish();

private:	// Implementation methods
	void initializeInputKind(InputKind *iq, int i);
	void finishInputKind(InputKind *iq, int i);
	void initializeServerProcessor(ServerProcessor *s, int i);
	void timerEnd(ServerProcessor *s, cMessage *msg);
	void messageArrival(InputKind *iq, cMessage *msg);

	void insertMessageIntoQueue(InputKind *iq, cMessage *msg);	// Insert a new message in the queue (when all servers busy)
	cMessage * getQueuedMessage();	// Gets the following message from queue
	ServerProcessor *selectServer(cMessage *msg);
	void freeServer(ServerProcessor *s);
};


//----------------------------------------------------------------------------

// The module class needs to be registered with OMNeT++
Define_Module(Server);


static int cmpbypriorityandtime(cObject * a, cObject * b)
{
  if (((cMessage*)a)->priority() == ((cMessage *)b)->priority())
    return (((cMessage*)a)->arrivalTime() > ((cMessage *)b)->arrivalTime());
  
  return (((cMessage*)a)->priority() > ((cMessage *)b)->priority());
}


Server::~Server() {
	// Delete pre-allocated queue
	delete queue;

	delete[] servers;
	delete[] iqueues;
}


void Server::initialize()
{
	int i;

	numSources = static_cast<unsigned int>(par("numSources"));
	iqueues = new InputKind[numSources];
	for (i=0; i < numSources; i++) {
		initializeInputKind(& iqueues[i], i);
	}

	// Init values for total statistics (i.e. accounting for all the traffic)
	allQueueOccupancy.setName("Queue GLOBAL occupancy");
	allQueueTime.setName("Time spent in queue GLOBAL");
	allTimeBetweenArrivals.setName("GLOBAL Time between arrivals");
	allQueueOccupancy.record(0);
	allQueueAllocated = 0;
	
	// FIFO Queue with priority. Lowest priority figures stand for highest priority in the queue.
	queue = new cQueue("Queue", cmpbypriorityandtime);	// Queue instance
	
	numOfServers = (int) par("numServers");
	serviceTime = & par("serviceTime");
	servers = new ServerProcessor[numOfServers];
	for (i=0; i < numOfServers; i++) {
		initializeServerProcessor(& servers[i], i);
	}
	allServerOccupancy.setName("Server GLOBAL occupancy");
	allServerOccupancy.record(0);
	numOfServersBusy = 0;

	numPackets = 0;
	numSamples = static_cast<unsigned long>(par("numSamples"));
	queueSize = static_cast<unsigned long>(par("queueSize"));
	
	endSim = false;
	lastTimeOfArrival = -1;
}


void Server::initializeInputKind(InputKind *iq, int i)
{
	stringstream cstr;	// For string operations
	// Init queueOccupancy 
	cstr.str("");
	cstr << "Queue " << i << " occupancy";
	iq->queueOccupancy.setName(cstr.str().c_str());
	iq->queueOccupancy.record(0);

	// Init queueTime
	cstr.str("");
	cstr << "Time spent in queue " << i;
	iq->queueTime.setName(cstr.str().c_str());

	// Init the timeBetweenArrivals
	cstr.str("");
	cstr << "Time between arrivals " << i;
	iq->timeBetweenArrivals.setName(cstr.str().c_str());

	// Init the rest
	iq->lastTimeOfArrival = -1;
	iq->queueAllocated = 0;
	iq->bitsQueued = 0;
	iq->bitsLost = 0;
	iq->bitsCarried = 0;
	iq->messagesQueued = 0;
	iq->messagesLost = 0;
	iq->messagesCarried = 0;
}


void Server::initializeServerProcessor(ServerProcessor *s, int i)
{
	stringstream cstr;	// For string operations
	// Init serverOccupancy
	cstr.str("");
	cstr << "Server " << i << " occupancy";
	s->serverOccupancy.setName(cstr.str().c_str());
	s->serverOccupancy.record(0);
	s->serverBusy = false;
}


void Server::finish()
{
	int i;
	// Storing bytes lost and carried
	for (i = 0; i < numSources; i ++) {
		finishInputKind(& iqueues[i], i);
	}
}


void Server::finishInputKind(InputKind *iq, int i)
{
	stringstream cstr;
	// Storing bytes lost and carried
	cstr.str("");
	cstr << "Bits of type " << i << " carried: ";
	recordScalar(cstr.str().c_str(), iq->bitsCarried);

	cstr.str("");
	cstr << "Messages of type " << i << " carried: ";
	recordScalar(cstr.str().c_str(), iq->messagesCarried);

	cstr.str("");
	cstr << "Bits of type " << i << " lost: ";
	recordScalar(cstr.str().c_str(), iq->bitsLost);

	cstr.str("");
	cstr << "Messages of type " << i << " lost: ";
	recordScalar(cstr.str().c_str(), iq->messagesLost);

	cstr.str("");
	cstr << "Bits of type " << i << " queued: ";
	recordScalar(cstr.str().c_str(), iq->bitsQueued);

	cstr.str("");
	cstr << "Messages of type " << i << " queued: ";
	recordScalar(cstr.str().c_str(), iq->messagesQueued);
}


void Server::handleMessage(cMessage *msg)
{
	if (!endSim) {
		if (msg->isSelfMessage()) {
			timerEnd((ServerProcessor*) msg->contextPointer(), msg);
		} else {
			messageArrival(& iqueues[msg->kind()], msg);
		}
	}
	else {
		// Simulation has ended. Send back END message.
		delete msg;
		cMessage * auxMsg = new cMessage("EndControl");
		send(auxMsg, "goutBk");
	}
}


/**
 * New arrival of input traffic
 */
void Server::messageArrival(InputKind *iq, cMessage *msg)
{
	if (lastTimeOfArrival >= 0) allTimeBetweenArrivals.record(simTime() - lastTimeOfArrival);
	if (iq->lastTimeOfArrival >= 0) iq->timeBetweenArrivals.record(simTime() - iq->lastTimeOfArrival);
	lastTimeOfArrival = simTime();
	iq->lastTimeOfArrival = simTime();

	// Select the server to allocate
	ServerProcessor *s = selectServer(msg);
	if (s != 0) {
		// There are free resources
		
		// Updating queue samples
		iq->queueTime.record(0);
		allQueueTime.record(0);

		msg->setContextPointer(s);
		// Ask again once the service time have finished
		scheduleAt(simTime() + msg->length() * serviceTime->doubleValue(), msg);
	} else {
		// All resources are busy. The request is queued
		insertMessageIntoQueue(iq, msg);
	}
}


/**
 * Finalization of service processing
 */
void Server::timerEnd(ServerProcessor *s, cMessage *msg)
{
	// One more message is carried
	numPackets++;

	// Updating the scalar statistics for traffic carried
	InputKind *iq = & iqueues[msg->kind()];
	iq->bitsCarried += msg->length();
	iq->messagesCarried ++;

	// Delivering the message to the sink
	send(msg, "goutFw");

	// If enough samples
	if (numPackets >= numSamples) {
		cMessage * auxMsg = new cMessage("EndControl");
		send(auxMsg, "goutBk");
		//endSim = true;
	}

	// Looking for next queued request
	if (queue->empty()) {
		// Server becomes free
		freeServer(s);
	} else {
		// Server continues with a queued message
		// Extract the first message from the queue
		cMessage * queuedMsg = getQueuedMessage();

		queuedMsg->setContextPointer(s);
		// Ask again once the service time have finished
		scheduleAt(simTime() + msg->length() * serviceTime->doubleValue(), queuedMsg);
	}
}


/**
 * Extract the first message from the queue
 */
cMessage * Server::getQueuedMessage()
{
	cMessage * nextMsg;

	// Get next message
	nextMsg = (cMessage *)queue->pop();
	InputKind *iq = & iqueues[nextMsg->kind()];

	// Free the amount of bytes in the accounting for this traffic
	iq->queueAllocated -= nextMsg->length();
	
	// Free the amount of bytes in the accounting for all traffics
	allQueueAllocated -= nextMsg->length();
	
	// Trace
	ev << "Message " << nextMsg->name() << " extracted from queue" << endl;

	// Updating queue occupancy statistics
	iq->queueOccupancy.record(iq->queueAllocated);
	allQueueOccupancy.record(allQueueAllocated);

	// Saving the waiting time
	iq->queueTime.record(simTime() - nextMsg->arrivalTime());
	allQueueTime.record(simTime() - nextMsg->arrivalTime());
	
	return nextMsg;
}


/**
 * Put message at end of the queue
 */
void Server::insertMessageIntoQueue(InputKind *iq, cMessage * msg)
{
	// Checks if there is enough room in the queue to store the whole message
	if (queueSize - allQueueAllocated > msg->length()) {
		// Allocating room in the queues (traffic and global)
		iq->queueAllocated += msg->length();
		allQueueAllocated += msg->length();

		// Insert the message in the queue of messages
		queue->insert(msg);

		// Trace
		ev << "Inserting message " << msg->name() << " in queue" << endl;

		// Updating samples for the queue occupancy (traffic and global)
		iq->queueOccupancy.record(iq->queueAllocated);
		allQueueOccupancy.record(allQueueAllocated);

		// Update queued information 
		iq->bitsQueued += msg->length();
		iq->messagesQueued ++;
	} else {
		// There is no room for the message in the queue. Message lost.
		// Updating the scalar statistics for traffic lost
		iq->bitsLost += msg->length();
		iq->messagesLost ++;
		delete msg;
	}
}


/**
 * Select a free server processor and occupy it.
 */
Server::ServerProcessor *Server::selectServer(cMessage * msg) 
{
    if (numOfServersBusy == numOfServers) return 0;
    for (int i = 0; i < numOfServers; i++) {
	ServerProcessor *s = & servers[i];
	if (! s->serverBusy) {
	    numOfServersBusy ++;
	    s->serverBusy = true;
	    // Saving the occupancy
	    s->serverOccupancy.record(1);
	    allServerOccupancy.record(numOfServersBusy);
	    return s;
	}
    }
}


/**
 * Free an occupied server processor.
 */
void Server::freeServer(ServerProcessor *s) 
{
	numOfServersBusy--;
	s->serverBusy = false;
	// Saving the occupancy
	s->serverOccupancy.record(0);
	allServerOccupancy.record(numOfServersBusy);
}

