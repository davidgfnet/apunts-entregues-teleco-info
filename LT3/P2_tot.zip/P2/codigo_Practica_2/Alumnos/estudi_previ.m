
function pearson_test_exponential(v,n)
    % v mostres, n categories
    histo = hist(v,n);
    % V.A. exponencial, valor esperat = 1/num cat
    valor_esp = length(v)./n
    % Calcul
    resta = histo-valor_esp
    % Suma al cuadrat
    
    suma = 0;
    for i=1:n
        suma = suma + resta(i)*resta(i);
    end
    suma./valor_esp
end

function pearson_test_uniform(v,n)
    % v mostres, n categories
    histo = hist(v,n);
    % V.A. uniforme, valor esperat = 1/num cat
    valor_esp = length(v)./n
    % Calcul
    resta = histo-valor_esp
    % Suma al cuadrat
    
    suma = 0;
    for i=1:n
        suma = suma + resta(i)*resta(i);
    end
    suma./valor_esp
end

function estadistica( v )

    fprintf('Mitjana: %d\n',mean(v))
    fprintf('Mediana: %d\n',median(v))
    fprintf('Variança: %d\n',var(v));
    fprintf('Període: %d\n',seqperiod(v));

    %figure('Name','Correlació');
    %plot(xcorr(v))

    figure('Name','Histograma');
    %hist(v,100)
    t = hist(v,100);
    bar(t ./ max(t))

    %figure('Name','Dispersió 2D');
    %plot(v(1:length(v)-1),v(2:length(v)),'.')

    %figure('Name','Dispersió 3D');
    %plot3(v(1:length(v)-2),v(2:length(v)-1),v(3:length(v)),'.')

    figure('Name','histo-smooth');
    plot(ksdensity(v),'LineWidth',2)
end

function percent_test (v) 
    percent=[0.001,0.0025,0.005,0.01,0.025,0.05,0.1,0.15,0.2,0.25,0.3,0.35,0.4,0.45,0.5,0.55,0.6,0.65,0.7,0.75,0.8,0.85,0.9,0.95,0.975,0.99,0.995,0.9975,0.999];
    prctile(v,100-100*percent)
end

