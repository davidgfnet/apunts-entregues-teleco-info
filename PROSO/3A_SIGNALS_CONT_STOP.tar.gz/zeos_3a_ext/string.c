
#include <libc.h>

// Ultra simple printf!
void printf(const char *format, ...) {
	int * numbers = (int*)&format;
	char temp_buffer[32];
	
	while (*format != 0) {
		if (*format == '%') {
			format++;
			switch(*format) {
				case 'd':
					++numbers;
					itoa(*numbers,temp_buffer);
					write(1,temp_buffer,strlen(temp_buffer));
					break;
				case 'x':
					++numbers;
					itohex(*numbers,temp_buffer);
					write(1,temp_buffer,strlen(temp_buffer));
					break;
				default: break;
			};
		}
		else {
			write(1,(void*)format,1);
		}
		format++;
	}
}


