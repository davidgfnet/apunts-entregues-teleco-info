#include <libc.h>

void runjp();

int __attribute__ ((__section__(".text.main")))
  main(void)
{

  write(1,"HOLA 1\n",7);

  int bwritten = write(1,"HOLA 2\n",7);
  char tbuf[32];
  itoa(bwritten,tbuf);
  write(1,tbuf,1);

  // Generate breakpoint exception
  //asm(".byte 0xCC");
  // Generate a page fault exception
  //*((char*)0x0) = 1;

  runjp();

  while(1);
  return 0;
}


