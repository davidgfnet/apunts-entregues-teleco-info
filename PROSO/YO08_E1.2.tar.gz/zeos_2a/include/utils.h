#ifndef UTILS_H
#define UTILS_H

void copy_data(void *start, void *dest, int size);
int copy_from_user(void *start, void *dest, int size);
int copy_to_user(void *start, void *dest, int size);
void itoa(int num, char *buffer);
void itohex(unsigned int num, char *buffer);
int strlen (char * str);

#endif
