/*
 * sys.c - Syscalls implementation
 */

#include <devices.h>
int sys_write(int fd,char *buffer, int size)
{
	return 0;
}

