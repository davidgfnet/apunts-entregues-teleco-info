/*
 * libc.c 
 */

#include <libc.h>

/* Wrapper of  write system call*/
int write(int fd,char *buffer,int size)
{
	return 0;
}

