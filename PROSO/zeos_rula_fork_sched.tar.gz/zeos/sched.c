/*
 * sched.c - initializes struct for task 0
 */

#include <sched.h>
#include <mm.h>

int pid_number_counter = 0;
struct list_head * runqueue;

struct protected_task_struct task[NR_TASKS]
  __attribute__((__section__(".data.task")));

/* Erases all the process table
   and sets the default values. 
   Also inits the runqueue */
void initialize_tasks()
{
  int i;
  for (i = 0; i < NR_TASKS; i++)
  {
    task[i].t.task.pid = -1;
    task[i].t.task.quantum = INITIAL_QUANTUM;
    INIT_LIST_HEAD(&task[i].t.task.plist);
  }
  task[0].t.task.pid = 0;
  runqueue = &task[0].t.task.plist;
  // The task 0 has the code and data pages following the kernel pages
  for (i = 0; i < NUM_PAG_DATA; i++)
  {
    task[0].t.task.phy_data_pages[i] = NUM_PAG_KERNEL+NUM_PAG_CODE+i;
  }
}

void init_task0(void)
{
  /* Initializes paging for the process 0 adress space */
  initialize_P0_frames();
  set_user_pages();
  set_cr3();

  initialize_tasks();
}

/* Checks if a process change is needed and then
   changes the logical address mapping to the process
   Returns the kernel stack base pointer (for TSS)
   so it can be updated
*/
int rotate_processes()
{
  int i;
  // Check if the quantum has expired!
  struct task_struct * curr_task;  // The task we are stopping
  current_task_addr(curr_task);
  if ((--curr_task->quantum) <= 0)
  {
    curr_task->quantum = INITIAL_QUANTUM;
    // Save the process state!!!
    int * stack_bottom;
    __asm__ volatile (
    "movl %%ebp,%0\n"
    // 2 * ret@ + ebp
    // + 16 register (bottom!!!)
    "addl $((3+16)*4),%0\n"
    :"=r"(stack_bottom));
    for (i = 0; i < 16; i++) {
      stack_bottom--;
      curr_task->saved_state[i] = *stack_bottom;
    }

    // Change to the next process
    runqueue = curr_task->plist.next;
    curr_task = (struct task_struct *)runqueue;
    // Change the page mappings
    for (i = 0; i < NUM_PAG_DATA; i++)
    {
      set_ss_pag(((L_USER_START+NUM_PAG_CODE*0x1000)>>12)+i,((struct task_struct *)runqueue)->phy_data_pages[i]);
    }
    set_cr3();
    return (int)(curr_task);
  }
  return 0;
}


