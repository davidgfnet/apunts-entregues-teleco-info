/*
 * sys.c - Syscalls implementation
 */

#include <devices.h>
#include <io.h>
#include <utils.h>
#include <errno.h>
#include <sched.h>
#include <sys.h>
#include <list.h>
#include <mm.h>

extern struct protected_task_struct task[NR_TASKS];
extern int pid_number_counter;
extern struct list_head * runqueue;

// Comprovador de decriptor de canal
// caldrà modificar-lo ja que ha de comprar l'existència del canal
int comprova_fd(int fd, int operacio)
{
  return (fd == 1 && operacio == WRITING);
}

/* Write syscall. Currently just writes to stdout or stderr (screen) */
/* TODO: Check if the buffer pointer is a valid user address */
int sys_write(int fd,char *buffer, int size)
{
  if (buffer == 0) return -EFAULT;
  if (size < 0) return -EINVAL;

  if (comprova_fd(fd,WRITING))
  {
    // Not memory enough to coyp the data (page fault by stack overflow)
    //char tempo_buffer[size];
    //copy_from_user(buffer,tempo_buffer,size);
    sys_write_console (buffer, size);
  }
  else
    return -EBADF;

  return size;
}

int sys_getpid()
{
  struct task_struct * curr_task;
  current_task_addr(curr_task);
  return curr_task->pid;
}

int sys_fork()
{
  union task_union * curr_task;
  current_task_addr(curr_task);

  // Create a new process but continue executing the parent
  int i; int free_task = -1;
  // Search for a free task slot
  for (i = 0; i < NR_TASKS; i++)
  {
    if (task[i].t.task.pid == -1)
    {
      free_task = i; break;
    }
  }
  if (free_task == -1) return -ENOMEM;

  // Copy all the PCB + kernel stack
  copy_data((void*)curr_task,((void*)&task[free_task].t),sizeof(union task_union));

  // Copy the current register status to the PCB's register bank
  int * stack_bottom;
  __asm__ volatile (
  "movl %%ebp,%0\n"
  // Five params (ebx..%edi) + ret@ + ebp
  // + 16 register (bottom!!!)
  "addl $((5+2+16)*4),%0\n"
  :"=r"(stack_bottom));
  for (i = 0; i < 16; i++) {
    stack_bottom--;
    task[free_task].t.task.saved_state[i] = *stack_bottom;
  }
  task[free_task].t.task.saved_state[9] = 0; // EAX is 0 for the children process

  // Set the pid, the quantum and add it to the runqueue
  task[free_task].t.task.pid = (++pid_number_counter);
  task[free_task].t.task.quantum = INITIAL_QUANTUM;
  list_add_tail(&task[free_task].t.task.plist,runqueue);

  // Now reserve some physical pages for the data and save those page numbers in the PCB
  for (i = 0; i < NUM_PAG_DATA; i++)
  {
    task[free_task].t.task.phy_data_pages[i] = alloc_frame();
  }

  // Finally copy the data pages, to do that we need to map
  // the new process data block in to unused logical addresses
  for (i = 0; i < NUM_PAG_DATA; i++)
  {
    set_ss_pag((AUXILIAR_LOGIC_ZONE>>12)+i,task[free_task].t.task.phy_data_pages[i]);
  }
  // Flush the TLB before accessing the new mapped pages
  set_cr3();
  copy_data((void*)(L_USER_START+NUM_PAG_CODE*0x1000),(void*)AUXILIAR_LOGIC_ZONE,NUM_PAG_DATA*0x1000);
  // Now remove the mapping and flush TLB
  for (i = 0; i < NUM_PAG_DATA; i++)
  {
    del_ss_pag(AUXILIAR_LOGIC_ZONE>>12);
  }
  set_cr3();

  return pid_number_counter;
}

/* Empty function for empty syscalls */
int sys_ni_syscall()
{
  return -ENOSYS;
}


