#include <libc.h>

void runjp();

int __attribute__ ((__section__(".text.main")))
  main(void)
{
/*
  int bwritten = write(1,"HOLA 2\n",7);
  char tbuf[32];
  itoa(bwritten,tbuf);
  write(1,tbuf,1);

  // Generate breakpoint exception
  //asm(".byte 0xCC");
  // Generate a page fault exception
  //*((char*)0x0) = 1;

//  runjp();

  write(1,"\nMY PID IS: ",12);
  int pid = getpid();
  itoa(pid,tbuf);
  write(1,tbuf,1);
*/

  write(1,"\nHOLA 2\n",8);

  if (fork() == 0) {
    write(1,"HIJO\n",5);
  }else{
    write(1,"PADRE\n",6);
  }

  while(1);
  return 0;
}


