#include <libc.h>

void runjp();

int __attribute__ ((__section__(".text.main")))
  main(void)
{

  /* STRESS TEST
  while (1) {
    if (fork() == 0) {
      char tempb[32];
      write(1,"\nSTRESS TEST\nMY PID IS: ",26);
      itoa(getpid(),tempb);
      write(1,tempb,strlen(tempb));
      exit();
    }
  }
  */


/* // DEMO SIGNALS, 2 PROCESSES WAITING SAME SEMAPHORE
  sem_init(1,0);
  write(1,"HOLA\n",5);
  if (fork() == 0) {
    fork();
    sem_wait(1);
  }else{
    int i,j;
    for (j = 0; j < 2; j++) {
    for (i = 0; i < 10000000; i++)
       __asm__ __volatile__ ("nop");
    sem_signal(1);
    write(1,"SIGN\n",5);
    }
    while(1);
  }

  if (fork() == 0) {
    write(1,"HIJO\n",5);
  }else{
    write(1,"PADRE\n",6);
  }
*/

/*
 //DEMO SIGNALS, 2 PROCESSES WAITING SAME SEMAPHORE, DESTROY
  sem_init(1,0);
  write(1,"HOLA\n",5);
  if (fork() == 0) {
    fork();
    sem_wait(1);
  }else{
    int i;
    for (i = 0; i < 10000000; i++)
       __asm__ __volatile__ ("nop");
    sem_destroy(1);
    write(1,"SIGN\n",5);
    while(1);
  }

  if (fork() == 0) {
    write(1,"HIJO\n",5);
  }else{
    write(1,"PADRE\n",6);
  }
*/

  exit();
  return 0;
}


