*** Aquest paquet conté els següents fitxers:

* Proves per al codi de la primera entrega (libjp1.a)
* Proves per al codi de la segona entrega (libjp2.a)
* Proves per al codi de la tercera entrega (libjpopen.a, libjpclose.a,libjpwrite.a, libjpread.a, libjpdup.a, libjpunlink.a)
* README_E2.txt: per a cada prova de la segona entrega, especifica quines funcions necessita que funcionin correctament
* README_E3.txt: per a cada prova de la tercera entrega, especifica quines funcions necessita que funcionin correctament

*** Instruccions d'us:

* Al Makefile assegureu-vos que el vostre user s'enllaça amb
el fitxer libjp.a que ha de ser un soft link a la llibreria que voleu testejar en cada moment (libjp1.a o libjp2.a, libjopen.a, etc.). Per fer-ho afegiu aquest fitxer a la variable USROBJ.
* Per a que el joc de proves funcioni correctament és
necessari que utilitzeu el .bochsrc que us donem (les
instruccions per segon de la màquina virtual, ips, han de
ser les que us donem al fitxer original)
* Al main del user.c heu de cridar la rutina runjp().
Tingueu en compte que només es pot executar un joc de proves
a la vegada.
* Tingueu en compte que és un joc de proves incremental. Es
a dir, si una prova falla no està garantit que la resta de
proves s'executin correctament.
* Per a veure correctament tots els missatges de les proves
haurieu de tenir habilitat a Bochs l'escriptura per la consola (això ja 
està fet al Bochs que executeu a la imatge del laboratori).
* Teniu l'opció d'executar un rang de proves separadament en lloc de totes a la vegada. Per això, heu de substituir la crida 'runjp()' de l'user.c per la crida 'runjp_rank( int primera, int ultima )', que té per paràmetres els identificadors de la primera i última proves del rang a executar.
