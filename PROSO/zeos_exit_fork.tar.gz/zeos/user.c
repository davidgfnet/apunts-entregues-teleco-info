#include <libc.h>

void runjp();

int __attribute__ ((__section__(".text.main")))
  main(void)
{

  while (1) {
    if (fork() == 0) {
      char tempb[32];
      write(1,"\nSTRESS TEST\nMY PID IS: ",26);
      itoa(getpid(),tempb);
      write(1,tempb,strlen(tempb));
      exit();
    }
  }

  fork();
  fork();

  write(1,"\nHOLA 2\n",8);

  if (fork() == 0) {
    write(1,"HIJO\n",5);
  }else{
    exit();
    write(1,"PADRE\n",6);
  }

  while(1);
  return 0;
}


