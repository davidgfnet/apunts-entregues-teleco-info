/*
 * sys.c - Syscalls implementation
 */

#include <devices.h>
#include <io.h>
#include <utils.h>

/* Write syscall. Currently just writes to stdout or stderr (screen) */
/* TODO: Check if the buffer pointer is a valid user address */
int sys_write(int fd,char *buffer, int size)
{
  if (buffer == 0) return -1;
  if (size <= 0) return -1;
  char temp_buf[size+1];

  switch (fd) {
  case 1:
  case 2:
    copy_data(buffer,temp_buf,size);
    temp_buf[size] = 0;
    printk(temp_buf);
    break;
  default: return -1; break;
  };

  return size;
}

/* Empty function for empty syscalls */
int sys_ni_syscall()
{

}


