int sys_write_console(char *buffer,int size)
{
	return 0;
}
