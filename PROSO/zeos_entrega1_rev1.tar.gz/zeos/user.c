#include <libc.h>

/*
Versió fent ús de l'entrada sortida del inline assembly
   0:	55                   	push   %ebp
   1:	89 e5                	mov    %esp,%ebp
   3:	8b 55 0c             	mov    0xc(%ebp),%edx
   6:	8b 45 08             	mov    0x8(%ebp),%eax
   9:	89 c0                	mov    %eax,%eax
   b:	01 c2                	add    %eax,%edx
   d:	5d                   	pop    %ebp
   e:	c3                   	ret    
   f:	90                   	nop
*/
int add2(int par1,int par2) {
  int resultado;
  __asm__ __volatile__ (
  "movl %1,%0\n"
  "add  %0,%2\n"
  :"=r"(resultado):"r"(par1),"r"(par2));
  return resultado;
}

/*
Versió fent servir només assemblador
   0:	55                   	push   %ebp
   1:	89 e5                	mov    %esp,%ebp
   3:	8b 45 08             	mov    0x8(%ebp),%eax
   6:	8b 4d 0c             	mov    0xc(%ebp),%ecx
   9:	01 c8                	add    %ecx,%eax
   b:	5d                   	pop    %ebp
   c:	c3                   	ret    
   d:	8d 76 00             	lea    0x0(%esi),%esi
*/
int add1(int par1,int par2) {
	__asm__ __volatile__ (
	"mov    8(%ebp),%eax\n"
	"mov    12(%ebp),%ecx\n"
	"add  %ecx,%eax\n"
	);
}

long inner(long n)
{
  int i;
  long suma;
  suma = 0;
  for (i=0; i<n; i++) suma = suma + i;
  return suma;
}
long outer(long n)
{
  int i;
  long acum;
  acum = 0;
  for (i=0; i<n; i++) acum = acum + inner(i);
  return acum;
}

int __attribute__ ((__section__(".text.main")))
  main(void)
{

//	int suma1 = add1(123,-12);
//	int suma2 = add2(123,-12);

//	long count, acum;
//	count = 75;
//	acum = 0;
//	acum = outer(count);

  write(1,"HOLA 1\n",7);

  int bwritten = write(1,"HOLA 2\n",7);
  char tbuf[32];
  itoa(bwritten,tbuf);
  write(1,tbuf,1);

  // Generate breakpoint exception
  asm(".byte 0xCC");

  while(1);
  return 0;
}


