/*
 * io.c - 
 */

#include <io.h>
#include <sys.h>
#include <utils.h>
#include <errno.h>

// The devices
struct file_operations device_operations[NUM_DEVICES_TYPE] = {
  {zeosfat_read,zeosfat_write,O_RDWR},
  {0,console_write,O_WRONLY},
  {0,0,O_RDONLY}
 };

// ZeOS FAT 

// The data itself
char zeosfat_data[MAX_BLOCKS][256];
// The FAT (indicates the next block)
int zeosfat_fat[MAX_BLOCKS];
// The directory of the FS
struct dir_entry zeosfat_directory[MAX_FILES];

int initZeOSFat(void)
{
  int i;
  for (i = 0; i < MAX_FILES; i++)
    zeosfat_directory[i].used = -1; // Empty!

  for (i = 0; i < MAX_BLOCKS; i++)
    zeosfat_fat[i] = ZEOS_FAT_NOT_USED;

  return 0;
}

int fat_find_unused_block()
{
  int i;
  for (i = 0; i < MAX_BLOCKS; i++)
    if (zeosfat_fat[i] == ZEOS_FAT_NOT_USED)
      return i;
  return -1; // Not enough space
}

int zeosfat_create(const char * name, int type)
{
  int i;
  for (i = 0; i < MAX_FILES; i++)
    if (zeosfat_directory[i].used < 0)
      {
        int block = fat_find_unused_block();
        if (block < 0) return -1;   // The disk is full! No more free blocks!
        zeosfat_directory[i].start_block = block;
        zeosfat_directory[i].used = 0; // Used, but any process accessing
        zeosfat_directory[i].size = 0;
        zeosfat_directory[i].type = type;
        copy_data((void*)name,&zeosfat_directory[i].filename[0],FILE_NAME_SIZE+1);
        return 0;
      }

  return -1;  // The directory is full!
}

int zeosfat_close(struct file_descriptor_struct * fd)
{
  // Just decrease the count!
  zeosfat_directory[fd->fileid].used--;
  return 0;
}

int zeosfat_open (const char * name, int flags, struct file_descriptor_struct * fd)
{
  int i;
  for (i = 0; i < MAX_FILES; i++)
    if (zeosfat_directory[i].used >= 0)
      if (strcmp(name,zeosfat_directory[i].filename) == 0)
        {
          if ((flags & O_CREAT) != 0 && (flags & O_EXCL) != 0)
          {
            // Trying to overwrite the file, error!
             return -EEXIST;
          }

          // Trying to Read an unreadable device?
          if ((flags&O_RDONLY) != 0 && (device_operations[zeosfat_directory[i].type].rw&O_RDONLY) == 0) return -EACCES;
          // Trying to Write an unwritable device?
          if ((flags&O_WRONLY) != 0 && (device_operations[zeosfat_directory[i].type].rw&O_WRONLY) == 0) return -EACCES;

          // Found the file, proceed to fill the File Descriptor
          fd->curr_position = 0;
          fd->mode = flags & 0x3; // R/W bits
          fd->fileid = i;
          fd->file_op = &device_operations[zeosfat_directory[i].type];
          zeosfat_directory[i].used++;
          return 0;
        }

  if ((flags & O_CREAT) != 0)
  {
    if ((flags & O_EXCL) == 0)
    {
      // Create the file!!!
      int ret_code = zeosfat_create(name,TYPE_FILE);
      if (ret_code < 0) return ret_code; // Couldn't create the file!
      return zeosfat_open (name, flags, fd); // Now open the file (it DOES exits)
    }
    else
    {
      // Trying to create a file but exists!
      return -EEXIST;
    }
  }

  return -ENOFILE;  // File does not exists!
}


int zeosfat_read (struct file_descriptor_struct * fd, char *buffer, int size)
{
  int curr_block = zeosfat_directory[fd->fileid].start_block;
  int pos = fd->curr_position;
  if (fd->curr_position >= zeosfat_directory[fd->fileid].size) return 0; // EOF
  // We don't want to read more than the file size
  if (zeosfat_directory[fd->fileid].size - pos < size) size = zeosfat_directory[fd->fileid].size - pos;

  // Seek to the block!
  int inpos = pos & 0xFF; // (% 256)
  while (pos >= 256)
  {
    // Go to the next block
    curr_block = zeosfat_fat[curr_block];
    pos = pos - 256;
  }
  
  // Start reading
  int bytes_read = 0;
  while (size > 0) {
    int can_copy = intmin(256-inpos,size);    
    copy_data(&zeosfat_data[curr_block][pos],buffer,can_copy);

    buffer += can_copy;
    size -= can_copy;
    fd->curr_position += can_copy;
    bytes_read += can_copy;
    inpos = (inpos + can_copy) & 0xFF; // (%256)
    curr_block = zeosfat_fat[curr_block];
  }

  return bytes_read;
}

int zeosfat_write (struct file_descriptor_struct * fd, char *buffer, int size)
{
  int curr_block = zeosfat_directory[fd->fileid].start_block;
  int pos = fd->curr_position;

  // Seek to the block and create new blocks if the position
  // is after the current position!
  int inpos = pos & 0xFF; // (% 256)
  while (pos >= 256)
  {
    // Go to the next block
    int nextb = zeosfat_fat[curr_block];
    if (nextb == ZEOS_FAT_EOF) {
      // Allocate new block!
      int newblock = fat_find_unused_block();
      if (newblock == -1) return -1; // Not enough space!
      zeosfat_fat[curr_block] = newblock;
      zeosfat_fat[newblock] = ZEOS_FAT_EOF;
      nextb = newblock;
    }
    curr_block = nextb;
    pos = pos - 256;
  }

  int bytes_written = 0;
  while (size > 0) {
    int can_copy = intmin(256-inpos,size);    
    copy_data(buffer,&zeosfat_data[curr_block][pos],can_copy);

    buffer += can_copy;
    size -= can_copy;
    fd->curr_position += can_copy;
    bytes_written += can_copy;
    inpos = (inpos + can_copy) & 0xFF; // (%256)
    
    int nextb = zeosfat_fat[curr_block];
    if (nextb == ZEOS_FAT_EOF) {
      // Allocate new block!
      int newblock = fat_find_unused_block();
      if (newblock == -1) return -1; // Not enough space!
      zeosfat_fat[curr_block] = newblock;
      zeosfat_fat[newblock] = ZEOS_FAT_EOF;
      nextb = newblock;
    }
    curr_block = nextb;
  }

  return bytes_written;
}

// DEVICES

int sys_open_screen (const char * name, int flags);
int sys_close_screen (int fd);

int sys_open_keyboard (const char * name, int flags) { return 0; }
int sys_close_keyboard (int fd) { return 0; }


int sys_read_keyboard (int fd, char *buffer, int size);
int sys_write_screen (int fd, char *buffer, int size);

int sys_open_file (const char * name, int flags);
int sys_close_file (int fd);
int sys_read_file (int fd, char *buffer, int size);
int sys_write_file (int fd, char *buffer, int size);


/**************/
/** Screen  ***/
/**************/

#define NUM_COLUMNS 80
#define NUM_ROWS    25

Byte x=0, y=0;

/* Read a byte from 'port' */
Byte inb (unsigned short port)
{
  Byte v;

  __asm__ __volatile__ ("inb %w1,%0":"=a" (v):"Nd" (port));
  return v;
}

void printc(char c)
{
  Word ch = (Word) (c & 0x00FF) | 0x0200;
  DWord screen = 0xb8000 + (y * NUM_COLUMNS + x) * 2;
   __asm__ __volatile__ ( "movb %0, %%al; outb $0xe9" ::"a"(c));
  if (++x >= NUM_COLUMNS)
  {
    x = 0;
    if (++y >= NUM_ROWS)
      y = 0;
  }
  __asm__ __volatile__("movw %0, (%1)" : : "g"(ch), "g"(screen));
}

void printk(char *string)
{
  int i;
  for (i = 0; string[i]; i++) {
    if (string[i] == '\n')
    {
      y++;
      x = 0;
      // Check if the screen is full and scroll it up!
      if (y == NUM_ROWS)
      {
        scroll_screen();
        y = NUM_ROWS-1;
      }
    }
    else
    {
      printc(string[i]);
    }
  }
}

/* Scrolls the screen by deleting the first line and moving all the lines up */
void scroll_screen()
{
  unsigned short * prev_line = (unsigned short*)0xb8000;
  unsigned short * next_line = prev_line+NUM_COLUMNS;
  int ly;
  for (ly = 1; ly < NUM_ROWS; ly++)
  {
    int lx;
    for (lx = 0; lx < NUM_COLUMNS; lx++)
    {
      *prev_line++ = *next_line++;
    }
  }
  // Empty the last line
  int lx;
  for (lx = 0; lx < NUM_COLUMNS; lx++)
  {
    *prev_line++ = 32;
  }  
}

/* Empties all the screen */
void screen_clear()
{
  x = 0; y = 0;
  unsigned short * video_mem = (unsigned short*)0xb8000;
  int i;
  for (i = 0; i < NUM_COLUMNS*NUM_ROWS; i++)
  {
	  // Fill the screen with spaces
	  *video_mem++ = 32;
  }
}

/* Prints the character c in (x,y) position */
void printc_xy(int x,int y,char c)
{
  short * screen = (short*)(0xb8000 + (y * NUM_COLUMNS + x) * 2);
  *screen = (short)((0xFF & c) | 0x0f00 );
}

/* Prints the string s in (x,y) position */
void printf_xy(int x,int y,char * s)
{
  short * screen = (short*)(0xb8000 + (y * NUM_COLUMNS + x) * 2);
  while (*s != 0)
    *screen++ = (short)((0xFF & *s++) | 0x0f00 );
}


