
#define NUM_COLUMNS 80
#define NUM_ROWS    25

#include <io.h>
#include <devices.h>
#include <sched.h>
#include <fat.h>

// Keyboard Buffer
struct keyboard_fifo kbd_buffer;

// The devices
struct file_operations device_operations[NUM_DEVICES_TYPE] = {
  {zeosfat_read,zeosfat_write,O_RDWR},
  {0,console_write,O_WRONLY},
  {keyboard_read,0,O_RDONLY}
 };

// Inits the KBD FIFO
void InitializeDevices()
{
  kbd_buffer.valid_data = 0;
  kbd_buffer.read_ptr = 0;
  kbd_buffer.write_ptr = 0;
}


int console_write (struct file_descriptor_struct * fd, char *buffer, int size)
{
  return sys_write_console(buffer,size);
}


int keyboard_read (struct file_descriptor_struct * fd, char *buffer, int size)
{
  struct task_struct * curr_task;
  current_task_addr(curr_task);
  if (curr_task->pid == 0) return -1;
  if (size > KEYBOARD_BUFFER_SIZE) size = KEYBOARD_BUFFER_SIZE;

  // Check if there is enough data and no one is waiting
  if (keyboardqueue == 0)
  {
    if (kbd_buffer.valid_data >= size) {
      // Just copy the data, no need to block the process!
      int i;
      for (i = 0; i < size; i++)
      {
        *buffer++ = kbd_buffer.buffer[kbd_buffer.read_ptr];
        kbd_buffer.read_ptr = (kbd_buffer.read_ptr + 1)%KEYBOARD_BUFFER_SIZE;
      }
      kbd_buffer.valid_data -= size;
      return size;
    }
    else
    {
      // No one waiting, I'm the unique process!
      curr_task->req_kb_bytes = size;
      curr_task->req_kb_buffer = buffer;
      runqueue = curr_task->plist.next;
      keyboardqueue = (struct list_head *)curr_task;
      list_del(&curr_task->plist);
      INIT_LIST_HEAD(&curr_task->plist);
      task_switch((union task_union*)runqueue); // Jump to next process
      return 0;
    }
  }
  else
  {
    // Add to queue
    curr_task->req_kb_bytes = size;
    curr_task->req_kb_buffer = buffer;
    runqueue = curr_task->plist.next;
    list_del(&curr_task->plist);
    list_add_tail(&curr_task->plist,keyboardqueue);
    task_switch((union task_union*)runqueue); // Jump to next process
    return 0;
  }

  return 0;
}




extern Byte x,y;

int sys_write_console (char *buffer, int size)
{
  int i;
  for (i = 0; i < size; i++) {
    if (buffer[i] == '\n')
    {
      y++;
      x = 0;
      // Check if the screen is full and scroll it up!
      if (y == NUM_ROWS)
      {
        scroll_screen();
        y = NUM_ROWS-1;
      }
    }
    else
    {
      short ch = (short) (buffer[i] & 0x00FF) | 0x0F00;
      short * screen = (short*)(0xb8000 + (y * NUM_COLUMNS + x) * 2);
      *screen = ch;
      x++;
      if (x >= NUM_COLUMNS)
      {
        x = 0;
        y++;
        if (y == NUM_ROWS)
        {
          scroll_screen();
          y = NUM_ROWS-1;
        }
      }
    }
  }  
  return size;
}


