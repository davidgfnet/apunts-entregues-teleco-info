/*
 * io.h - Definició de l'entrada/sortida per pantalla en mode sistema
 */

#ifndef __IO_H__
#define __IO_H__

#include <types.h>
#include <mm_address.h>

/** Screen functions **/
/**********************/

Byte inb (unsigned short port);
void printc(char c);
void printk(char *string);
void screen_clear(void);
void printc_xy(int x,int y,char c);
void printf_xy(int x,int y,char * s);
void scroll_screen();

/**** KEYBOARD ****/
#define KEYBOARD_BUFFER_SIZE  16
struct keyboard_fifo {
  unsigned char buffer [KEYBOARD_BUFFER_SIZE];
  int read_ptr;
  int write_ptr;
  int valid_data;
};
extern struct keyboard_fifo kbd_buffer;

// FILE DESCRIPTORS AND DEVICE DESCRIPTORS //
#define     O_RDONLY   0x1
#define     O_WRONLY   0x2
#define     O_RDWR     (O_RDONLY | O_WRONLY)
#define     O_CREAT    0x4
#define     O_EXCL     0x8

#define     NUM_DEVICES_TYPE  3

#define     TYPE_FILE      0x0
#define     TYPE_SCREEN    0x1
#define     TYPE_KEYBOARD  0x2

struct file_descriptor_struct;
struct file_operations {
  // Pointer to the specific functions of the device
  int (*read) (struct file_descriptor_struct * fd, char *buffer, int size);
  int (*write) (struct file_descriptor_struct * fd, char *buffer, int size);
  int rw;           // If the devices is readable/writable
};

extern struct file_operations device_operations[NUM_DEVICES_TYPE];

struct file_descriptor_struct {
  int curr_position;        // In a seekable stream, the position, otherwise -1
  int mode;                 // Read, write, etc
  int fileid;               // The id to pass the specific functions
  struct file_operations * file_op; // Pointer to the device descriptor

  int entry_usage; // Indicates the entry usage (may be shared by father and child)
};
extern struct file_descriptor_struct system_fd[NR_FD_SYSTEM];

int sys_open_file (const char * name, int flags);
int sys_close_file (int fd);
int sys_read_file (int fd, char *buffer, int size);
int sys_write_file (int fd, char *buffer, int size);

int sys_open_screen (const char * name, int flags);
int sys_close_screen (int fd);
int sys_write_screen (int fd, char *buffer, int size);

int sys_open_keyboard (const char * name, int flags);
int sys_close_keyboard (int fd);
int sys_read_keyboard (int fd, char *buffer, int size);

// ZEOS FAT // 

#define MAX_BLOCKS          128
#define ZEOS_FAT_EOF        0xFFFFFFFF
#define ZEOS_FAT_NOT_USED   0xFFFFFFFE
#define MAX_FILES           10
#define FILE_NAME_SIZE      10
extern char zeosfat_data[MAX_BLOCKS][256];
extern int zeosfat_fat[MAX_BLOCKS];
struct dir_entry {
  int used;                          // Entry being used by any process, if its empty value = -1
  char filename[FILE_NAME_SIZE+1];   // File name
  unsigned int start_block;          // The first block containing data
  int size;                          // The size of the file
  int type;                          // The file type (remember it can be a device!)
};
extern struct dir_entry zeosfat_directory[MAX_FILES];

int initZeOSFat(void);

// Creates a file in the FAT system of a given type
int zeosfat_create(const char * name, int type);
// Opens a file and fills the descriptor
int zeosfat_open (const char * name, int flags, struct file_descriptor_struct * fd);
// Reads data from the file
int zeosfat_read (struct file_descriptor_struct * fd, char *buffer, int size);
// Writes data to the file
int zeosfat_write (struct file_descriptor_struct * fd, char *buffer, int size);
// Closes the file
int zeosfat_close(struct file_descriptor_struct * fd);
// Deletes a file
int zeosfat_delete(const char * name);

#endif  /* __IO_H__ */

