/*
 * sys.c - Syscalls implementation
 */

#include <devices.h>
#include <io.h>
#include <utils.h>
#include <errno.h>
#include <sched.h>
#include <stats.h>
#include <sys.h>
#include <list.h>
#include <mm.h>
#include <mm_address.h>

extern struct protected_task_struct task[NR_TASKS];
extern int pid_number_counter;
extern struct list_head * runqueue;

// Checks if a pointer is inside the User logical space
int comprova_usr_ptr(int init, int size) {
  return !(init < L_USER_START || (init+size) > USER_END);
}

int sys_open(const char *path, int flags)
{
  if (!comprova_usr_ptr((int)path,FILE_NAME_SIZE+1)) return -EFAULT;
  if (strlen(path) > 10) return -ENAMETOOLONG; // Name too long!
  char * fname = (char*)path;
  if (*fname == '/') fname++; // Remove the directory
  if ((flags & O_RDWR) == 0) return -EINVAL;
  if ((flags & (~(0xF))) != 0) return -EINVAL;

  struct task_struct * curr_task;
  current_task_addr(curr_task);

  // Search for a free channel in the PCB
  int i;
  for (i = 0; i < NR_FD; i++)
  {
    if (curr_task->file_descriptors[i].file_op == 0)
    {
      int ret_val = zeosfat_open (fname, flags, &curr_task->file_descriptors[i]);
      if (ret_val < 0) return ret_val;
      return i;
    }
  }
  return -EMFILE;
}

int sys_close(int fd)
{
  if (fd < 0 || fd >= NR_FD) return -EBADF;
  struct task_struct * curr_task;
  current_task_addr(curr_task);
  if (curr_task->file_descriptors[fd].file_op == 0) return -EBADF;

  return zeosfat_close(&curr_task->file_descriptors[fd]);
}

int sys_read(int fd,char *buffer, int size)
{
  if (size < 0) return -EINVAL;
  if (size == 0) return 0;
  if (fd < 0 || fd >= NR_FD) return -EBADF;
  struct task_struct * curr_task;
  current_task_addr(curr_task);
  if (curr_task->file_descriptors[fd].file_op == 0) return -EBADF;
  if (!comprova_usr_ptr((int)buffer,size)) return -EFAULT;

  if (curr_task->file_descriptors[fd].file_op->read == 0) return -EBADF;
  return (curr_task->file_descriptors[fd].file_op->read)(&curr_task->file_descriptors[fd],buffer,size);
}

int sys_write(int fd,char *buffer, int size)
{
  if (size < 0) return -EINVAL;
  if (size == 0) return 0;
  if (fd < 0 || fd >= NR_FD) return -EBADF;
  struct task_struct * curr_task;
  current_task_addr(curr_task);
  if (curr_task->file_descriptors[fd].file_op == 0) return -EBADF;
  if (!comprova_usr_ptr((int)buffer,size)) return -EFAULT;

  if (curr_task->file_descriptors[fd].file_op->write == 0) return -EBADF;
  return (curr_task->file_descriptors[fd].file_op->write)(&curr_task->file_descriptors[fd],buffer,size);
}

int sys_unlink (const char * name)
{
  if (!comprova_usr_ptr((int)name,FILE_NAME_SIZE+1)) return -EFAULT;
  if (strlen(name) > 10) return -ENAMETOOLONG; // Name too long!
  char * fname = (char*)name;
  if (*fname == '/') fname++; // Remove the directory

  return zeosfat_delete(name);
}

int sys_dup(int fd)
{
  if (fd < 0 || fd >= NR_FD) return -EBADF;
  struct task_struct * curr_task;
  current_task_addr(curr_task);
  if (curr_task->file_descriptors[fd].file_op == 0) return -EBADF; // Unused channel!

  // Search for a free channel in the PCB
  int i;
  for (i = 0; i < NR_FD; i++)
  {
    if (curr_task->file_descriptors[i].file_op == 0)
    {
      // Free channel! Copy the data and mark usage +1
      curr_task->file_descriptors[i] = curr_task->file_descriptors[fd];
      zeosfat_directory[curr_task->file_descriptors[i].fileid].used++;
      return i;
    }
  }
  return -EMFILE;
}

int sys_getpid()
{
  struct task_struct * curr_task;
  current_task_addr(curr_task);
  return curr_task->pid;
}

int sys_fork()
{
  union task_union * curr_task;
  current_task_addr(curr_task);

  // Create a new process but continue executing the parent
  int i; int free_task = -1;
  // Search for a free task slot
  for (i = 0; i < NR_TASKS; i++)
  {
    if (task[i].t.task.pid == -1)
    {
      free_task = i; break;
    }
  }
  if (free_task == -1) return -ENOMEM;

  // Copy all the PCB + kernel stack
  copy_data((void*)curr_task,((void*)&task[free_task].t),sizeof(union task_union));
  task[free_task].t.saved_regs.eax = 0;  // Modify eax for the child 

  // Set the pid, the quantum and add it to the runqueue
  task[free_task].t.task.pid = (++pid_number_counter);
  task[free_task].t.task.p_stats.remaining_tics = task[free_task].t.task.init_quantum;
  task[free_task].t.task.p_stats.total_trans = 0;
  task[free_task].t.task.p_stats.total_tics = 0;

  // Duplicate the channels, just add +1 to the fat usage!
  for (i = 0; i < NR_FD; i++)
    if (task[free_task].t.task.file_descriptors[i].file_op != 0)
      zeosfat_directory[task[free_task].t.task.file_descriptors[i].fileid].used++;

  list_add_tail(&task[free_task].t.task.plist,runqueue);

  // Now reserve some physical pages for the data and save those page numbers in the PCB
  for (i = 0; i < NUM_PAG_DATA; i++)
  {
    task[free_task].t.task.phy_data_pages[i] = alloc_frame();
  }

  // Finally copy the data pages, to do that we need to map
  // the new process data block in to unused logical addresses
  for (i = 0; i < NUM_PAG_DATA; i++)
  {
    set_ss_pag((AUXILIAR_LOGIC_ZONE>>12)+i,task[free_task].t.task.phy_data_pages[i]);
  }
  // Flush the TLB before accessing the new mapped pages
  set_cr3();
  copy_data((void*)(L_USER_START+NUM_PAG_CODE*0x1000),(void*)AUXILIAR_LOGIC_ZONE,NUM_PAG_DATA*0x1000);
  // Now remove the mapping and flush TLB
  for (i = 0; i < NUM_PAG_DATA; i++)
  {
    del_ss_pag((AUXILIAR_LOGIC_ZONE>>12)+i);
  }
  set_cr3();

  return pid_number_counter;
}

int sys_exit()
{
  struct task_struct * curr_task;
  current_task_addr(curr_task);

  if (curr_task->pid == 0)
    return -1;

  // Destroy their semaphores!
  int i;
  for (i = 0; i < NR_SEM; i++) 
    if (sem_list[i].owner == curr_task->pid)
      sys_sem_destroy(i);
  
  // Mark the process PCB as unused by PID=-1
  curr_task->pid = -1;
  curr_task->p_stats.remaining_tics = 0; // Force the process to abandon the CPU
  // Now delete all the physical pages used by the process
  for (i = 0; i < NUM_PAG_DATA; i++)
  {
    free_frame(curr_task->phy_data_pages[i]);
  }

  processes_scheduler(1);
  return 0;
}

int sys_nice(int quantum)
{
  if (quantum <= 0) return -EINVAL;
  struct task_struct * curr_task;
  current_task_addr(curr_task);
  int last = curr_task->init_quantum;
  curr_task->init_quantum = quantum;
  return last; 
}

int sys_sem_init(int n_sem, unsigned int value)
{
  int mypid = sys_getpid();
  // Invalid semaphore
  if (n_sem < 0 || n_sem >= NR_SEM) return -EINVAL;

  if (sem_list[n_sem].used == 0)
  {
    sem_list[n_sem].owner = mypid;
    sem_list[n_sem].used = 1;
    sem_list[n_sem].value = value;
    int i;
    for (i = 0; i < sem_list[n_sem].locked_processes[i]; i++)
      sem_list[n_sem].locked_processes[i] = -1;
    return 0;
  }
  else
  {
    return -EBUSY;
  }
}

int sys_sem_wait(int n_sem)
{
  if (n_sem < 0 || n_sem >= NR_SEM) return -EINVAL;
  if (sys_getpid() == 0) return -1; // Can't block init
  if (sem_list[n_sem].used == 0) return -EINVAL; // Unitialized

  struct task_struct * curr_task;
  current_task_addr(curr_task);
  int nprocess = ((int)((int)curr_task)-((int)&task[0].t.task));
  nprocess /= 0x2000;

  if (sem_list[n_sem].value == 0) {
    // Block process
    int i;
    for (i = 0; i < NR_SEM; i++)
      if (sem_list[n_sem].locked_processes[i] == -1) {
        sem_list[n_sem].locked_processes[i] = nprocess;
        break;
      }

    // Put a 0 in EAX (OK)
    task[nprocess].t.saved_regs.eax = 0;
    task[nprocess].t.task.p_stats.remaining_tics = 0;

    processes_scheduler(1);
  }else{
    // Just decrement
    sem_list[n_sem].value--;
  }
  return 0;
}

int sys_sem_signal(int n_sem)
{
  if (n_sem < 0 || n_sem >= NR_SEM) return -EINVAL;
  if (sem_list[n_sem].used == 0) return -EINVAL; // Unitialized

  if (sem_list[n_sem].locked_processes[0] < 0) {
    // No processes blocked just increment
    sem_list[n_sem].value++;
  }else{
    // There's a process blocked
    int process_num = sem_list[n_sem].locked_processes[0];
    int i;
    // Move the queue forward
    for (i = 0; i < NR_SEM-1; i++)
      sem_list[n_sem].locked_processes[i] = sem_list[n_sem].locked_processes[i+1];
    sem_list[n_sem].locked_processes[NR_SEM-1] = -1;
    
    // Place a 0 in EAX of the process we're going to unblock
    task[process_num].t.saved_regs.eax = 0;
    list_add(&task[process_num].t.task.plist,runqueue);
  }
  return 0;
}

int sys_sem_destroy(int n_sem)
{
  // Destroy the semaphore and put all the processes in the runqueue
  int mypid = sys_getpid();
  if (n_sem < 0 || n_sem >= NR_SEM) return -EINVAL;
  if (sem_list[n_sem].used == 0) return -EINVAL;
  if (sem_list[n_sem].owner != mypid) return -1;

  int i;
  for (i = 0; i < NR_SEM; i++) {
    int np = sem_list[n_sem].locked_processes[i];
    if (np != -1) {
      // Return -1 to wait_sem
      task[np].t.saved_regs.eax = -1;
      list_add(&task[np].t.task.plist,runqueue);
    }
  }
  sem_list[n_sem].owner = -1;
  sem_list[n_sem].used = 0;
  return 0;
}

int sys_get_stats(int pid, struct stats *st) {
  if (pid < 0) return -EINVAL;
  if (comprova_usr_ptr((int)st,sizeof(struct stats))) {
    int i;
    for (i = 0; i < NR_TASKS; i++) {
      if (task[i].t.task.pid == pid) {
        *st = task[i].t.task.p_stats;
        return 0;
      }
    }
    return -ESRCH;
  }
  else
  {
    return -EFAULT;
  }
}

/* Empty function for empty syscalls */
int sys_ni_syscall()
{
  return -ENOSYS;
}

int console_write (struct file_descriptor_struct * fd, char *buffer, int size)
{
  return sys_write_console(buffer,size);
}




