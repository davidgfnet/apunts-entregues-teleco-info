package aima.search.demos;

/**
 * @author Ravi Mohan
 * 
 */

public class SearchDemo {
	public static void main(String[] args) {
		NQueensDemo.main(null);
		EightPuzzleDemo.main(null);
		MapDemo.main(null);
		CSPDemo.main(null);
	}

}
