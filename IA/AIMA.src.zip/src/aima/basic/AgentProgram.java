package aima.basic;

/**
 * @author Ravi Mohan
 * 
 */
public abstract class AgentProgram {

	public abstract String execute(Percept percept);

}