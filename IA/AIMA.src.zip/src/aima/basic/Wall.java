package aima.basic;

/**
 * @author Ravi Mohan
 * 
 */
public class Wall extends EnvironmentObject {

}