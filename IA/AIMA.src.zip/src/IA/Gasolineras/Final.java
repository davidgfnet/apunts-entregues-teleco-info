/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package IA.Gasolineras;

import aima.search.framework.GoalTest;

/**
 *
 * @author jesus
 */
public class Final implements GoalTest{
    
 public boolean isGoalState(Object aState) {
        return(false);
    }
}
