package IA.petroli;

public class PetroliTesterGUI {

	public static void main(String args[]) {
		
		PetroliWindow finestra = new PetroliWindow();
		finestra.setVisible(true);

	}
}
