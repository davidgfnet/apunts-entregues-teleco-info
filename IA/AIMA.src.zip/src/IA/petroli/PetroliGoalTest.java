package IA.petroli;

import aima.search.framework.GoalTest;

public class PetroliGoalTest implements GoalTest 
{

	public boolean isGoalState(Object state) 
	{
		return false;
	}

}
