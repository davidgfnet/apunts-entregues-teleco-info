
package projectecerca;

import aima.search.framework.HeuristicFunction;

/*
 * Classe heurística molt simple, es basa en buscar el minim retard
 */

public class ProblemaHeuristicaRetard implements HeuristicFunction{
      public double getHeuristicValue(Object state) {
          EstatProblema estat = (EstatProblema)state;
          return estat.getHoresRetard();
      }
}
