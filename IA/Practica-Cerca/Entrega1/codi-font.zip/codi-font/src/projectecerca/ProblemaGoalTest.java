
package projectecerca;

import aima.search.framework.GoalTest;

public class ProblemaGoalTest implements GoalTest {
    public boolean isGoalState(Object aState) {
        return(false);
    }
}
