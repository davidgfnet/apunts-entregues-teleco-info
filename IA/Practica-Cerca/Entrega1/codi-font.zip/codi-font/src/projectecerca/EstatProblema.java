
package projectecerca;

import java.util.*;

public class EstatProblema {
    private Camio llistat_camions[][];
    private Vector<Entrega> entreguesSenseCamio;

    /*
     * entregues és un vector amb les entregues que ens han demanat fer
     * capacitats és un vector de [10][6] enters amb les capacitats de cada camió
     */
    public EstatProblema(Vector<Entrega> entregues, int capacitats[][]) {
        // Cal copiar tots els vectors!!! Vigilar amb les referències!
        entreguesSenseCamio = new Vector<Entrega> (entregues);
        llistat_camions = new Camio[ProblemaCamions.numHores][ProblemaCamions.numCentres];
        for (int i = 0; i < ProblemaCamions.numHores; i++)
            for (int j = 0; j < ProblemaCamions.numCentres; j++)
                llistat_camions[i][j] = new Camio(capacitats[i][j]);
    }

    /*
     * Constructor còpia. DEEP COPY!!!
     */
    public EstatProblema(EstatProblema ep) {
        entreguesSenseCamio = new Vector<Entrega>(ep.entreguesSenseCamio);

        llistat_camions = new Camio[ProblemaCamions.numHores][ProblemaCamions.numCentres];
        for (int i = 0; i < ProblemaCamions.numHores; i++)
            for (int j = 0; j < ProblemaCamions.numCentres; j++)
                llistat_camions[i][j] = new Camio(ep.llistat_camions[i][j]);
    }

    public int Benefici() {
        int b = 0;
        for (int i = 0; i < ProblemaCamions.numHores; i++)
            for (int j = 0; j < ProblemaCamions.numCentres; j++)
                b += llistat_camions[i][j].getBenefici(i);

        for (int i = 0; i < entreguesSenseCamio.size(); i++)
            b += entreguesSenseCamio.get(i).CalculaGuanyNoEntregada();

        return b;
    }
    public int BeneficiMaxim() {
        int b = 0;
        for (int i = 0; i < ProblemaCamions.numHores; i++)
            for (int j = 0; j < ProblemaCamions.numCentres; j++)
                b += llistat_camions[i][j].getBenefici(0);

        for (int i = 0; i < entreguesSenseCamio.size(); i++)
            b += entreguesSenseCamio.get(i).CalculaGuany(0);

        return b;
    }
    public int CapacitatTransport() {
        int c = 0;
        for (int i = 0; i < ProblemaCamions.numHores; i++)
            for (int j = 0; j < ProblemaCamions.numCentres; j++)
                c += llistat_camions[i][j].getCapacitat();
        return c;
    }
    public int PesTotal() {
        int c = 0;
        for (int i = 0; i < ProblemaCamions.numHores; i++)
            for (int j = 0; j < ProblemaCamions.numCentres; j++)
                c += llistat_camions[i][j].getPesEntregues();

        for (int i = 0; i < entreguesSenseCamio.size(); i++)
            c += entreguesSenseCamio.get(i).getPes();

        return c;
    }
    public int PesNoEntregat() {
        int c = 0;
        for (int i = 0; i < entreguesSenseCamio.size(); i++)
            c += entreguesSenseCamio.get(i).getPes();

        return c;
    }
    public int BeneficiMaximEstimat() {
        float maxb = BeneficiMaxim();
        float capa = CapacitatTransport();
        float total = PesTotal();
        if (capa < total) {
            return (new Double(maxb*capa/total)).intValue();
        }else{
            return (new Double(maxb)).intValue();
        }
    }
    public int EspaiSobrant() {
        int c = 0;
        for (int i = 0; i < ProblemaCamions.numHores; i++)
            for (int j = 0; j < ProblemaCamions.numCentres; j++)
                c += llistat_camions[i][j].EspaiLliure();
        
        return c;
    }
    
    public int NombreComandes() {
        int t = 0;
        for (int i = 0; i < ProblemaCamions.numHores; i++)
            for (int j = 0; j < ProblemaCamions.numCentres; j++)
                t += llistat_camions[i][j].getNumEntregues();

        return t + this.entreguesSenseCamio.size();
    }

    /*
     * Retorna el nombre d'hores acumulades de retard de paquets
     */
    public int getHoresRetard() {
        int r = 0;
        for (int i = 0; i < ProblemaCamions.numHores; i++)
            for (int j = 0; j < ProblemaCamions.numCentres; j++)
                r += llistat_camions[i][j].getHoresRetard(i);

        for (int i = 0; i < entreguesSenseCamio.size(); i++)
            r += entreguesSenseCamio.get(i).HoresRetras(-1);

        return r;
    }

    /*
     * Inicialització intel·ligent
     * Posa els paquets ens camions (fins on es pot!) de forma que comença
     * posant els paquets més prioritaris a dalt i va baixant
     */
    public void Inicialitza1() {
        for (int i = 0; i < ProblemaCamions.numCentres; i++) {
            Vector <Entrega> ec = new Vector<Entrega>();
            for (int j = 0; j < entreguesSenseCamio.size(); j++) {
                if (entreguesSenseCamio.get(j).getNumCentre() == i) {
                    ec.add(entreguesSenseCamio.get(j));
                }
            }
            entreguesSenseCamio.removeAll(ec); // Assumim que els colocarem tots
            RepartirPaquets(ec, i);
            entreguesSenseCamio.addAll(ec);    // Afegim els que han quedat
        }
    }

    /*
     * FUNCIONS NECESSARIES per a les operacions de entregar o no entregar
     * una entrega amb un camió determinat
     */

    /*
     * Retorna el llistat d'entregues sense assignar a cap camió
     */
    public Vector<Entrega> getEntreguesSenseCamio() {
        return new Vector<Entrega>(entreguesSenseCamio);
    }
    /*
     * Assigna l'entrega sense camio idxEntrega al camió de l'hora i el centre
     * esmentats
     */
    public void CamioFesEntrega(int idxEntrega, int hora, int centre) {
        llistat_camions[hora][centre].AfegirEntrega(entreguesSenseCamio.get(idxEntrega));
        entreguesSenseCamio.remove(idxEntrega);
    }
    /*
     * Retorna la llista de camions (per a poder consultar les seves entregues)
     */
    public Camio[][] getCamions() {
        return llistat_camions;
    }
    /*
     * Anula l'entrega idxEntrega del camió hora,centre i l'afegeix al vector
     * d'entregues que no s'entregaràn
     */
    public void CamioAnulaEntrega(int idxEntrega, int hora, int centre) {
        Entrega e = llistat_camions[hora][centre].TreureEntrega(idxEntrega);
        entreguesSenseCamio.add(e);
    }


    /*
     * FUNCIONS NECESSARIES per a les operacions d'intercanvi de càrrega
     * en la qual does camions intercanvien les seves càrregues (part d'elles)
     */
    
    /*
     * Intercanvia el paquet i1 del camio de les h1 del centre centre
     * amb el paquet i2 del camio de les h2 del centre centre
     * No comprova cap mena d'error! Comprovar abans si es pot fer!
     */
    public boolean IntercanviaPaquets(int centre, int h1, int h2, int i1, int i2) {
        Entrega e1 = llistat_camions[h1][centre].TreureEntrega(i1);
        Entrega e2 = llistat_camions[h2][centre].TreureEntrega(i2);
        boolean ret1 = llistat_camions[h1][centre].AfegirEntrega(e2);
        boolean ret2 = llistat_camions[h2][centre].AfegirEntrega(e1);
        return ret1 && ret2;
    }

    /*
     * Mira si és possible girar dos paquets entre camions d'un mateix centre
     * a diferents hores. Simplement mira si l'espai lliure al treure el paquet
     * és suficient com per acomodar el que vindrà
     */
    public boolean PossibleIntercanviPaquets(int centre, int h1, int h2, int i1, int i2) {
        int pes1 = llistat_camions[h1][centre].getEntrega(i1).getPes();
        int pes2 = llistat_camions[h2][centre].getEntrega(i2).getPes();

        return (llistat_camions[h1][centre].EspaiLliure()-pes1 >= pes2) &&
               (llistat_camions[h2][centre].EspaiLliure()-pes2 >= pes1);
    }

    /*
     * Passa el paquet i1 del camio de les h1 del centre centre
     * al camio de les h2 del centre centre
     * Si falla retorna fals però no desfà els canvis!!!!
     */
    public void PassaPaquet(int centre, int h1, int h2, int idx) {
        Entrega e = llistat_camions[h1][centre].TreureEntrega(idx);
        llistat_camions[h2][centre].AfegirEntrega(e);
    }

    /*
     * Retorna cert si es pot passar el paquet del camio h1 al h2
     */
    public boolean PossiblePasPaquet(int centre, int h1, int h2, int idx) {
        return llistat_camions[h2][centre].EspaiLliure() >= llistat_camions[h1][centre].getEntrega(idx).getPes();
    }


    /*
     * Gira dos camions! Si sobren paquets del gran els recoloca a altres
     * camions del mateix centre i si no és possible doncs els afegeix a
     * la llista de paquets que no s'entregaran.
     * Per a millorar aquesta alternativa s'afegiran paquets a l'espai lliure
     * del camió gran seguint una estratègia conservadora (només afegir paquets
     * que reportin un benefici estrictament positiu)
     * PRE: H1,C1 es el camio més gran (mes capacitat)
     */
    public void GiraCamions(int c1, int c2, int h1, int h2) {
        // Primer girar camions i guardar les càrregues
        Camio cam1 = llistat_camions[h1][c1];
        Camio cam2 = llistat_camions[h2][c2];
        Vector<Entrega> e1 = cam1.getEntregues();
        Vector<Entrega> e2 = cam2.getEntregues();

        llistat_camions[h1][c1] = cam2;
        llistat_camions[h2][c2] = cam1;

        // Intercanvi de càrregues, encabir el màxim al camió petits
        cam1.setEntregues(e2); // Segur que hi cap, ja que cam1 > e2
        cam2.buidaEntregues();
        while (! e1.isEmpty()) {
            Entrega ent = e1.lastElement();
             // Si hi cap a dins!
            if (ent.getPes() <= cam2.EspaiLliure()) {
                 cam2.AfegirEntrega(ent);
                 e1.removeElementAt(e1.size()-1); // POP BACK!
            }else{
                break;
            }
            
        }
        // Com que encara poden quedar paquets al vector els "intentem" repartir
        // als camions. Si no ho fem aquest nou estat serà pitjor,
        // ja que treiem paquets entregats i això és absurd.
        RepartirPaquets(e1,c1);
        entreguesSenseCamio.addAll(e1);

        // Ara intentem encabir paquets del vector de no entregats al camió que
        // té espai lliure (aquest era l'objectiu inicial del gir)
        // Comencem posant paquets de l'hora del camió, l'hora -1 i així fins a primera hora
        for (int h = h2; h >= 0; h--) {
            for (int i = 0; i < entreguesSenseCamio.size(); i++) {
                Entrega en = entreguesSenseCamio.get(i);
                if (en.getNumCentre() == c2 && en.geHoraEntrega() == h) {
                    if (cam1.EspaiLliure() >= en.getPes()) {
                        cam1.AfegirEntrega(entreguesSenseCamio.get(i));
                        entreguesSenseCamio.remove(i);
                        i--;
                    }
                }
            }
        }


     }

    // Reparteix paquets als camions d'un centre de forma "intel·ligent"
    // PRE: El vector només té paquets del centre! No es comprova!
    private void RepartirPaquets(Vector<Entrega> e1, int centre) {
        if (!e1.isEmpty()) {
            Collections.sort(e1);
            for (int i = 0; i < ProblemaCamions.numHores; i++) {
                boolean mod = false;
                while (llistat_camions[i][centre].EspaiLliure() >= e1.lastElement().getPes()) {
                    // Mentre hi càpiguen paquets...
                    llistat_camions[i][centre].AfegirEntrega(e1.lastElement());
                    e1.removeElementAt(e1.size() - 1); // POP BACK!
                    mod = true;
                    if (e1.isEmpty()) { // Exit!
                        i = ProblemaCamions.numHores;
                        mod = false;
                        break;
                    }
                }
                // Si hem afegit alguna entrega, reiniciar el bucle de i, així
                // aconseguim distribuir al màxmim els paquets abans de la seva hora d'entrega
                if (mod)
                    i = -1;
            }
        }
    }
}
