
package projectecerca;

import java.util.Random;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;


public class VistaPrincipal extends javax.swing.JFrame {
    private int [] hora_probs;
    private int [] centre_probs;
    private Object dataf[][][];

    /** Creates new form VistaPrincipal */
    public VistaPrincipal() {
        initComponents();
        
        NCam500.setModel(new SpinnerNumberModel(60,0,60,1));
        NCam1000.setModel(new SpinnerNumberModel(0,0,60,1));
        NCam2000.setModel(new SpinnerNumberModel(0,0,60,1));
        String nomsColumna[] = new String[3];
        nomsColumna[0] = "Centre";
        nomsColumna[1] = "Hora";
        nomsColumna[2] = "Pes";
        TaulaComandes.setModel(new DefaultTableModel(nomsColumna, ProblemaCamions.nombreComandesPerDefecte));
        spinnerNC.setModel(new SpinnerNumberModel(ProblemaCamions.nombreComandesPerDefecte,1,100000,1));
        spinnerNC.setValue(ProblemaCamions.nombreComandesPerDefecte);

        grupBotons.add(radio1);
        grupBotons.add(radio2);

        grupBotons2.add(Ini0);
        grupBotons2.add(Ini1);
        grupBotons2.add(Ini2);
        grupBotons2.add(Ini3);

        Grup3.add(opera1);
        Grup3.add(opera2);

        hora_probs = new int[10];
        hora_probs[0] = hora_probs[1] = hora_probs[2] = 100;
        hora_probs[3] = hora_probs[4] = hora_probs[5] = 100;
        hora_probs[6] = hora_probs[7] = hora_probs[8] = 100;
        hora_probs[9] = 100;

        centre_probs = new int[6];
        centre_probs[0] = centre_probs[1] = centre_probs[2] = 100;
        centre_probs[3] = centre_probs[4] = centre_probs[5] = 100;
    }

    private void FillValues(int seed, int numC) {
        Integer values[] = ProblemaCamions.GeneraCondicionsInicials(seed,numC,hora_probs,centre_probs);

        NCam500.setValue(values[0]);
        NCam1000.setValue(values[1]);
        NCam2000.setValue(values[2]);

        for (int i = 0; i < numC; i++) {
            TaulaComandes.setValueAt(new String(Integer.toString(values[3*i+0+3])), i, 0);
            TaulaComandes.setValueAt(new String(Integer.toString(values[3*i+1+3])), i, 1);
            TaulaComandes.setValueAt(new String(Integer.toString(values[3*i+2+3])), i, 2);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grupBotons = new javax.swing.ButtonGroup();
        grupBotons2 = new javax.swing.ButtonGroup();
        Grup3 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        TaulaComandes = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        RandomWithoutSeed = new javax.swing.JButton();
        RandomWithSeed = new javax.swing.JButton();
        seedBox = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        spinnerNC = new javax.swing.JSpinner();
        jLabel5 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        butResolve = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        labelBeneficisHC = new javax.swing.JLabel();
        labelTempsHC = new javax.swing.JLabel();
        labelBeneficisSA = new javax.swing.JLabel();
        labelTempsSA = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        NCam500 = new javax.swing.JSpinner();
        NCam1000 = new javax.swing.JSpinner();
        NCam2000 = new javax.swing.JSpinner();
        jLabel16 = new javax.swing.JLabel();
        labelTempsRetardHC = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        radio1 = new javax.swing.JRadioButton();
        radio2 = new javax.swing.JRadioButton();
        jLabel18 = new javax.swing.JLabel();
        sliderNSteps = new javax.swing.JSlider();
        sliderStiter = new javax.swing.JSlider();
        jLabel19 = new javax.swing.JLabel();
        sliderK = new javax.swing.JSlider();
        jLabel20 = new javax.swing.JLabel();
        sliderLambda = new javax.swing.JSlider();
        jLabel21 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        Ini0 = new javax.swing.JRadioButton();
        Ini1 = new javax.swing.JRadioButton();
        Ini2 = new javax.swing.JRadioButton();
        Ini3 = new javax.swing.JRadioButton();
        jLabel22 = new javax.swing.JLabel();
        labelBeneficiEstatInicial = new javax.swing.JLabel();
        labelNEstatsVHC = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        labelPesosSA = new javax.swing.JLabel();
        labelTempsRetardSA = new javax.swing.JLabel();
        labelNEstatsVSA = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        labelPesosHC = new javax.swing.JLabel();
        probBut = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        seedBox2 = new javax.swing.JTextField();
        opera2 = new javax.swing.JRadioButton();
        opera1 = new javax.swing.JRadioButton();
        butRes = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("Form"); // NOI18N

        org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(projectecerca.ProjecteCercaApp.class).getContext().getResourceMap(VistaPrincipal.class);
        jLabel1.setText(resourceMap.getString("jLabel1.text")); // NOI18N
        jLabel1.setName("jLabel1"); // NOI18N

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator1.setName("jSeparator1"); // NOI18N

        jLabel3.setText(resourceMap.getString("jLabel3.text")); // NOI18N
        jLabel3.setName("jLabel3"); // NOI18N

        jScrollPane2.setName("jScrollPane2"); // NOI18N

        TaulaComandes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        TaulaComandes.setName("TaulaComandes"); // NOI18N
        jScrollPane2.setViewportView(TaulaComandes);

        jLabel2.setText(resourceMap.getString("jLabel2.text")); // NOI18N
        jLabel2.setName("jLabel2"); // NOI18N

        RandomWithoutSeed.setText(resourceMap.getString("RandomWithoutSeed.text")); // NOI18N
        RandomWithoutSeed.setName("RandomWithoutSeed"); // NOI18N
        RandomWithoutSeed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RandomWithoutSeedActionPerformed(evt);
            }
        });

        RandomWithSeed.setText(resourceMap.getString("RandomWithSeed.text")); // NOI18N
        RandomWithSeed.setName("RandomWithSeed"); // NOI18N
        RandomWithSeed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RandomWithSeedActionPerformed(evt);
            }
        });

        seedBox.setText(resourceMap.getString("seedBox.text")); // NOI18N
        seedBox.setName("seedBox"); // NOI18N

        jLabel4.setText(resourceMap.getString("jLabel4.text")); // NOI18N
        jLabel4.setName("jLabel4"); // NOI18N

        spinnerNC.setName("spinnerNC"); // NOI18N
        spinnerNC.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                spinnerNCStateChanged(evt);
            }
        });
        spinnerNC.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                spinnerNCPropertyChange(evt);
            }
        });

        jLabel5.setText(resourceMap.getString("jLabel5.text")); // NOI18N
        jLabel5.setName("jLabel5"); // NOI18N

        jSeparator2.setName("jSeparator2"); // NOI18N

        butResolve.setText(resourceMap.getString("butResolve.text")); // NOI18N
        butResolve.setName("butResolve"); // NOI18N
        butResolve.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butResolveActionPerformed(evt);
            }
        });

        jLabel6.setText(resourceMap.getString("jLabel6.text")); // NOI18N
        jLabel6.setName("jLabel6"); // NOI18N

        jLabel7.setText(resourceMap.getString("jLabel7.text")); // NOI18N
        jLabel7.setName("jLabel7"); // NOI18N

        jLabel8.setText(resourceMap.getString("jLabel8.text")); // NOI18N
        jLabel8.setName("jLabel8"); // NOI18N

        jLabel9.setText(resourceMap.getString("jLabel9.text")); // NOI18N
        jLabel9.setName("jLabel9"); // NOI18N

        jLabel10.setText(resourceMap.getString("jLabel10.text")); // NOI18N
        jLabel10.setName("jLabel10"); // NOI18N

        jLabel11.setText(resourceMap.getString("jLabel11.text")); // NOI18N
        jLabel11.setName("jLabel11"); // NOI18N

        jLabel12.setText(resourceMap.getString("jLabel12.text")); // NOI18N
        jLabel12.setName("jLabel12"); // NOI18N

        labelBeneficisHC.setText(resourceMap.getString("labelBeneficisHC.text")); // NOI18N
        labelBeneficisHC.setName("labelBeneficisHC"); // NOI18N

        labelTempsHC.setText(resourceMap.getString("labelTempsHC.text")); // NOI18N
        labelTempsHC.setName("labelTempsHC"); // NOI18N

        labelBeneficisSA.setText(resourceMap.getString("labelBeneficisSA.text")); // NOI18N
        labelBeneficisSA.setName("labelBeneficisSA"); // NOI18N

        labelTempsSA.setText(resourceMap.getString("labelTempsSA.text")); // NOI18N
        labelTempsSA.setName("labelTempsSA"); // NOI18N

        jLabel13.setText(resourceMap.getString("jLabel13.text")); // NOI18N
        jLabel13.setName("jLabel13"); // NOI18N

        jLabel14.setText(resourceMap.getString("jLabel14.text")); // NOI18N
        jLabel14.setName("jLabel14"); // NOI18N

        jLabel15.setText(resourceMap.getString("jLabel15.text")); // NOI18N
        jLabel15.setName("jLabel15"); // NOI18N

        NCam500.setName("NCam500"); // NOI18N
        NCam500.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                NCam500StateChanged(evt);
            }
        });
        NCam500.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                NCam500PropertyChange(evt);
            }
        });

        NCam1000.setName("NCam1000"); // NOI18N
        NCam1000.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                NCam1000StateChanged(evt);
            }
        });
        NCam1000.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                NCam1000PropertyChange(evt);
            }
        });

        NCam2000.setName("NCam2000"); // NOI18N
        NCam2000.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                NCam2000StateChanged(evt);
            }
        });
        NCam2000.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                NCam2000PropertyChange(evt);
            }
        });

        jLabel16.setText(resourceMap.getString("jLabel16.text")); // NOI18N
        jLabel16.setName("jLabel16"); // NOI18N

        labelTempsRetardHC.setText(resourceMap.getString("labelTempsRetardHC.text")); // NOI18N
        labelTempsRetardHC.setName("labelTempsRetardHC"); // NOI18N

        jLabel17.setText(resourceMap.getString("jLabel17.text")); // NOI18N
        jLabel17.setName("jLabel17"); // NOI18N

        radio1.setSelected(true);
        radio1.setText(resourceMap.getString("radio1.text")); // NOI18N
        radio1.setName("radio1"); // NOI18N

        radio2.setText(resourceMap.getString("radio2.text")); // NOI18N
        radio2.setName("radio2"); // NOI18N

        jLabel18.setText(resourceMap.getString("jLabel18.text")); // NOI18N
        jLabel18.setName("jLabel18"); // NOI18N

        sliderNSteps.setMaximum(500000);
        sliderNSteps.setMinimum(500);
        sliderNSteps.setValue(50000);
        sliderNSteps.setName("sliderNSteps"); // NOI18N

        sliderStiter.setMaximum(10000);
        sliderStiter.setMinimum(1);
        sliderStiter.setValue(100);
        sliderStiter.setName("sliderStiter"); // NOI18N

        jLabel19.setText(resourceMap.getString("jLabel19.text")); // NOI18N
        jLabel19.setName("jLabel19"); // NOI18N

        sliderK.setMaximum(1000);
        sliderK.setMinimum(1);
        sliderK.setValue(20);
        sliderK.setName("sliderK"); // NOI18N

        jLabel20.setText(resourceMap.getString("jLabel20.text")); // NOI18N
        jLabel20.setName("jLabel20"); // NOI18N

        sliderLambda.setMaximum(500);
        sliderLambda.setMinimum(1);
        sliderLambda.setValue(5);
        sliderLambda.setName("sliderLambda"); // NOI18N

        jLabel21.setText(resourceMap.getString("jLabel21.text")); // NOI18N
        jLabel21.setName("jLabel21"); // NOI18N

        jSeparator3.setName("jSeparator3"); // NOI18N

        Ini0.setSelected(true);
        Ini0.setText(resourceMap.getString("Ini0.text")); // NOI18N
        Ini0.setName("Ini0"); // NOI18N

        Ini1.setText(resourceMap.getString("Ini1.text")); // NOI18N
        Ini1.setName("Ini1"); // NOI18N

        Ini2.setText(resourceMap.getString("Ini2.text")); // NOI18N
        Ini2.setName("Ini2"); // NOI18N

        Ini3.setText(resourceMap.getString("Ini3.text")); // NOI18N
        Ini3.setName("Ini3"); // NOI18N

        jLabel22.setText(resourceMap.getString("jLabel22.text")); // NOI18N
        jLabel22.setName("jLabel22"); // NOI18N

        labelBeneficiEstatInicial.setText(resourceMap.getString("labelBeneficiEstatInicial.text")); // NOI18N
        labelBeneficiEstatInicial.setName("labelBeneficiEstatInicial"); // NOI18N

        labelNEstatsVHC.setText(resourceMap.getString("labelNEstatsVHC.text")); // NOI18N
        labelNEstatsVHC.setName("labelNEstatsVHC"); // NOI18N

        jLabel24.setText(resourceMap.getString("jLabel24.text")); // NOI18N
        jLabel24.setName("jLabel24"); // NOI18N

        labelPesosSA.setText(resourceMap.getString("labelPesosSA.text")); // NOI18N
        labelPesosSA.setName("labelPesosSA"); // NOI18N

        labelTempsRetardSA.setText(resourceMap.getString("labelTempsRetardSA.text")); // NOI18N
        labelTempsRetardSA.setName("labelTempsRetardSA"); // NOI18N

        labelNEstatsVSA.setText(resourceMap.getString("labelNEstatsVSA.text")); // NOI18N
        labelNEstatsVSA.setName("labelNEstatsVSA"); // NOI18N

        jLabel26.setText(resourceMap.getString("jLabel26.text")); // NOI18N
        jLabel26.setName("jLabel26"); // NOI18N

        jLabel27.setText(resourceMap.getString("jLabel27.text")); // NOI18N
        jLabel27.setName("jLabel27"); // NOI18N

        jLabel28.setText(resourceMap.getString("jLabel28.text")); // NOI18N
        jLabel28.setName("jLabel28"); // NOI18N

        labelPesosHC.setText(resourceMap.getString("labelPesosHC.text")); // NOI18N
        labelPesosHC.setName("labelPesosHC"); // NOI18N

        probBut.setText(resourceMap.getString("probBut.text")); // NOI18N
        probBut.setName("probBut"); // NOI18N
        probBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                probButActionPerformed(evt);
            }
        });

        jLabel29.setText(resourceMap.getString("jLabel29.text")); // NOI18N
        jLabel29.setName("jLabel29"); // NOI18N

        seedBox2.setName("seedBox2"); // NOI18N

        opera2.setText(resourceMap.getString("opera2.text")); // NOI18N
        opera2.setName("opera2"); // NOI18N

        opera1.setSelected(true);
        opera1.setText(resourceMap.getString("opera1.text")); // NOI18N
        opera1.setName("opera1"); // NOI18N

        butRes.setText(resourceMap.getString("butRes.text")); // NOI18N
        butRes.setName("butRes"); // NOI18N
        butRes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                butResActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator2, javax.swing.GroupLayout.DEFAULT_SIZE, 694, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                                .addComponent(probBut))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, 0, 0, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(spinnerNC, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(145, 145, 145))
                            .addComponent(RandomWithoutSeed, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(RandomWithSeed)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                                .addComponent(seedBox, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel15)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                                .addComponent(NCam2000, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(NCam500, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                                .addComponent(NCam1000, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 6, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel18)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                                .addComponent(sliderNSteps, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(sliderK, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(sliderStiter, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                                .addGap(18, 18, 18)
                                .addComponent(sliderLambda, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jSeparator3, javax.swing.GroupLayout.DEFAULT_SIZE, 402, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(radio2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(radio1, javax.swing.GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(opera2, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(opera1))
                                        .addGap(18, 18, 18)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(Ini3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Ini2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Ini1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Ini0, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 206, Short.MAX_VALUE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel29)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(seedBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 117, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(butRes, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(butResolve, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(41, 41, 41)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel8)
                                                    .addComponent(jLabel9))
                                                .addGap(30, 30, 30))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel16)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(labelBeneficisHC, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                                            .addComponent(labelTempsHC, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                                            .addComponent(labelTempsRetardHC, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel24)
                                            .addComponent(jLabel22))
                                        .addGap(27, 27, 27))
                                    .addComponent(jLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(labelNEstatsVHC, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 208, Short.MAX_VALUE)
                                    .addComponent(labelBeneficiEstatInicial, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 208, Short.MAX_VALUE)
                                    .addComponent(labelPesosHC, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 208, Short.MAX_VALUE)
                                    .addComponent(labelNEstatsVSA, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(labelTempsRetardSA, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(labelPesosSA, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 208, Short.MAX_VALUE))))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel10))
                                .addGap(30, 30, 30)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(labelBeneficisSA, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                                    .addComponent(labelTempsSA, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel27)))
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(256, 256, 256))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(17, 17, 17)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(sliderNSteps, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel18))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(sliderStiter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(sliderK, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(sliderLambda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(radio1)
                            .addComponent(Ini0))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(radio2)
                            .addComponent(Ini1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Ini2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Ini3))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addComponent(opera1)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(opera2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                        .addComponent(butRes)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(butResolve)
                            .addComponent(jLabel29)
                            .addComponent(seedBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jSeparator1, javax.swing.GroupLayout.DEFAULT_SIZE, 464, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(NCam500, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(NCam1000, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(NCam2000, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(probBut)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(spinnerNC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(RandomWithoutSeed)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(RandomWithSeed)
                            .addComponent(seedBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 6, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(69, 69, 69))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel24)
                                    .addGap(42, 42, 42))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(labelBeneficiEstatInicial)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(labelNEstatsVHC)
                                    .addGap(21, 21, 21)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(labelBeneficisHC)
                                    .addComponent(jLabel8))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(labelTempsHC)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel22))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(labelTempsRetardHC)
                                    .addComponent(jLabel16))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel28)
                            .addComponent(labelPesosHC))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(labelBeneficisSA)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(labelTempsSA))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel11))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel27)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel26)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel17))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(labelTempsRetardSA)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(labelNEstatsVSA)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(labelPesosSA)))
                .addGap(25, 25, 25))
        );

        jLabel2.getAccessibleContext().setAccessibleName(resourceMap.getString("jLabel2.AccessibleContext.accessibleName")); // NOI18N

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RandomWithSeedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RandomWithSeedActionPerformed
        int seed = Integer.valueOf(seedBox.getText());
        int numC = ((SpinnerNumberModel)spinnerNC.getModel()).getNumber().intValue();
        FillValues(seed,numC);

    }//GEN-LAST:event_RandomWithSeedActionPerformed

    private void RandomWithoutSeedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RandomWithoutSeedActionPerformed
        int seed = (new Random()).nextInt();
        if (seed < 0) seed = -seed;
        seedBox.setText(Integer.toString(seed));
        seedBox2.setText(Integer.toString(seed));
        RandomWithSeedActionPerformed(evt);
    }//GEN-LAST:event_RandomWithoutSeedActionPerformed

    private void spinnerNCPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_spinnerNCPropertyChange

    }//GEN-LAST:event_spinnerNCPropertyChange

    // Afegeix o treu files de la llista de comandes preservant-ne els valors
    private void spinnerNCStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_spinnerNCStateChanged
        String nomsColumna[] = new String[3];
        nomsColumna[0] = "Centre";
        nomsColumna[1] = "Hora";
        nomsColumna[2] = "Pes";
        int numC = ((SpinnerNumberModel)spinnerNC.getModel()).getNumber().intValue();
        DefaultTableModel mod = (DefaultTableModel)TaulaComandes.getModel();
        Vector data = mod.getDataVector();
        mod = new DefaultTableModel(nomsColumna, numC);
        TaulaComandes.setModel(mod);
        for (int i = 0; i < data.size() && i < numC; i++) {
            for (int j = 0; j < 3; j++) {
                mod.setValueAt(((Vector)data.get(i)).get(j), i, j);
            }
        }
    }//GEN-LAST:event_spinnerNCStateChanged

    private void NCam500StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_NCam500StateChanged
    }//GEN-LAST:event_NCam500StateChanged

    private void NCam500PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_NCam500PropertyChange
    }//GEN-LAST:event_NCam500PropertyChange

    private void NCam1000StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_NCam1000StateChanged
    }//GEN-LAST:event_NCam1000StateChanged

    private void NCam1000PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_NCam1000PropertyChange
    }//GEN-LAST:event_NCam1000PropertyChange

    private void NCam2000StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_NCam2000StateChanged
    }//GEN-LAST:event_NCam2000StateChanged

    private void NCam2000PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_NCam2000PropertyChange
    }//GEN-LAST:event_NCam2000PropertyChange

    private void butResolveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butResolveActionPerformed
        try {
            int n500 = ((SpinnerNumberModel)NCam500.getModel()).getNumber().intValue();
            int n1000 = ((SpinnerNumberModel)NCam1000.getModel()).getNumber().intValue();
            int n2000 = ((SpinnerNumberModel)NCam2000.getModel()).getNumber().intValue();
            int cams[] = {n500,n1000,n2000};

            int ini = 0;
            if (Ini1.isSelected()) ini = 1;
            if (Ini2.isSelected()) ini = 2;
            if (Ini3.isSelected()) ini = 3;

            int opera = 0;
            if (opera2.isSelected()) opera = 1;

            Vector com =  ((DefaultTableModel)TaulaComandes.getModel()).getDataVector();
            ProblemaCamions p = new ProblemaCamions(cams,com,ini,Integer.valueOf(seedBox2.getText()));

            int sa_steps = sliderNSteps.getValue();
            int sa_k = sliderK.getValue();
            int sa_stiter = sliderStiter.getValue();
            double sa_lamb = sliderLambda.getValue()/1000.0f;
            if (radio1.isSelected()) p.ResolProblema(0,Integer.valueOf(seedBox.getText()),opera,sa_steps,sa_stiter,sa_k,sa_lamb);
            else p.ResolProblema(1,Integer.valueOf(seedBox.getText()),opera,sa_steps,sa_stiter,sa_k,sa_lamb);

            dataf = p.ObteResultats();

            labelTempsHC.setText(Integer.toString((int)p.getTimeMS(true))+"ms");
            labelBeneficisHC.setText(Integer.toString(p.getBeneficiFinal(true)));
            labelTempsSA.setText(Integer.toString((int)p.getTimeMS(false))+"ms");
            labelBeneficisSA.setText(Integer.toString(p.getBeneficiFinal(false)));

            labelBeneficiEstatInicial.setText(Integer.toString(p.getBeneficiInicial()));
            labelTempsRetardHC.setText(Integer.toString(p.getHoresRetard(true)));
            labelTempsRetardSA.setText(Integer.toString(p.getHoresRetard(false)));
            // total / no entregat / entregat / lliure
            labelPesosHC.setText(
                           Integer.toString(p.getPesTotal(true))
                    +" / " + Integer.toString(p.getPesNoEntregat(true))
                    +" / " + Integer.toString(p.getPesEntregat(true))
                    +" / " + Integer.toString(p.getEspaiSobrant(true)));

            labelPesosSA.setText(
                           Integer.toString(p.getPesTotal(false))
                    +" / " + Integer.toString(p.getPesNoEntregat(false))
                    +" / " + Integer.toString(p.getPesEntregat(false))
                    +" / " + Integer.toString(p.getEspaiSobrant(false)));

            labelNEstatsVHC.setText(Integer.toString(p.getNumVisitats(true)));
            labelNEstatsVSA.setText(Integer.toString(p.getNumVisitats(false)));
        }catch (Exception e) {
            JOptionPane.showMessageDialog(this,"Els camps no són vàlids!","Error!",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_butResolveActionPerformed

    private void probButActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_probButActionPerformed
        ProbDialog diag = new ProbDialog(this,true,hora_probs,centre_probs);
        diag.setVisible(true);
        hora_probs = diag.getProbs();
        centre_probs = diag.getProbsC();
    }//GEN-LAST:event_probButActionPerformed

    private void butResActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_butResActionPerformed
        if (dataf != null) {
            Object cols[] = new String[6];
            for (int i = 0; i < 6; i++)
                cols[i] = "Centre "+i;

            frmResults form = new frmResults(this,true,dataf,cols);
            form.setVisible(true);
        }
    }//GEN-LAST:event_butResActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup Grup3;
    private javax.swing.JRadioButton Ini0;
    private javax.swing.JRadioButton Ini1;
    private javax.swing.JRadioButton Ini2;
    private javax.swing.JRadioButton Ini3;
    private javax.swing.JSpinner NCam1000;
    private javax.swing.JSpinner NCam2000;
    private javax.swing.JSpinner NCam500;
    private javax.swing.JButton RandomWithSeed;
    private javax.swing.JButton RandomWithoutSeed;
    private javax.swing.JTable TaulaComandes;
    private javax.swing.JButton butRes;
    private javax.swing.JButton butResolve;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup grupBotons;
    private javax.swing.ButtonGroup grupBotons2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JLabel labelBeneficiEstatInicial;
    private javax.swing.JLabel labelBeneficisHC;
    private javax.swing.JLabel labelBeneficisSA;
    private javax.swing.JLabel labelNEstatsVHC;
    private javax.swing.JLabel labelNEstatsVSA;
    private javax.swing.JLabel labelPesosHC;
    private javax.swing.JLabel labelPesosSA;
    private javax.swing.JLabel labelTempsHC;
    private javax.swing.JLabel labelTempsRetardHC;
    private javax.swing.JLabel labelTempsRetardSA;
    private javax.swing.JLabel labelTempsSA;
    private javax.swing.JRadioButton opera1;
    private javax.swing.JRadioButton opera2;
    private javax.swing.JButton probBut;
    private javax.swing.JRadioButton radio1;
    private javax.swing.JRadioButton radio2;
    private javax.swing.JTextField seedBox;
    private javax.swing.JTextField seedBox2;
    private javax.swing.JSlider sliderK;
    private javax.swing.JSlider sliderLambda;
    private javax.swing.JSlider sliderNSteps;
    private javax.swing.JSlider sliderStiter;
    private javax.swing.JSpinner spinnerNC;
    // End of variables declaration//GEN-END:variables

}
