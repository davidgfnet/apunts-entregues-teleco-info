
package projectecerca;

import aima.search.framework.Successor;
import aima.search.framework.SuccessorFunction;
import java.util.*;


public class SuccessorsSA implements SuccessorFunction {
    private Random rg;

    public SuccessorsSA(int seed) {
        rg = new Random(seed);
    }

    public List getSuccessors(Object aState) {
        ArrayList retVal = new ArrayList();
        EstatProblema state = (EstatProblema)aState;
        Camio[][] llcam = state.getCamions();
        Vector <Entrega> entNoFetes = state.getEntreguesSenseCamio();

        // Triem un operador a l'atzar!
        while (true) {
            int op = rg.nextInt(3);

            switch (op) {
                case 0: {
                    // OP 0 a l'atzar, triar una hora i un paquet
                    if (entNoFetes.size() == 0) continue;
                    int n1 = rg.nextInt(entNoFetes.size());
                    int n2 = rg.nextInt(ProblemaCamions.numHores);

                    int numcentre = entNoFetes.get(n1).getNumCentre();
                    int pes = entNoFetes.get(n1).getPes();
                    if (llcam[n2][numcentre].EspaiLliure() >= pes) {
                        EstatProblema nou = new EstatProblema(state);
                        nou.CamioFesEntrega(n1, n2, numcentre);
                        retVal.add(new Successor(new String("Entrega " + n1 + " " + n2 + " " + numcentre), nou));
                        return retVal;
                    }
                } break;
                case 1: {
                // Operador 1: Gira parells de paquets (si es poden girar)
                    int i = rg.nextInt(ProblemaCamions.numCentres);
                    int h = rg.nextInt(ProblemaCamions.numHores);
                    if (h == ProblemaCamions.numHores-1) continue;
                    int h2 = rg.nextInt(ProblemaCamions.numHores-h-1) + h + 1;

                    // Fixats 2 camions del centre 'i' a hores h i h2, girar paquet!
                    int n1 = llcam[h][i].getNumEntregues();
                    int n2 = llcam[h2][i].getNumEntregues();
                    if (n1 == 0 && n2 == 0) continue;
                    else if (n1 != 0 && n2 != 0) {
                        int i1 = rg.nextInt(n1);
                        int i2 = rg.nextInt(n2);

                        if (state.PossibleIntercanviPaquets(i,h,h2,i1,i2)) {
                            EstatProblema nou = new EstatProblema(state);
                            nou.IntercanviaPaquets(i,h,h2,i1,i2);
                            String str = new String(
                                       "Intercanvia al centre " + i +
                                       " el paquet del camió de les " + h +
                                       " numero " +i1 + "pel del camió de les " +
                                       h2 + " paquet num " + i2);
                            retVal.add(new Successor(str, nou));
                            return retVal;
                        }
                    }else if (n1 == 0){
                        int i2 = rg.nextInt(n2);
                        EstatProblema nou = new EstatProblema(state);
                        if (state.PossiblePasPaquet(i,h2,h,i2)) {
                            nou.PassaPaquet(i,h2,h,i2);
                            String str = new String(
                                       "Passa paquet: (centre " + i +
                                       ") el paquet del camió de les " + h2 +
                                       " numero " + i2 + " al camió de les " + h);
                            retVal.add(new Successor(str, nou));
                            return retVal;
                        }
                    }else if (n2 == 0) {
                        int i1 = rg.nextInt(n1);
                        EstatProblema nou = new EstatProblema(state);
                        if (state.PossiblePasPaquet(i,h,h2,i1)) {
                            nou.PassaPaquet(i,h,h2,i1);
                            String str = new String(
                                       "Passa paquet: (centre " + i +
                                       ") el paquet del camió de les " + h +
                                       " numero " + i1 + " al camió de les " + h2);
                            retVal.add(new Successor(str, nou));
                            return retVal;
                        }
                    }
                } break;
                case 2: {
                // Segon operador: Aquest sempre genera algun successor vàlid, ni que
                // sigui poc beneficiós!
                    int c1 = rg.nextInt(ProblemaCamions.numCentres);
                    int h1 = rg.nextInt(ProblemaCamions.numHores);
                    int c2 = rg.nextInt(ProblemaCamions.numCentres-c1) + c1;
                    int h2;
                    if (c1 == c2) {
                        if (h1 == ProblemaCamions.numHores-1) continue;
                        h2 = rg.nextInt(ProblemaCamions.numHores - h1 - 1) + h1 + 1;
                    }
                    else h2 = rg.nextInt(ProblemaCamions.numHores);

                    Camio cam1 = llcam[h1][c1]; // BIG
                    Camio cam2 = llcam[h2][c2]; // LITTLE
                    // Swap si necessari
                    if (cam1.getCapacitat() != cam2.getCapacitat()) {
                        EstatProblema nou = new EstatProblema(state);

                        if (cam1.getCapacitat() < cam2.getCapacitat())
                            nou.GiraCamions(c2, c1, h2, h1);
                        else
                            nou.GiraCamions(c1, c2, h1, h2);

                        String str = new String(
                                   "Gira dos camions de centres ("+c1+","+c2+") i hores ("
                                   +h1+","+h2+")");
                        retVal.add(new Successor(str, nou));
                        return retVal;
                    }
                } break;
            }
        }
    }

}
