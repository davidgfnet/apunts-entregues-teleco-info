
package projectecerca;

import aima.search.framework.HeuristicFunction;

/*
 * Classe heurística molt simple, es basa en buscar el major benefici
 * Es pot millorar premiant certs estats (d'entre els que ofereixen el mateix
 * benefici) segons ens convingui. Cal anar amb compte ja que el "bonus" ha de
 * mantenir l'admissibilitat, es a dir, que un estat amb un cert benefici
 * sempre es millor que un altre estat amb menor benefici. Així només provocariem
 * desempats entre mateixos beneficis.
 */

/* Premiem menor retard a mateix benefici. Exemple:
 *
 * Ben.    Ret.     Calcul        Resultat a min.
 * 1000€    10    -1000 -1/12  ->  -1000,083
 * 1000€    20    -1000 -1/22  ->  -1000,045
 * El premi és de com a molt 0.5 (aixi mai un estat amb més benefici
 * serà ignorat a causa d'un amb menor benefici.
 */

public class ProblemaHeuristicaBenefici implements HeuristicFunction{
      public double getHeuristicValue(Object state) {
          EstatProblema estat = (EstatProblema)state;
          double retard_inv = 1/(((double)estat.getHoresRetard())+2); // Evitar 0 o 1!!
          return (-estat.Benefici()) + (-retard_inv);
      }
}

