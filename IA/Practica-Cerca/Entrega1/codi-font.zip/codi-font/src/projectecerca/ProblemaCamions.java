

package projectecerca;

import aima.search.framework.HeuristicFunction;
import aima.search.framework.Problem;
import aima.search.framework.SearchAgent;
import aima.search.framework.SuccessorFunction;
import aima.search.informed.HillClimbingSearch;
import aima.search.informed.SimulatedAnnealingSearch;
import java.util.*;


public class ProblemaCamions {
    public static final int numCentres = 6;
    public static final int numHores = 10;
    public static final int nombreComandesPerDefecte = 100;

    public static final int pesosCamions[] = {500,1000,2000};
    public static final int pesosComandes[] = {100,200,300,400,500};

    private EstatProblema estatInicial;
    private EstatProblema fi1, fi2;

    private long TimeMS_HC, TimeMS_SA;
    private int BeneficiInicial;
    private int BeneficiFinal_HC, BeneficiFinal_SA;
    private int NumEstatsVisitats;
    private int nodExpSA, nodExpHC;
    /*
     * Crea un problema amb unes certes condicions inicials i l'estat inicial
     * sigui totes les comandes marcades com a no processades
     * Inicialitazció dels pesos dels camions 1
     */
    public ProblemaCamions(int pesoscam[], Vector<Vector<String>> comandes, int inicialitzacio, int seed) {
        int capa [][] = new int[numHores][numCentres];

        Vector <Entrega> vecent = new Vector<Entrega> ();
        for (int i = 0; i < comandes.size(); i++) {
            Entrega e = new Entrega(Integer.valueOf(comandes.get(i).get(0))-1,
                                    Integer.valueOf(comandes.get(i).get(1))-1,
                                    Integer.valueOf(comandes.get(i).get(2)));
            vecent.add(e);
        }

        switch (inicialitzacio) {
        case 0:  // Inizialització simple i desequilibrada
            for (int j = 0; j < numCentres; j++)
                for (int i = 0; i < numHores; i++)
                    for (int k = 0; k < pesoscam.length; k++)
                        if (pesoscam[k] != 0){
                            capa[i][j] = pesosCamions[k];
                            pesoscam[k]--;
                            break;
                        }
            break;
        case 1:  // Inicialització equitativa però sense tenir en compte les hores amb més demanda
            int c1 = numHores-1, c2 = numCentres-1;
            for (int j = 0; j < pesosCamions.length; j++) {
                for (int i = 0; i < pesoscam[j]; i++) {
                    capa[c1][c2] = pesosCamions[j];
                    c2--;
                    if (c2 < 0) {
                        c2 = numCentres-1;
                        c1--;
                    }
                }
            }
            break;
        case 2:  // Inicialització aleatòria
            Random r = new Random(seed);
            for (int j = 0; j < numCentres; j++)
                for (int i = 0; i < numHores; i++)
                    while (true) {
                        int k = r.nextInt(pesoscam.length);
                        if (pesoscam[k] != 0){
                            capa[i][j] = pesosCamions[k];
                            pesoscam[k]--;
                            break;
                        }
                    }
            break;
        case 3:
            // Inicialització altament intel·ligent, greedy però eficaç
            // Ordena les comandes per hora i volum i reparteix els camions
            // equitativament.

            // 1r pas: calcula el pes total, pes per centre i pes per hora i centre
            int pesos[][] = new int[numHores][numCentres];
            for (int i = 0; i < vecent.size(); i++) {
                int nc = vecent.get(i).getNumCentre();
                int pes = vecent.get(i).getPes();
                int hora = vecent.get(i).geHoraEntrega();
                pesos[hora][nc] += pes;
            }

            // 2n pas: assigna camions basant-se en el pes que hi ha a cada hora
            // Intenta assignar el camio que satisfà la demanda per sempre convservador:
            // Si l'espai sobrant és més gran que l'espai que faltaria amb un de menor
            // no el tria
            int numCamions = numCentres*numHores;
            while (numCamions-- > 0) {
                // Cerca un pic de demanda
                int max = -1; int cmax=-1,hmax=-1;
                for (int j = 0; j < numCentres; j++) {
                    for (int i = 0; i < numHores; i++) {
                        if (max < pesos[i][j]) {
                            cmax = j; hmax = i; max = pesos[i][j];
                        }
                    }
                }

                int camidx = -1;
                for (int i = pesosCamions.length-1; i >= 0; i--) {
                    if (pesoscam[i] != 0) {
                        if (pesosCamions[i] >= pesos[hmax][cmax] || camidx == -1) {
                            capa[hmax][cmax] = pesosCamions[i];
                            camidx = i;
                        }else{
                             if (pesosCamions[camidx] - pesos[hmax][cmax] > pesos[hmax][cmax] - pesosCamions[i]) {
                                camidx = i;
                                capa[hmax][cmax] = pesosCamions[i];
                                break;
                             }
                        }
                    }
                }
                pesoscam[camidx]--;
                pesos[hmax][cmax] = -1;
            }
            break;
        }
        
        estatInicial = new EstatProblema(vecent,capa);
        estatInicial.Inicialitza1();
        NumEstatsVisitats = 0;
    }
    
    /*
     * Genera un vector de condicions del problema (nombre de camions,
     * dades de les comandes, etc).
     */
    public static Integer[] GeneraCondicionsInicials(int seed, int numC, int [] hprobs, int [] cprobs) {
        Random r = new Random(seed);
        Integer table[] = new Integer[numCentres*numHores+numC*3];

        // Generar els pesos dels camions
        int n1,n2,n3,nt;
        n1 = r.nextInt(100); n2 = r.nextInt(100); n3 = r.nextInt(100);
        nt = n1+n2+n3;
        float na = (new Float(n1))/(float)nt; float nb = (new Float(n2))/(float)nt;
        table[0] = new Integer((int)(na*numCentres*numHores));
        table[1] = new Integer((int)(nb*numCentres*numHores));
        table[2] = new Integer(numCentres*numHores - table[0] - table[1]);

        // Generar les comandes
        for (int i = 0; i < numC; i++) {
            int h = getHoraProb(r,hprobs);
            int c = getCentreProb(r,cprobs);
            table[3*i  +3] = new Integer(c+1);
            table[3*i+1+3] = new Integer(h+1);
            table[3*i+2+3] = new Integer(pesosComandes[r.nextInt(pesosComandes.length)]);
        }

        return table;
    }

    private static int getHoraProb(Random r, int [] hprobs) {
        int max = 0;
        for (int i = 0; i < hprobs.length; i++)
            max += hprobs[i];

        while (true) {
            int hp = r.nextInt(max);
            int accum = 0;
            for (int i = 0; i < hprobs.length; i++) {
                accum += hprobs[i];
                if (hp < accum)
                    return i;
            }
        }
    }

    private static int getCentreProb(Random r, int [] cprobs) {
        int max = 0;
        for (int i = 0; i < cprobs.length; i++)
            max += cprobs[i];

        while (true) {
            int hp = r.nextInt(max);
            int accum = 0;
            for (int i = 0; i < cprobs.length; i++) {
                accum += cprobs[i];
                if (hp < accum)
                    return i;
            }
        }
    }

    public void ResolProblema(int target, int seed, int operadors,
            int sa_steps, int sa_stiter, int sa_k, double sa_lamb) {
        String HCactions;
        BeneficiInicial = estatInicial.Benefici();
        HeuristicFunction hf = null;
        switch (target) {
            case 0:
                hf = new ProblemaHeuristicaBenefici();
                break;
            case 1:
                hf = new ProblemaHeuristicaRetard();
                break;
        }

        try {
            SuccessorFunction operad = new SuccessorsHC();
            if (operadors == 1) operad = new SuccessorsHC2();
            Problem problem =  new Problem(estatInicial,operad, new ProblemaGoalTest(),hf);
            HillClimbingSearch sh =  new HillClimbingSearch();
            Date inici = new Date();
            SearchAgent agent = new SearchAgent(problem,sh);
            Date fi = new Date();
            
            //HCactions = getActions(agent.getActions());
            //printInstrumentation(agent.getInstrumentation());
            fi1 = (EstatProblema)sh.getLastSearchState();

            TimeMS_HC = ElapsedTime(inici, fi);
            BeneficiFinal_HC = fi1.Benefici();
            nodExpHC = Integer.valueOf(agent.getInstrumentation().getProperty("nodesExpanded")).intValue();
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            SuccessorFunction operad = new SuccessorsSA(seed);
            if (operadors == 1) operad = new SuccessorsSA2(seed);

            Problem problem =  new Problem(estatInicial,operad, new ProblemaGoalTest(),hf);
            SimulatedAnnealingSearch sh = new SimulatedAnnealingSearch(sa_steps,sa_stiter,sa_k,sa_lamb);
            Date inici = new Date();
            SearchAgent agent = new SearchAgent(problem,sh);
            Date fi = new Date();

            //HCactions = getActions(agent.getActions());
            //printInstrumentation(agent.getInstrumentation());
            //printActions(agent.getActions());
            fi2 = (EstatProblema)sh.getLastSearchState();

            TimeMS_SA = ElapsedTime(inici, fi);
            BeneficiFinal_SA = fi2.Benefici();
            nodExpSA = Integer.valueOf(agent.getInstrumentation().getProperty("nodesExpanded")).intValue();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void printInstrumentation(Properties properties) {
        Iterator keys = properties.keySet().iterator();
        while (keys.hasNext()) {
            String key = (String) keys.next();
            String property = properties.getProperty(key);
            System.out.println(key + " : " + property);
        }
    }
    private static void printActions(List actions) {
        for (int i = 0; i < actions.size(); i++) {
            String action = (String) actions.get(i);
            System.out.println(action);
        }
    }

    private static String getActions(List actions) {
        String ret = "";
        for (int i = 0; i < actions.size(); i++) {
            String action = (String) actions.get(i);
            ret += action;
        }
        return ret;
    }

    private static long ElapsedTime(Date i, Date f) {
        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        c1.setTime(i);
        c2.setTime(f);
        return c2.getTimeInMillis() - c1.getTimeInMillis();
    }

    public long getTimeMS(boolean hc) {
        if (hc)
            return TimeMS_HC;
        else
            return TimeMS_SA;
    }

    public int getBeneficiFinal(boolean hc) {
        if (hc)
            return BeneficiFinal_HC;
        else
            return BeneficiFinal_SA;
    }

    public int getBeneficiInicial() {
        return BeneficiInicial;
    }

    public int getNumEstatsVisitats() {
        return NumEstatsVisitats;
    }

    public int getHoresRetard(boolean hc) {
        if (hc)
            return fi1.getHoresRetard();
        else
            return fi2.getHoresRetard();
    }

    public int getEspaiSobrant(boolean hc) {
        if (hc)
            return fi1.EspaiSobrant();
        else
            return fi2.EspaiSobrant();
    }
    public int getPesTotal(boolean hc) {
        if (hc)
            return fi1.PesTotal();
        else
            return fi2.PesTotal();
    }
    public int getPesNoEntregat(boolean hc) {
        if (hc)
            return fi1.PesNoEntregat();
        else
            return fi2.PesNoEntregat();
    }
    public int getPesEntregat(boolean hc) {
        if (hc)
            return fi1.PesTotal() - fi1.PesNoEntregat();
        else
            return fi2.PesTotal() - fi2.PesNoEntregat();
    }
    public int getNumVisitats(boolean hc) {
        if (hc)
            return nodExpHC;
        else
            return nodExpSA;
    }

    public Object[][][] ObteResultats() {
        Camio lc [][] = fi1.getCamions();
        Object result[][][] = new String[2][lc.length][lc[0].length];
        for (int i = 0; i < lc.length; i++) {
            for (int j = 0; j < lc[i].length; j++) {
                result[0][i][j] = new String(lc[i][j].getPesEntregues()+"/"+lc[i][j].getCapacitat());
            }
        }

        lc = fi2.getCamions();
        for (int i = 0; i < lc.length; i++) {
            for (int j = 0; j < lc[i].length; j++) {
                result[1][i][j] = new String(lc[i][j].getPesEntregues()+"/"+lc[i][j].getCapacitat());
            }
        }
        return result;
    }
}
