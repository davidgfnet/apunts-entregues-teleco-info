
package projectecerca;

import java.util.Vector;
import javax.swing.table.DefaultTableModel;
import org.jdesktop.application.Application;
import org.jdesktop.application.SingleFrameApplication;

public class ProjecteCercaApp extends SingleFrameApplication {

    @Override protected void startup() {
        show(new VistaPrincipal());
    }

    @Override protected void configureWindow(java.awt.Window root) {
    }

    public static ProjecteCercaApp getApplication() {
        return Application.getInstance(ProjecteCercaApp.class);
    }

    public static void main(String[] args) {
        launch(ProjecteCercaApp.class, args);
        /*
        int numC= 250;
        int hora_probs[] = new int[10];
        int ini = 3;
        boolean usehc = true;
        hora_probs[0] = hora_probs[1] = hora_probs[2] = 100;
        hora_probs[3] = hora_probs[4] = hora_probs[5] = 100;
        hora_probs[6] = hora_probs[7] = hora_probs[8] = 100;
        hora_probs[9] = 100;

        hora_probs[3] = 200;
        hora_probs[4] = 200;
        hora_probs[5] = 200;
        hora_probs[6] = 200;

        int centre_probs[] = new int[6];
        centre_probs[0] = centre_probs[1] = centre_probs[2] = 100;
        centre_probs[3] = centre_probs[4] = centre_probs[5] = 100;
        //centre_probs[5] = 500;
        ProblemaCamions p = null;

        int time_avg = 0;
        int ben_avg = 0;

        for (int seed = 1; seed <= 10; seed++) {
            int avg1 = 0;
            int avg2 = 0;
            int avg3 = 0;
            for (int seed2 = 1; seed2 <= 5; seed2++) {
                Integer values[] = ProblemaCamions.GeneraCondicionsInicials(seed,numC,hora_probs,centre_probs);

                int cams[] = new int[3];
                cams[0] = values[0];
                cams[1] = values[1];
                cams[2] = values[2];

                Vector < Vector < String >> taula = new Vector<Vector<String>>();
                taula.setSize(numC);
                for (int i = 0; i < numC; i++) {
                    taula.set(i, new Vector <String> (3));
                    taula.get(i).setSize(3);
                    taula.get(i).set(0,new String(Integer.toString(values[3*i+0+3])));
                    taula.get(i).set(1,new String(Integer.toString(values[3*i+1+3])));
                    taula.get(i).set(2,new String(Integer.toString(values[3*i+2+3])));
                }

                p = new ProblemaCamions(cams,taula,ini,seed2);

                p.ResolProblema(0,seed,1,  50000,100,5,0.005);

                if (ini == 2) {
                    avg1 += p.getBeneficiInicial();
                    avg2 += p.getBeneficiFinal(usehc);
                    avg3 += p.getTimeMS(usehc);
                }else{
                    break;
                }
            }
            if (ini == 2) {
                System.out.print("Seed: " + seed + " Bini = " + (avg1/5) + " Bfi = " + (avg2/5) + " T: " + avg3 + "\n");
                time_avg += avg3;
                ben_avg += avg2;
            } else {
                System.out.print("Seed: " + seed + " Bini = " + p.getBeneficiInicial() + " Bfi = " + p.getBeneficiFinal(usehc) + " Hret: " + p.getHoresRetard(usehc) + " T: " + p.getTimeMS(usehc) + "\n");
                time_avg += p.getTimeMS(usehc);
                ben_avg += p.getBeneficiFinal(usehc);
            }
        }
        System.out.print("Time AVG: " + (time_avg/30) + "\n");
        System.out.print("Benf AVG: " + (ben_avg/30) + "\n");
         * */
    }
}
