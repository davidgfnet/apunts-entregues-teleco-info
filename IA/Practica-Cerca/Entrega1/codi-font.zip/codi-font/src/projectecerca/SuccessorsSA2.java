
package projectecerca;

import aima.search.framework.Successor;
import aima.search.framework.SuccessorFunction;
import java.util.*;


public class SuccessorsSA2 implements SuccessorFunction {
    private Random rg;

    public SuccessorsSA2(int seed) {
        rg = new Random(seed);
    }

    public List getSuccessors(Object aState) {
        ArrayList retVal = new ArrayList();
        EstatProblema state = (EstatProblema)aState;
        Camio[][] llcam = state.getCamions();
        Vector <Entrega> entNoFetes = state.getEntreguesSenseCamio();

        // Triem un operador a l'atzar!
        while (true) {
            int op = rg.nextInt(3);

            switch (op) {
                case 0: {
                    // OP 0 a l'atzar, triar una hora i un paquet
                    if (entNoFetes.size() == 0) continue;
                    int n1 = rg.nextInt(entNoFetes.size());
                    int n2 = rg.nextInt(ProblemaCamions.numHores);

                    int numcentre = entNoFetes.get(n1).getNumCentre();
                    int pes = entNoFetes.get(n1).getPes();
                    if (llcam[n2][numcentre].EspaiLliure() >= pes) {
                        EstatProblema nou = new EstatProblema(state);
                        nou.CamioFesEntrega(n1, n2, numcentre);
                        retVal.add(new Successor(new String("Entrega " + n1 + " " + n2 + " " + numcentre), nou));
                        return retVal;
                    }
                } break;
                case 1: {

                // Operador 1: Girar paquets entre la cua de paquets que no s'entreguen
                // i un paquet d'un camió
                if (entNoFetes.size() > 0) {
                    int i = rg.nextInt(entNoFetes.size());
                    int numcentre = entNoFetes.get(i).getNumCentre();
                    int pes = entNoFetes.get(i).getPes();
                    int h = rg.nextInt(ProblemaCamions.numHores);
                    Vector <Entrega> entr = llcam[h][numcentre].getEntregues();
                    if (entr.size() > 0) {
                        int j = rg.nextInt(entr.size());
                                            if (llcam[h][numcentre].EspaiLliure() - pes + entr.get(j).getPes() >= 0) {
                            EstatProblema nou = new EstatProblema(state);
                            nou.CamioAnulaEntrega(j, h, numcentre);
                            nou.CamioFesEntrega(i, h, numcentre);
                            retVal.add(new Successor(new String("Gira de la cua de no entregats ("
                                    + i + "," + j + ")" + h + " " + numcentre), nou));
                        }
                    }
                }

                } break;
                case 2: {
                // Segon operador: Aquest sempre genera algun successor vàlid, ni que
                // sigui poc beneficiós!
                    int c1 = rg.nextInt(ProblemaCamions.numCentres);
                    int h1 = rg.nextInt(ProblemaCamions.numHores);
                    int c2 = rg.nextInt(ProblemaCamions.numCentres-c1) + c1;
                    int h2;
                    if (c1 == c2) {
                        if (h1 == ProblemaCamions.numHores-1) continue;
                        h2 = rg.nextInt(ProblemaCamions.numHores - h1 - 1) + h1 + 1;
                    }
                    else h2 = rg.nextInt(ProblemaCamions.numHores);

                    Camio cam1 = llcam[h1][c1]; // BIG
                    Camio cam2 = llcam[h2][c2]; // LITTLE
                    // Swap si necessari
                    if (cam1.getCapacitat() != cam2.getCapacitat()) {
                        EstatProblema nou = new EstatProblema(state);

                        if (cam1.getCapacitat() < cam2.getCapacitat())
                            nou.GiraCamions(c2, c1, h2, h1);
                        else
                            nou.GiraCamions(c1, c2, h1, h2);

                        String str = new String(
                                   "Gira dos camions de centres ("+c1+","+c2+") i hores ("
                                   +h1+","+h2+")");
                        retVal.add(new Successor(str, nou));
                        return retVal;
                    }
                } break;
            }
        }
    }

}
