
package projectecerca;

/*
 * Descriu una entrega (o també anomenada petició)
 */
public class Entrega implements Comparable {
    private int numCentre;   // Va de 0 a 5
    private int horaEntrega; // Va de 0 a 9
    private int pes;         // de 100 a 500 en intervals de 100

    public Entrega(int numCentre, int horaEntrega, int pes) {
        this.numCentre = numCentre;
        this.horaEntrega = horaEntrega;
        this.pes = pes;
    }
    // COPY!
    public Entrega(Entrega or) {
        numCentre = or.numCentre;
        horaEntrega = or.horaEntrega;
        pes = or.pes;
    }
    public int getNumCentre() {
        return numCentre;
    }
    public int geHoraEntrega() {
        return horaEntrega;
    }
    public int getPes() {
        return pes;
    }

    /*
     * Calcula el guany que es produiria si l'entrega és entregada a
     * l'hora indicada
     */
    public int CalculaGuany(int hora) {
        int guany;
        if (pes <= 200) guany = pes;
        else if (pes <= 400) guany = (pes+pes/2);
        else guany = 2*pes;

        if (horaEntrega >= hora) {
            // Arriba a l'hora o abans
            return guany;
        }else{
            // Arriba tard
            int retard = hora - horaEntrega;
            return guany - (2*retard*guany)/10;
        }
    }

    /*
     * Calcula el guany (negatiu obviament) de no entregar
     * la comanda
     * TODO No entenc aquest punt de l'enunciat, preguntar profe!
     */
    public int CalculaGuanyNoEntregada() {
        int guany;
        if (pes <= 200) guany = pes;
        else if (pes <= 400) guany = (pes+pes/2);
        else guany = 2*pes;

        int retard = 9 - horaEntrega;
        return -(retard*2*guany)/10-guany;
    }

    public int compareTo(Object o) {
        int dh = ((Entrega)o).horaEntrega - horaEntrega;
        if (dh != 0) return dh;
        return ((Entrega)o).pes - pes;
    }

    public int HoresRetras(int hora) {
        if (hora < 0) {
            // No entregat!
            return this.horaEntrega + 15;
        }else{
            if (this.horaEntrega >= hora) return 0;
            else return 9 - this.horaEntrega;
        }
    }
}
