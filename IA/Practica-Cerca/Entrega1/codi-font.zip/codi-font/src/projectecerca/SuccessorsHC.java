
package projectecerca;

import aima.search.framework.Successor;
import aima.search.framework.SuccessorFunction;
import java.util.*;

/*
 * Generació  de successors. Important! Donat que copiar un estat és
 * costós no el copiarem fins que no veiem que aquella operació és
 * factible ni que això reporti més comprovacions de les necessàries.
 * La majoria d'operadors generen en la realitat poques oportunitats
 * en relació al màxim possible (sobretot les de combinatòria).
 */
public class SuccessorsHC implements SuccessorFunction {

    public List getSuccessors(Object aState) {
        ArrayList retVal = new ArrayList();
        EstatProblema state = (EstatProblema)aState;
        Camio[][] llcam = state.getCamions();

        // Operador 0 (base): Intentar afegir un paquet a algun camio
        // del vector de paquets no entregats
        Vector <Entrega> entNoFetes = state.getEntreguesSenseCamio();
        for (int i = 0; i < entNoFetes.size(); i++) {
            int numcentre = entNoFetes.get(i).getNumCentre();
            int pes = entNoFetes.get(i).getPes();
            for (int h = 0; h < ProblemaCamions.numHores; h++) {
                if (llcam[h][numcentre].EspaiLliure() >= pes) {
                    EstatProblema nou = new EstatProblema(state);
                    nou.CamioFesEntrega(i, h, numcentre);
                    retVal.add(new Successor(new String("Entrega " + i + " " + h + " " + numcentre), nou));
                }
            }
        }

        // Operador antic eliminat: treure paquets, no té sentit la solució és pitjor!

        // Operador 1: Gira parells de paquets (si es poden girar)
        for (int i = 0; i < ProblemaCamions.numCentres; i++) {
            for (int h = 0; h < ProblemaCamions.numHores; h++) {
                for (int h2 = h+1; h2 < ProblemaCamions.numHores; h2++) {
                    // Fixats 2 camios del centre 'i' a hores h i h2, girar paquet!
                    int n1 = llcam[h][i].getNumEntregues();
                    int n2 = llcam[h2][i].getNumEntregues();
                    if (n1 != 0 && n2 != 0) {
                        for (int i1 = 0; i1 < n1; i1++) {
                            for (int i2 = 0; i2 < n2; i2++) {
                                if (state.PossibleIntercanviPaquets(i,h,h2,i1,i2)) {
                                    EstatProblema nou = new EstatProblema(state);
                                    nou.IntercanviaPaquets(i,h,h2,i1,i2);
                                    String str = new String(
                                               "Intercanvia al centre " + i +
                                               " el paquet del camió de les " + h +
                                               " numero " +i1 + "pel del camió de les " +
                                               h2 + " paquet num " + i2);
                                    retVal.add(new Successor(str, nou));
                                }
                            }
                        }
                    }else if (n1 == 0){
                        for (int i2 = 0; i2 < n2; i2++) {
                            EstatProblema nou = new EstatProblema(state);
                            if (state.PossiblePasPaquet(i,h2,h,i2)) {
                                nou.PassaPaquet(i,h2,h,i2);
                                String str = new String(
                                           "Passa paquet: (centre " + i +
                                           ") el paquet del camió de les " + h2 +
                                           " numero " + i2 + " al camió de les " + h);
                                retVal.add(new Successor(str, nou));
                            }
                        }
                    }else if (n2 == 0) {
                        for (int i1 = 0; i1 < n1; i1++) {
                            EstatProblema nou = new EstatProblema(state);
                            if (state.PossiblePasPaquet(i,h,h2,i1)) {
                                nou.PassaPaquet(i,h,h2,i1);
                                String str = new String(
                                           "Passa paquet: (centre " + i +
                                           ") el paquet del camió de les " + h +
                                           " numero " + i1 + " al camió de les " + h2);
                                retVal.add(new Successor(str, nou));
                            }
                        }
                    }
                }
            }
        }

        // Segon operador: intercanviar dos camions. Per a fer-ho bé i que
        // s'intercanviin camions de diferent capacitat, l'operació de swap
        // gira els camions i intenta reolocar els paquets sobrants
        // a la vegada que aprofitar l'espai lliure que ha quedat de la millor
        // forma possible (molt conservador, només genera 1 successor per cada
        // parell de camions quan realment hi poden haver moltes combincacions
        // de recolocació de paquets).
        
        for (int c1 = 0; c1 < ProblemaCamions.numCentres; c1++) {
            for (int h1 = 0; h1 < ProblemaCamions.numHores; h1++) {
                for (int c2 = c1; c2 < ProblemaCamions.numCentres; c2++) {
                    for (int h2 = (c1 == c2) ? h1+1 : 0; h2 < ProblemaCamions.numHores; h2++) {
                        Camio cam1 = llcam[h1][c1]; // BIG
                        Camio cam2 = llcam[h2][c2]; // LITTLE
                        // Swap si necessari
                        if (cam1.getCapacitat() == cam2.getCapacitat()) continue;
                        EstatProblema nou = new EstatProblema(state);

                        if (cam1.getCapacitat() < cam2.getCapacitat())
                            nou.GiraCamions(c2, c1, h2, h1);
                        else
                            nou.GiraCamions(c1, c2, h1, h2);

                        String str = new String(
                                   "Gira dos camions de centres ("+c1+","+c2+") i hores ("
                                   +h1+","+h2+")");
                        retVal.add(new Successor(str, nou));
                    }
                }
            }
        }

        return retVal;
    }

}
