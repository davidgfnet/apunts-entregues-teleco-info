
package projectecerca;

import aima.search.framework.Successor;
import aima.search.framework.SuccessorFunction;
import java.util.*;

/*
 * Generació  de successors. Important! Donat que copiar un estat és
 * costós no el copiarem fins que no veiem que aquella operació és
 * factible ni que això reporti més comprovacions de les necessàries.
 * La majoria d'operadors generen en la realitat poques oportunitats
 * en relació al màxim possible (sobretot les de combinatòria).
 */
public class SuccessorsHC2 implements SuccessorFunction {

    public List getSuccessors(Object aState) {
        ArrayList retVal = new ArrayList();
        EstatProblema state = (EstatProblema)aState;
        Camio[][] llcam = state.getCamions();

        // Operador 0 (base): Intentar afegir un paquet a algun camio
        // del vector de paquets no entregats
        Vector <Entrega> entNoFetes = state.getEntreguesSenseCamio();
        for (int i = 0; i < entNoFetes.size(); i++) {
            int numcentre = entNoFetes.get(i).getNumCentre();
            int pes = entNoFetes.get(i).getPes();
            for (int h = 0; h < ProblemaCamions.numHores; h++) {
                if (llcam[h][numcentre].EspaiLliure() >= pes) {
                    EstatProblema nou = new EstatProblema(state);
                    nou.CamioFesEntrega(i, h, numcentre);
                    retVal.add(new Successor(new String("Entrega " + i + " " + h + " " + numcentre), nou));
                }
            }
        }

        // Operador 1: Girar paquets entre la cua de paquets que no s'entreguen
        // i un paquet d'un camió
        for (int i = 0; i < entNoFetes.size(); i++) {
            int numcentre = entNoFetes.get(i).getNumCentre();
            int pes = entNoFetes.get(i).getPes();
            for (int h = 0; h < ProblemaCamions.numHores; h++) {
                Vector <Entrega> entr = llcam[h][numcentre].getEntregues();
                for (int j = 0; j < entr.size(); j++) {
                    if (llcam[h][numcentre].EspaiLliure() - pes + entr.get(j).getPes() >= 0) {
                        EstatProblema nou = new EstatProblema(state);
                        nou.CamioAnulaEntrega(j, h, numcentre);
                        nou.CamioFesEntrega(i, h, numcentre);
                        retVal.add(new Successor(new String("Gira de la cua de no entregats ("
                                + i + "," + j + ")" + h + " " + numcentre), nou));
                    }
                }
            }
        }

        for (int c1 = 0; c1 < ProblemaCamions.numCentres; c1++) {
            for (int h1 = 0; h1 < ProblemaCamions.numHores; h1++) {
                for (int c2 = c1; c2 < ProblemaCamions.numCentres; c2++) {
                    for (int h2 = (c1 == c2) ? h1+1 : 0; h2 < ProblemaCamions.numHores; h2++) {
                        Camio cam1 = llcam[h1][c1]; // BIG
                        Camio cam2 = llcam[h2][c2]; // LITTLE
                        // Swap si necessari
                        if (cam1.getCapacitat() == cam2.getCapacitat()) continue;
                        EstatProblema nou = new EstatProblema(state);

                        if (cam1.getCapacitat() < cam2.getCapacitat())
                            nou.GiraCamions(c2, c1, h2, h1);
                        else
                            nou.GiraCamions(c1, c2, h1, h2);

                        String str = new String(
                                   "Gira dos camions de centres ("+c1+","+c2+") i hores ("
                                   +h1+","+h2+")");
                        retVal.add(new Successor(str, nou));
                    }
                }
            }
        } 

        return retVal;
    }

}
