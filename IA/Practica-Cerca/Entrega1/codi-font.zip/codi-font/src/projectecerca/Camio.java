
package projectecerca;

import java.util.*;

public class Camio {
    private Vector<Entrega> entregues;
    private int capacitat;
    private int espaiLliure;

    public Camio(int capacitat) {
        this.capacitat = capacitat;
        this.espaiLliure = capacitat;
        entregues = new Vector<Entrega>();
    }
    // DEEP COPY (no cal copiar entregues ja que son immutables)
    public Camio(Camio or) {
        capacitat = or.capacitat;
        espaiLliure = or.espaiLliure;

        entregues = new Vector<Entrega>(or.entregues);
    }
    
    public boolean AfegirEntrega(Entrega e) {
        entregues.add(e);
        espaiLliure -= e.getPes();
        if (espaiLliure < 0) {
            System.out.print("ERR");
        }
        return (espaiLliure>=0);
    }
    public int EspaiLliure() {
        return this.espaiLliure;
    }
    public int getNumEntregues() {
        return entregues.size();
    }
    public Entrega TreureEntrega(int index) {
        Entrega ret = entregues.get(index);
        espaiLliure += ret.getPes();
        entregues.remove(index);
        return ret;
    }
    public Entrega getEntrega(int index) {
        return entregues.get(index);
    }
    public Vector<Entrega> getEntregues() {
        return new Vector<Entrega> (entregues);
    }
    public void setEntregues(Vector<Entrega> ent) {
        entregues = ent;
        espaiLliure = capacitat-getPesEntregues();
    }
    public void buidaEntregues() {
        entregues.clear();
        espaiLliure = capacitat;
    }
    public int getCapacitat() {
        return capacitat;
    }

    public int getPesEntregues() {
        int p = 0;
        for (int i = 0; i < entregues.size(); i++)
            p += entregues.get(i).getPes();
        return p;
    }
    public int getBenefici(int hora) {
        int b = 0;
        for (int i = 0; i < entregues.size(); i++)
            b += entregues.get(i).CalculaGuany(hora);
        return b;
    }
    public int getHoresRetard(int hora) {
        int r = 0;
        for (int i = 0; i < entregues.size(); i++)
            r += entregues.get(i).HoresRetras(hora);

        return r;
    }
}
