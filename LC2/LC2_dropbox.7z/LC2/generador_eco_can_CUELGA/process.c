#include <math.h>
#include <stdlib.h>
#include "block.h"

#define PI 3.141592654

// Generador d'eco
float hFIR[L_FIR] = {0,0,0,0,0.3,0,0,0,0,0,0};
float guany = 0;
float retard_gran[D+L_FIR] = {0};
float * retard = &retard_gran[L_FIR];

// Cancel�lador d'eco
#define La 11 
#define Lh La 
#define N 200 
#define D 2500 
#define M (N+D+La-1) 
#define PMIN 10000 
#define BETA 0.95 
#define MU 0.01 

float aFIR[L_FIR] = {0,0,0,0,0.3,0,0,0,0,0,0};
float y_can[M];


void inicialitzacio() {
	int i;
	guany = 0;
	for (i = 0; i< L_FIR; i++)
		guany += hFIR[i]*hFIR[i];

	guany = sqrtf(1-guany);

	for (i = 0; i < D+L_FIR; i++)
		retard_gran[i] = 0;

	for (i = 0; i < M; i++) {
		y_can[i] = 0;
	}
}

void fir(float *x, float *y, float *h, int k, int n) {
	int i,j;
	for (i = 0; i < n; i++) {
		float accum = 0;
		for (j = 0; j < k; j++)
			accum += h[j]*x[i-j];
		y[i] = accum;
	}
}


void processFIR(float *block, float *h)
{
    int i;
    static float x[(L_FIR-1)+N] = {0};         // FIR Input buffer             

    for (i=0; i<N; i++) x[L_FIR-1+i] = block[i];
    fir(&x[L_FIR], block, h, L_FIR, N);
    for (i=0; i<(L_FIR-1); i++) x[i] = x[i+N];
}

void processFIR2(float *block, float *h)
{
    int i;
    static float x[(L_FIR-1)+N] = {0};         // FIR Input buffer             

    for (i=0; i<N; i++) x[L_FIR-1+i] = block[i];
    fir(&x[L_FIR], block, h, L_FIR, N);
    for (i=0; i<(L_FIR-1); i++) x[i] = x[i+N];
}


void calculaEco(float * io_block) {
	int i, j = 0;
	processFIR(retard,hFIR);	    // Procesa bloque
	for (i = 0; i < N; i++)
		io_block[i] = io_block[i]*guany + retard[i];
	for (i = N; i < D; i++)
		retard[i-N] = retard[i];
	for (i = D-N; i < D; i++)
		retard[i] = io_block[j++];
}


void can_eco(float * io_block) {
	int i,j,k;
	float tmp1,tmp2;
	float p=PMIN;
	float * h = aFIR;
	for(i=0;i<M-N;i++)
		y_can[i]=y_can[i+N];
	/*Guardem les mostres noves*/
	for(i=0;i<N;i++)
		y_can[M-N+i]=io_block[i];
	/*Processament de les dades*/
	for(i=0;i<N;i++){
		tmp1=0;
		for(k=0;k<Lh;k++)
			tmp1+=h[k]*y_can[M-N-D-k+i];
		io_block[i]-=tmp1;
		/*C�lcul de MU NLMS*/
		tmp2=0;
		for(j=0;j<Lh;j++)
			tmp2+=(y_can[M-N-D-j+i])*(y_can[M-N-D-j+i]);
		p=BETA*p+tmp2*(1-BETA);
		tmp2=MU/(p+PMIN);
		/*Actualitzaci� dels coeficients del filtre*/
		for(j=0;j<Lh;j++)
			h[j]+=tmp2*y_can[M-N-D+i-j]*io_block[i];
	}
}
