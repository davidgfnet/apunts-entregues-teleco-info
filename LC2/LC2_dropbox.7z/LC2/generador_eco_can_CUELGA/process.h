void inicialitzacio();
void processFIR(float *, float *);
void calculaEco(float * io_block);
void can_eco(float * io_block);