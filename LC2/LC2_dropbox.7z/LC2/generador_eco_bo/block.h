#define N 			1000
#define L_FIR 		11      // Orden del filtro FIR + 1
#define D			2400


