void inicialitzacio();
void processFIR(float *, float *);
void calculaEco(float * io_block);


