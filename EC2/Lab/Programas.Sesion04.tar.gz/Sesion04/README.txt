Para compilar/ejecutar el fichero de prueba, seguid los siguientes pasos:

$> gcc Main.c FusionOriginal.c -o TEST
$> ./TEST


Para compilar/ejecutar el fichero de trabajo, seguid los siguientes pasos:

$> gcc Main.c Fusion.s -o FUSION 
$> ./FUSION


