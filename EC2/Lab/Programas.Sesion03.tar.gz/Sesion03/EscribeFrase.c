#include <stdio.h>

char v[100] = "Esto es una frase acabada en un salto de linea.\n";
int cont;

main()
{
  int i;

  cont = 0;
  i = 0;

  do {
    printf("%c", v[i]);
    if (v[i] == 'a') cont++;
    i++;
  } while (v[i] != '\n');

  printf("\nLa frase tiene %d a's.\n", cont);

}


