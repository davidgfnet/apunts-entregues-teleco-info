/****************************************************************************
** Meta object code from reading C++ file 'materialwidget.h'
**
** Created: Sat Jan 1 23:48:49 2011
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "materialwidget.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'materialwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MaterialWidget[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: signature, parameters, type, tag, flags
      16,   15,   15,   15, 0x05,
      39,   15,   15,   15, 0x05,
      55,   15,   15,   15, 0x05,

 // slots: signature, parameters, type, tag, flags
      72,   15,   15,   15, 0x0a,
     117,   88,   15,   15, 0x0a,
     190,   15,   15,   15, 0x0a,
     206,   15,   15,   15, 0x0a,
     224,   15,   15,   15, 0x0a,
     233,   15,   15,   15, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MaterialWidget[] = {
    "MaterialWidget\0\0MaterialChange(float*)\0"
    "MaterialApply()\0MaterialRevert()\0"
    "MakeInvisible()\0ar,ag,ab,dr,dg,db,sr,sg,sb,s\0"
    "MakeVisible(float,float,float,float,float,float,float,float,float,floa"
    "t)\0"
    "ValuesUpdated()\0ComboChanged(int)\0"
    "Aplica()\0Revert()\0"
};

const QMetaObject MaterialWidget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_MaterialWidget,
      qt_meta_data_MaterialWidget, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MaterialWidget::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MaterialWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MaterialWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MaterialWidget))
        return static_cast<void*>(const_cast< MaterialWidget*>(this));
    return QWidget::qt_metacast(_clname);
}

int MaterialWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: MaterialChange((*reinterpret_cast< float*(*)>(_a[1]))); break;
        case 1: MaterialApply(); break;
        case 2: MaterialRevert(); break;
        case 3: MakeInvisible(); break;
        case 4: MakeVisible((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3])),(*reinterpret_cast< float(*)>(_a[4])),(*reinterpret_cast< float(*)>(_a[5])),(*reinterpret_cast< float(*)>(_a[6])),(*reinterpret_cast< float(*)>(_a[7])),(*reinterpret_cast< float(*)>(_a[8])),(*reinterpret_cast< float(*)>(_a[9])),(*reinterpret_cast< float(*)>(_a[10]))); break;
        case 5: ValuesUpdated(); break;
        case 6: ComboChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: Aplica(); break;
        case 8: Revert(); break;
        default: ;
        }
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void MaterialWidget::MaterialChange(float * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MaterialWidget::MaterialApply()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void MaterialWidget::MaterialRevert()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}
QT_END_MOC_NAMESPACE
