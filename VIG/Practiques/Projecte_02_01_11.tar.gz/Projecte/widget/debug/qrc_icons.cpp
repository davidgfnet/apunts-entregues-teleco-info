/****************************************************************************
** Resource object code
**
** Created: Sun Jan 2 01:21:53 2011
**      by: The Resource Compiler for Qt version 4.6.3
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <QtCore/qglobal.h>

QT_BEGIN_NAMESPACE

QT_END_NAMESPACE


int QT_MANGLE_NAMESPACE(qInitResources_icons)()
{
    return 1;
}

Q_CONSTRUCTOR_FUNCTION(QT_MANGLE_NAMESPACE(qInitResources_icons))

int QT_MANGLE_NAMESPACE(qCleanupResources_icons)()
{
    return 1;
}

Q_DESTRUCTOR_FUNCTION(QT_MANGLE_NAMESPACE(qCleanupResources_icons))

