#include "scene.h"
#include <math.h>
#include <GL/glu.h>

MaterialLib Scene::matlib;

Scene::Scene()
{
  zoom = 1;
  hangle = vangle = 0;
  wireframe = false;
  ratio = 1;
}

void Scene::Init()
{
  construirBase ();
}

void Scene::construirBase ()
{
  Model b("Base");

  // Construim el poligon base
  Vertex v1(Point(-5,0,-5));
  Vertex v2(Point(-5,0,5));
  Vertex v3(Point(5,0,5));
  Vertex v4(Point(5,0,-5));
  b.vertices.push_back(v1);
  b.vertices.push_back(v2);
  b.vertices.push_back(v3);
  b.vertices.push_back(v4);

  Face face(0,1,2,3);
  face.normal = Vector(0,1,0);
  face.material = 0;
  b.faces.push_back(face);

  lmodels.push_back(b);
  Objecte oref("Base", 0, Point(0,0,0), 1, 0);
  lobjectes.push_back(oref);
}

void Scene::Render()
{
  // Cal pintar tots els objectes de l'escena que es troben al vector

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(45, ratio, 2.0f, 100.0f);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glEnable(GL_CULL_FACE);
  if (wireframe) glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
  else glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);

  glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
  gluLookAt(zoom*cos(hangle*M_PI/180.0f)*cos(vangle*M_PI/180.0f),
            zoom*sin(vangle*M_PI/180.0f),
            zoom*sin(hangle*M_PI/180.0f)*cos(vangle*M_PI/180.0f), 0,0,0 ,0,1,0);

  for (unsigned int i = 0; i < lobjectes.size(); i++) {
    lobjectes[i].Render(lmodels);
  }
}

void Scene::LoadObject(std::string file)
{
  // Search if the model is already in use by (maybe) another object
  int model_index = -1;
  for (unsigned int i = 0; i < lmodels.size(); i++) {
    if (lmodels[i].getName() == file) {
      model_index = i;
      break;
    }
  }

  if (model_index == -1) {
    Model mod (file);
    mod.readObj(file.c_str(),Scene::matlib);
    lmodels.push_back(mod);
    model_index = lmodels.size()-1;
  }
  
  Objecte obj(file, model_index, Point(0,0,0),1,90);
  lobjectes.push_back(obj);
}

void Scene::SetZoom(int z) {
  zoom = z;
}

void Scene::UpdateHAngle(int a) {
  hangle = a;
}

void Scene::UpdateVAngle(int a) {
  vangle = a;
}

void Scene::setWireframe(bool w) {
  wireframe = w;
}
void Scene::ResetCamera() {

}
void Scene::setHiddenPartRemoval(bool r) {
  
}
void Scene::setAspectRatio(float r) {
  ratio = r;
}

// Posiciona l'objecte a la posició esmentada.
// Cal calcular l'offset, ja que hem de situar el centre
// de la base de la bounding box
void Scene::SetLastObjectPosition(Vector pos) {
  if (lobjectes.size() > 0)
    lobjectes[lobjectes.size()-1].setPositionBBBase(pos,lmodels);
}
void Scene::SetLastObjectRotation(int inc) {
  if (lobjectes.size() > 0)
    lobjectes[lobjectes.size()-1].setOrientation(lobjectes[lobjectes.size()-1].getOrientation()+inc*10.0f);
}


