#ifndef GLWIDGET_H
#define GLWIDGET_H

#include <QGLWidget>
#include <QMouseEvent>
#include <QKeyEvent>
#include <QFileDialog>
#include "point.h"
#include "scene.h"

class GLWidget : public QGLWidget
{
    Q_OBJECT

public:
    GLWidget(QWidget *parent = 0);
    virtual ~GLWidget();

protected:
    void initializeGL ();

    void paintGL ();
    void resizeGL (int width, int height);
    Vector UnprojectPoint(int x, int y);

    virtual void mousePressEvent (QMouseEvent *e);
    virtual void mouseReleaseEvent (QMouseEvent *e);
    virtual void mouseMoveEvent (QMouseEvent *e);
    virtual void keyPressEvent (QKeyEvent *event);

    double dist, anterior, posterior, radi, angleX, angleY, anglecam, ra;
    Point VRP;
    Scene scene;
    int vp_h,vp_w;

    typedef  enum {NONE, ROTATE, ZOOM, PAN, SITUA} InteractiveAction;
    InteractiveAction DoingInteractive;

    int   xClick, yClick;

 public slots:
     void LoadObject ();
     void UpdateZoom(int);
     void UpdateHAngle(int);
     void UpdateVAngle(int);
     void setWireframe(bool);
     void setHiddenPartRemoval(bool);
     void ResetCamera();
};

#endif
