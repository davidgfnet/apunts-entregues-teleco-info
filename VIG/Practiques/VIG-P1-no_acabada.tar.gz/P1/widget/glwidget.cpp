#include "glwidget.h"
#include <math.h>

GLWidget::GLWidget(QWidget *parent) :
    QGLWidget(parent)
{
  this->setMouseTracking(true);
  this->setFocusPolicy(Qt::StrongFocus);
  this->grabKeyboard();
}

GLWidget::~GLWidget() {
  this->releaseKeyboard();
}

void GLWidget::initializeGL()
{
  glClearColor(0.4f, 0.4f, 0.8f, 1.0f);
  glEnable(GL_DEPTH_TEST);
  scene.Init();
}
void GLWidget::resizeGL (int width, int height)
{
  vp_w = width;
  vp_h = height;
  scene.setAspectRatio(float(vp_w)/float(vp_h));
  glViewport (0, 0, width, height);
}

void GLWidget::paintGL( void )
{
  // Esborrem els buffers
  glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

  // dibuixar eixos aplicacio
  glDisable(GL_LIGHTING);
  glBegin(GL_LINES);
  glColor3f(1,0,0); glVertex3f(0,0,0); glVertex3f(20,0,0); // X
  glColor3f(0,1,0); glVertex3f(0,0,0); glVertex3f(0,20,0); // Y
  glColor3f(0,0,1); glVertex3f(0,0,0); glVertex3f(0,0,20); // Z
  glEnd();

  scene.Render();
}

void GLWidget::mousePressEvent( QMouseEvent *e) {
  xClick = e->x();
  yClick = e->y();

  if (DoingInteractive == SITUA) {
    DoingInteractive = NONE;
  }

  if (e->button()&Qt::LeftButton &&
      ! (e->modifiers()&(Qt::ShiftModifier|Qt::AltModifier|Qt::ControlModifier)))
  {
    DoingInteractive = ROTATE;
  }
  else if (e->button()&Qt::LeftButton &&  e->modifiers() &Qt::ShiftModifier)
  {
    DoingInteractive = ZOOM;
  }
  else if (e->button()&Qt::LeftButton &&  e->modifiers() &Qt::ControlModifier)
  {
      DoingInteractive = PAN;
  }
}

void GLWidget::keyPressEvent(QKeyEvent *e)
{
  switch (e->key())
  {
    case Qt::Key_X:
        if (DoingInteractive == SITUA) {
          scene.SetLastObjectRotation(-1);
          Vector punt = this->UnprojectPoint(xClick,yClick);
          scene.SetLastObjectPosition(punt);
          updateGL();
        } break;
    case Qt::Key_Z:
        if (DoingInteractive == SITUA) {
          scene.SetLastObjectRotation(1);
          Vector punt = this->UnprojectPoint(xClick,yClick);
          scene.SetLastObjectPosition(punt);
          updateGL();
        } break;
    case Qt::Key_F:
        scene.setWireframe(true);
        updateGL();
        break;
    case Qt::Key_S:
        scene.setWireframe(false);
        updateGL();
        break;
    default: e->ignore();
  }
}

void GLWidget::mouseReleaseEvent( QMouseEvent *)
{
  DoingInteractive = NONE;
}

void GLWidget::mouseMoveEvent(QMouseEvent *e)
{
  // Aqui cal que es calculi i s'apliqui la rotaci, el zoom o el pan
  // com s'escaigui...
  if (DoingInteractive == ROTATE)
  {
    // Fem la rotacio

  }
  else if (DoingInteractive == ZOOM)
  {
    // Fem el zoom

  }
  else if (DoingInteractive==PAN)
  {
    // Fem el pan

  }
  else if (DoingInteractive==SITUA)
  {
    Vector punt = this->UnprojectPoint(e->x(),e->y());
    scene.SetLastObjectPosition(punt);
    this->updateGL();
  }

  xClick = e->x();
  yClick = e->y();
}

void GLWidget::LoadObject()
{
  QString model = QFileDialog::getOpenFileName(this, tr("Open File"), "../data", tr("Objectes (*.obj)"));
  if (model != "") {
    scene.LoadObject(model.toStdString());
    DoingInteractive=SITUA;
  }
  this->updateGL();
}

void GLWidget::UpdateZoom(int z) {
  scene.SetZoom(z);
  this->updateGL();
}

void GLWidget::UpdateHAngle(int a) {
  scene.UpdateHAngle(a);
  this->updateGL();
}

void GLWidget::UpdateVAngle(int a) {
  scene.UpdateVAngle(a);
  this->updateGL();
}

void GLWidget::setWireframe(bool wf) {
  scene.setWireframe(wf);
  this->updateGL();
}
void GLWidget::setHiddenPartRemoval(bool r) {
  
}

void GLWidget::ResetCamera() {
  scene.ResetCamera();
  this->updateGL();
}

Vector GLWidget::UnprojectPoint(int x, int y) {
  // Cal obtenir la coordenada 3D del punt al que estem. Donat que la funció
  // de projecció no és bijectiva (R³ -> R²) existeixen infinits punts que
  // compleixen l'equació. Trobarem dos punts (qualsevols) i farem una recta.
  // Aleshores podem tribar el punt fent intersecció entre recta i pla (o
  // triangle si s'escau).

  y = vp_h - y;  // Conversió a coordenades de OGL

  GLdouble pos1[3],pos2[3];
  GLdouble mmodel[16]; GLdouble mproj[16];
  GLint viewp[4];
  glGetDoublev(GL_MODELVIEW_MATRIX,mmodel);
  glGetDoublev(GL_PROJECTION_MATRIX,mproj);
  viewp[0] = viewp[1] = 0; viewp[2] = vp_w; viewp[3] = vp_h;
  gluUnProject(x,y,-1,mmodel,mproj,viewp,&pos1[0],&pos1[1],&pos1[2]);
  gluUnProject(x,y, 1,mmodel,mproj,viewp,&pos2[0],&pos2[1],&pos2[2]);

  // Projectem sobre el pla XZ
  Vector p1(pos1[0],pos1[1],pos1[2]);
  Vector p2(pos2[0],pos2[1],pos2[2]);
  Vector dir = p2-p1;
  // Tenim p1 + dir*k = (x,0,z), d'on treballant sobre Y tenim
  // p1.y + dir.y*k = 0 --> k = -p1.y/dir.y
  // Coneguda k trobem x i z
  float k = -p1.y/dir.y;
  Vector punt = p1 + dir*k;
  return punt;
}


