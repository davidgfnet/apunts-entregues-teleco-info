
#include <iostream>
#include <math.h>
#include "point.h"
#include "matrix.h"

using namespace std;

Matrix::Matrix() {
  for (int i = 0; i < 4; i++)
    for (int j = 0; j < 4; j++)
      m.mat[i][j] = (i==j);
}

Matrix::Matrix(const float * ptr) {
  for (int i = 0; i < 16; i++)
    m.mat2[i] = ptr[i];
}

Matrix   operator+(const Matrix& a, const Matrix& b) {
  Matrix ret;
  for (int i = 0; i < 16; i++)
    ret.m.mat2[i] = a.m.mat2[i] + b.m.mat2[i];
  return ret;
}

Matrix   operator-(const Matrix& a, const Matrix& b) {
  Matrix ret;
  for (int i = 0; i < 16; i++)
    ret.m.mat2[i] = a.m.mat2[i] - b.m.mat2[i];
  return ret;
}

Matrix operator* (float f, const Matrix& m) {
  Matrix ret;
  for (int i = 0; i < 16; i++)
    ret.m.mat2[i] =f*m.m.mat2[i];
  return ret;
}

// Transforma un vector donada una matriu
Vector operator* (const Matrix& m,const Vector& v) {
  Vector ret;
  ret.x = m.m.mat[0][0]*v.x + m.m.mat[1][0]*v.y + m.m.mat[2][0]*v.z + m.m.mat[3][0];
  ret.y = m.m.mat[0][1]*v.x + m.m.mat[1][1]*v.y + m.m.mat[2][1]*v.z + m.m.mat[3][1];
  ret.z = m.m.mat[0][2]*v.x + m.m.mat[1][2]*v.y + m.m.mat[2][2]*v.z + m.m.mat[3][2];
  return ret;
}

// Crea una matriu de rotaci� al voltant de l'eix Y
Matrix MatrixRotationY(const float angle) {
  Matrix ret;
  ret.m.mat[0][0] = cos(angle);
  ret.m.mat[2][2] = cos(angle);

  ret.m.mat[2][0] = sin(angle);
  ret.m.mat[0][2] =-sin(angle);
  return ret;
}


