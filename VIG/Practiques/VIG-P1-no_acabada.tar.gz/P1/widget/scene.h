#ifndef _Scene_H_
#define _Scene_H_
#include "objecte.h"
#include "model.h"
#include <QtOpenGL/qgl.h>


class Scene
{
 private:
	
  // Tindrem un vector amb els models geomètrics dels objectes geomètrics
  // i un altre amb instàncies seves (instàncies o referències a objectes).
  std::vector<Model> lmodels;
  std::vector<Objecte> lobjectes;
  int zoom;
  int hangle,vangle;
  bool wireframe;
  float ratio;
  
 public:
  static MaterialLib matlib;	  // col·lecció de materials

  Scene();

  void Init();
  void construirBase();
  void Render();
  void LoadObject(std::string);
  void SetLastObjectPosition(Vector pos);
  void SetLastObjectRotation(int inc);

  void SetZoom(int);
  void UpdateHAngle(int);
  void UpdateVAngle(int);
  void setWireframe(bool);
  void setHiddenPartRemoval(bool);
  void ResetCamera();
  void setAspectRatio(float);
};

#endif

