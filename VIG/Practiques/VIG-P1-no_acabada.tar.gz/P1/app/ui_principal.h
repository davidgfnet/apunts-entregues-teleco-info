/********************************************************************************
** Form generated from reading UI file 'principal.ui'
**
** Created: 
**      by: Qt User Interface Compiler version 4.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PRINCIPAL_H
#define UI_PRINCIPAL_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QSlider>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include "glwidget.h"

QT_BEGIN_NAMESPACE

class Ui_Principal
{
public:
    QHBoxLayout *horizontalLayout_2;
    GLWidget *gLWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *buttonLoadObject;
    QLabel *label;
    QSlider *zoom_slider;
    QLabel *label_2;
    QSlider *hAngle;
    QSlider *vAngle;
    QPushButton *buttonResetCamera;
    QCheckBox *cbWireframe;
    QCheckBox *cbPartsOcultes;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton;

    void setupUi(QWidget *Principal)
    {
        if (Principal->objectName().isEmpty())
            Principal->setObjectName(QString::fromUtf8("Principal"));
        Principal->resize(644, 420);
        horizontalLayout_2 = new QHBoxLayout(Principal);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        gLWidget = new GLWidget(Principal);
        gLWidget->setObjectName(QString::fromUtf8("gLWidget"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(gLWidget->sizePolicy().hasHeightForWidth());
        gLWidget->setSizePolicy(sizePolicy);
        gLWidget->setMinimumSize(QSize(400, 400));

        horizontalLayout_2->addWidget(gLWidget);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetMinimumSize);
        buttonLoadObject = new QPushButton(Principal);
        buttonLoadObject->setObjectName(QString::fromUtf8("buttonLoadObject"));

        verticalLayout->addWidget(buttonLoadObject);

        label = new QLabel(Principal);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMargin(4);

        verticalLayout->addWidget(label);

        zoom_slider = new QSlider(Principal);
        zoom_slider->setObjectName(QString::fromUtf8("zoom_slider"));
        zoom_slider->setMinimum(1);
        zoom_slider->setMaximum(1000);
        zoom_slider->setOrientation(Qt::Horizontal);

        verticalLayout->addWidget(zoom_slider);

        label_2 = new QLabel(Principal);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMargin(4);

        verticalLayout->addWidget(label_2);

        hAngle = new QSlider(Principal);
        hAngle->setObjectName(QString::fromUtf8("hAngle"));
        hAngle->setMaximum(360);
        hAngle->setOrientation(Qt::Horizontal);

        verticalLayout->addWidget(hAngle);

        vAngle = new QSlider(Principal);
        vAngle->setObjectName(QString::fromUtf8("vAngle"));
        vAngle->setMinimum(-90);
        vAngle->setMaximum(90);
        vAngle->setOrientation(Qt::Horizontal);

        verticalLayout->addWidget(vAngle);

        buttonResetCamera = new QPushButton(Principal);
        buttonResetCamera->setObjectName(QString::fromUtf8("buttonResetCamera"));

        verticalLayout->addWidget(buttonResetCamera);

        cbWireframe = new QCheckBox(Principal);
        cbWireframe->setObjectName(QString::fromUtf8("cbWireframe"));

        verticalLayout->addWidget(cbWireframe);

        cbPartsOcultes = new QCheckBox(Principal);
        cbPartsOcultes->setObjectName(QString::fromUtf8("cbPartsOcultes"));

        verticalLayout->addWidget(cbPartsOcultes);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        pushButton = new QPushButton(Principal);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy1);

        horizontalLayout->addWidget(pushButton);


        verticalLayout->addLayout(horizontalLayout);


        horizontalLayout_2->addLayout(verticalLayout);


        retranslateUi(Principal);
        QObject::connect(buttonLoadObject, SIGNAL(clicked()), gLWidget, SLOT(LoadObject()));
        QObject::connect(pushButton, SIGNAL(clicked()), Principal, SLOT(close()));
        QObject::connect(zoom_slider, SIGNAL(valueChanged(int)), gLWidget, SLOT(UpdateZoom(int)));
        QObject::connect(hAngle, SIGNAL(valueChanged(int)), gLWidget, SLOT(UpdateHAngle(int)));
        QObject::connect(vAngle, SIGNAL(valueChanged(int)), gLWidget, SLOT(UpdateVAngle(int)));
        QObject::connect(buttonResetCamera, SIGNAL(clicked()), gLWidget, SLOT(ResetCamera()));
        QObject::connect(cbPartsOcultes, SIGNAL(toggled(bool)), gLWidget, SLOT(setHiddenPartRemoval(bool)));
        QObject::connect(cbWireframe, SIGNAL(toggled(bool)), gLWidget, SLOT(setWireframe(bool)));

        QMetaObject::connectSlotsByName(Principal);
    } // setupUi

    void retranslateUi(QWidget *Principal)
    {
        Principal->setWindowTitle(QApplication::translate("Principal", "Principal", 0, QApplication::UnicodeUTF8));
        buttonLoadObject->setText(QApplication::translate("Principal", "Load Object", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("Principal", "Zoom factor", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("Principal", "Camera orientation", 0, QApplication::UnicodeUTF8));
        buttonResetCamera->setText(QApplication::translate("Principal", "ResetCamera", 0, QApplication::UnicodeUTF8));
        cbWireframe->setText(QApplication::translate("Principal", "Wireframe", 0, QApplication::UnicodeUTF8));
        cbPartsOcultes->setText(QApplication::translate("Principal", "Eliminaci\303\263 de parts ocultes", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("Principal", "&Exit", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Principal: public Ui_Principal {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PRINCIPAL_H
